#include <ctype.h>

const struct ctype __ctype[256] = {
};
