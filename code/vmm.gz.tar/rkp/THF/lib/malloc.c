#include <bget.h>
#include <alloc.h>
#include <printf.h>
#include <arch/spinlock.h>
#include <assert.h>

//#define ALLOC_TRACE

spinlock_t malloc_lock = SPINLOCK_INITIALIZER;
/*tww @size: number of bytes*/
void *malloc(size_t size)
{
#ifdef ALLOC_TRACE
	uint64_t lr;
	asm volatile("mov %0, x30\n":"=r"(lr));
	spin_lock(&malloc_lock);
	void *ret = bget(size);
	spin_unlock(&malloc_lock);
	if (ret == NULL)
		panic("malloc failed\n");
	DMSG("ATRACE: malloc %zuB @0x%lx return %p\n", size, lr, ret);
	return ret;
#else
	spin_lock(&malloc_lock);
	void *ret = bget(size);
	spin_unlock(&malloc_lock);
	return ret;
#endif
}

void free(void *ptr)
{
#ifdef ALLOC_TRACE
	uint64_t lr;
	asm volatile("mov %0, x30\n":"=r"(lr));
	DMSG("ATRACE: free %p @0x%lx\n", ptr, lr);
#endif
	spin_lock(&malloc_lock);
	brel(ptr);
	spin_unlock(&malloc_lock);
}
