#include <string.h>

size_t strlen(const char *s)
{
	size_t ret = 0;
	while (*s)
		ret++, s++;
	return ret;
}

size_t strnlen(const char *s, size_t n)
{
	size_t ret = 0;
	while (n && *s)
		ret++, s++, n--;
	return ret;
}
