#ifndef ARCH_EXCEPTION_H_
#define ARCH_EXCEPTION_H_

#include <stdint.h>
#include <arch/aarch64.h>

#define EXP_EL2T_SYNC      0
#define EXP_EL2T_IRQ       1
#define EXP_EL2T_FIQ       2
#define EXP_EL2T_SERROR    3
#define EXP_EL2H_SYNC      4
#define EXP_EL2H_IRQ       5
#define EXP_EL2H_FIQ       6
#define EXP_EL2H_SERROR    7
#define EXP_EL1_SYNC       8
#define EXP_EL1_IRQ        9
#define EXP_EL1_FIQ        10
#define EXP_EL1_SERROR     11
#define EXP_EL1_32_SYNC    12
#define EXP_EL1_32_IRQ     13
#define EXP_EL1_32_FIQ     14
#define EXP_EL1_32_SERROR  15
#define N_EXCEPTION        16

#ifndef __ASSEMBLER__
typedef void (*exception_handler_t)(uint64_t eno, struct gpreg_context *regs);
extern exception_handler_t exptable[N_EXCEPTION];
#endif

#endif
