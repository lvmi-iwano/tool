#ifndef AARCH64_H_
#define AARCH64_H_

#include <compiler.h>
#include <stdint.h>

#define PAGE_SHIFT 12
#ifdef __ASSEMBLER__
#define PAGE_SIZE (1 << PAGE_SHIFT)
#else
#define PAGE_SIZE (1ULL << PAGE_SHIFT)
#endif

#define AARCH64_MODE_EL0t 0x0
#define AARCH64_MODE_EL1t 0x4
#define AARCH64_MODE_EL1h 0x5
#define AARCH64_MODE_EL2t 0x8
#define AARCH64_MODE_EL2h 0x9

#define AARCH32_MODE_USR  0x10
#define AARCH32_MODE_FIQ  0x11
#define AARCH32_MODE_IRQ  0x12
#define AARCH32_MODE_SVC  0x13
#define AARCH32_MODE_ABT  0x17
#define AARCH32_MODE_HYP  0x1A
#define AARCH32_MODE_SYS  0x1F

#ifdef __ASSEMBLER__
#define SYSREG_READ(type, name)
#define SYSREG_WRITE(type, name)
#else
#define SYSREG_READ(type, name) \
	static inline type read_##name(void) { \
		type res; \
		asm volatile("mrs %x0, " #name:"=r"(res)); \
		return res; \
	}
#define SYSREG_WRITE(type, name) \
	static inline void write_##name(type val) { \
		asm volatile("msr " #name ", %x0"::"r"(val)); \
	}
#endif

#define SYSREG(name) \
	SYSREG_READ(uint32_t, name) \
	SYSREG_WRITE(uint32_t, name)
#define SYSREG64(name) \
	SYSREG_READ(uint64_t, name) \
	SYSREG_WRITE(uint64_t, name)
#define RO_SYSREG(name) \
	SYSREG_READ(uint32_t, name)
#define RO_SYSREG64(name) \
	SYSREG_READ(uint64_t, name)

SYSREG64(hcr_el2);
#	define AARCH64_HCR_RW    BIT_64(31)  // EL1 is aarch64
#	define AARCH64_HCR_HVC   BIT_64(29)  //hvc disable 
#	define AARCH64_HCR_TDZ   BIT_64(28)  // Trap DC ZVA instruction
#	define AARCH64_HCR_TVM   BIT_64(26)  // Trap Virtual Memory Control
#	define AARCH64_HCR_TSC   BIT_64(19)  // Trap EL1 smc
#	define AARCH64_HCR_TID2  BIT_64(17)  // Trap ID group 2
#	define AARCH64_HCR_VSE   BIT_64(8)   // Virtual System Error or Asynchronous Abort
#	define AARCH64_HCR_VI    BIT_64(7)   // Virtual IRQ Interrupt
#	define AARCH64_HCR_VF    BIT_64(6)   // Virtual FIQ Interrupt
#	define AARCH64_HCR_AMO   BIT_64(5)   // Asynchronous External Abort and SError Interrupt routing
#	define AARCH64_HCR_IMO   BIT_64(4)   // Physical IRQ Routing
#	define AARCH64_HCR_FMO   BIT_64(3)   // Physical FIQ Routing
#	define AARCH64_HCR_VM    BIT_64(0)   // Enable stage 2 translation

SYSREG(cnthctl_el2);
#	define AARCH64_CNTHCTL_EL1PCEN   BIT_32(1) // EL1/0 allowed to access physical timer
#	define AARCH64_CNTHCTL_EL1PCTEN  BIT_32(0) // EL1/0 allowed to access physical counter
SYSREG(cntkctl_el1);
#	define AARCH64_CNTKCTL_EL0PCTEN  BIT_32(0)

SYSREG64(cntvoff_el2);

SYSREG64(id_aa64pfr0_el1);
#	define AARCH64_ID_AA64PFR0_GIC(reg) (((reg) >> 24) & 0xf)

SYSREG(spsr_el2);
#	define AARCH64_SPSR_N        BIT_32(31)
#	define AARCH64_SPSR_Z        BIT_32(30)
#	define AARCH64_SPSR_SS       BIT_32(21)
#	define AARCH64_SPSR_IL       BIT_32(20)
#	define AARCH64_SPSR_D        BIT_32( 9)
#	define AARCH64_SPSR_A        BIT_32( 8)
#	define AARCH64_SPSR_I        BIT_32( 7)
#	define AARCH64_SPSR_F        BIT_32( 6)
#	define AARCH64_SPSR_T        BIT_32( 5)
#	define AARCH64_SPSR_32       BIT_32( 4)
#	define AARCH64_SPSR_DAIF     (AARCH64_SPSR_D | AARCH64_SPSR_A | AARCH64_SPSR_I | AARCH64_SPSR_F)
#	define AARCH64_SPSR(x, y)    ((x) | (y))
#	define AARCH64_SPSR_M_SHIFT  0
#	define AARCH64_SPSR_M_WIDTH  5
#	define AARCH64_SPSR_M(reg)   (((reg) >> AARCH64_SPSR_M_SHIFT) & (BIT_32(AARCH64_SPSR_M_WIDTH) - 1))
#	define AARCH64_SPSR_M_MASK   BIT_32_MASK(AARCH64_SPSR_M_WIDTH + AARCH64_SPSR_M_SHIFT, AARCH64_SPSR_M_SHIFT)

SYSREG(esr_el2);
#	define AARCH64_ESR_EC(reg) (((reg) >> 26) & 0x3f)
#		define AARCH64_EC_SMC_32   0x13
#		define AARCH64_EC_SVC      0x15
#		define AARCH64_EC_HVC      0x16
#		define AARCH64_EC_SMC_64   0x17
#		define AARCH64_EC_MSR_MRS  0x18
#		define AARCH64_EC_IA_LOW   0x20
#		define AARCH64_EC_DA_LOW   0x24
SYSREG64(elr_el2);
SYSREG64(far_el2);

SYSREG(sctlr_el1);
SYSREG(sctlr_el2);
#	define AARCH64_SCTLR_EL2_RES 0x30C50830
#	define AARCH64_SCTLR_EL1_RES 0x30D00800
#	define AARCH64_SCTLR_WXN     BIT_32(19)
#	define AARCH64_SCTLR_I       BIT_32(12)
#	define AARCH64_SCTLR_SA      BIT_32(3)
#	define AARCH64_SCTLR_C       BIT_32(2)
#	define AARCH64_SCTLR_A       BIT_32(1)
#	define AARCH64_SCTLR_M       BIT_32(0)

SYSREG(cptr_el2);
#	define AARCH64_CPTR_EL2_RES 0x000033FF

SYSREG(midr_el1);
SYSREG64(mpidr_el1);
SYSREG64(mair_el1);
SYSREG64(mair_el2);
SYSREG64(amair_el1);
SYSREG(vpidr_el2);
SYSREG64(vmpidr_el2);
SYSREG64(sp_el0);
SYSREG64(sp_el1);
SYSREG(spsel);
SYSREG(dczid_el0);

SYSREG64(vbar_el2);
SYSREG(mdcr_el2);
#	define AARCH64_MDCR_TDA   BIT_32(9)
SYSREG(pmcr_el0);
SYSREG(afsr0_el1);
SYSREG(afsr1_el1);
SYSREG(contextidr_el1);
SYSREG(hstr_el2);

SYSREG(icc_sre_el2);
#	define AARCH64_ICC_SRE_ENABLE BIT_32(3)
#	define AARCH64_ICC_SRE_SRE    BIT_32(1)

SYSREG64(clidr_el1);
#	define AARCH64_CLIDR_CTYPE_WIDTH 3
#	define AARCH64_CLIDR_LOUIS_SHIFT 21
#	define AARCH64_CLIDR_LOUIS_WIDTH 3
#	define AARCH64_CLIDR_LOC_SHIFT   24
#	define AARCH64_CLIDR_LOC_WIDTH   3
SYSREG64(csselr_el1);
#	define AARCH64_CSSELR_LEVEL_SHIFT 1
SYSREG(ccsidr_el1);
#	define AARCH64_CCSIDR_LINESIZE_SHIFT         0
#	define AARCH64_CCSIDR_LINESIZE_WIDTH         3
#	define AARCH64_CCSIDR_LINESIZE(cssidr)       (((cssidr) >> AARCH64_CSSIDR_LINESIZE_SHIFT) & (BIT_32(AARCH64_CSSIDR_LINESIZE_WIDTH) - 1))
#	define AARCH64_CCSIDR_ASSOCIATIVITY_SHIFT    3
#	define AARCH64_CCSIDR_ASSOCIATIVITY_WIDTH    10
#	define AARCH64_CCSIDR_ASSOCIATIVITY(cssidr)  (((cssidr) >> AARCH64_CSSIDR_ASSOCIATIVITY_SHIFT) & (BIT_32(AARCH64_CSSIDR_ASSOCIATIVITY_WIDTH) - 1))
#	define AARCH64_CCSIDR_NUMSETS_SHIFT          13
#	define AARCH64_CCSIDR_NUMSETS_WIDTH          15
#	define AARCH64_CCSIDR_NUMSETS(cssidr)        (((cssidr) >> AARCH64_CSSIDR_NUMSETS_SHIFT) & (BIT_32(AARCH64_CSSIDR_NUMSETS_WIDTH) - 1))

SYSREG(tcr_el2);
#	define AARCH64_TCR_T0SZ_VA48     12
#	define AARCH64_TCR_IRGN0_WBWA    BIT_32(8)
#	define AARCH64_TCR_IRGN0_NC      0
#	define AARCH64_TCR_ORGN0_WBWA    BIT_32(10)
#	define AARCH64_TCR_ORGN0_NC      0
#	define AARCH64_TCR_SH0_OUTER     BIT_32(13)
#	define AARCH64_TCR_SH0_INNER     (BIT_32(13) | BIT_32(12))
#	define AARCH64_TCR_TG0_4K        0
#	define AARCH64_TCR_EL2_PS_WIDTH  3
#	define AARCH64_TCR_EL2_PS_SHIFT  16
#	define AARCH64_TCR_EL2_PS_48     (BIT_32(18) | BIT_32(16))
#	define AARCH64_TCR_T0SZ_SHIFT    0
#	define AARCH64_TCR_T0SZ_WIDTH    6
#	define AARCH64_TCR_T0SZ(reg)     (((reg) >> AARCH64_TCR_T0SZ_SHIFT) & (BIT_64(AARCH64_TCR_T0SZ_WIDTH) - 1))

SYSREG(vtcr_el2);
#	define AARCH64_VTCR_PS_SHIFT    16
#	define AARCH64_VTCR_TG0_4K      0
#	define AARCH64_VTCR_SH0_INNER   (BIT_32(13) | BIT_32(12))
#	define AARCH64_VTCR_ORGN0_WBWA  BIT_32(10)
#	define AARCH64_VTCR_IRGN0_WBWA  BIT_32(8)
#	define AARCH64_VTCR_SL0_SHIFT   6
#	define AARCH64_VTCR_SL0_WIDTH   2
#	define AARCH64_VTCR_SL0(reg)    (((reg) >> AARCH64_VTCR_SL0_SHIFT) & (BIT_32(AARCH64_VTCR_SL0_WIDTH) - 1))
#	define AARCH64_VTCR_T0SZ_SHIFT  0
#	define AARCH64_VTCR_T0SZ_WIDTH  6
#	define AARCH64_VTCR_T0SZ(reg)   (((reg) >> AARCH64_VTCR_T0SZ_SHIFT) & (BIT_32(AARCH64_VTCR_T0SZ_WIDTH) - 1))
#	define AARCH64_VTCR_RES         BIT_32(31)
SYSREG64(vttbr_el2);
#	define AARCH64_VTTBR_VMID_SHIFT   48
#	define AARCH64_VTTBR_VMID_WIDTH   8
#	define AARCH64_VTTBR_VMID(reg)    (((reg) >> AARCH64_VTTBR_VMID_SHIFT) & (BIT_64(AARCH64_VTTBR_VMID_WIDTH) - 1))
#	define AARCH64_VTTBR_BADDR_SHIFT  0
#	define AARCH64_VTTBR_BADDR_WIDTH  48
#	define AARCH64_VTTBR_BADDR(reg)   (((reg) >> AARCH64_VTTBR_BADDR_SHIFT) & (BIT_64(AARCH64_VTTBR_BADDR_WIDTH) - 1))
#	define AARCH64_VTTBR_BADDR_MASK   BIT_64_MASK(AARCH64_VTTBR_BADDR_WIDTH + AARCH64_VTTBR_BADDR_SHIFT, AARCH64_VTTBR_BADDR_SHIFT)

SYSREG64(ttbr0_el2);
#	define AARCH64_TTBR0_BADDR_SHIFT  0
#	define AARCH64_TTBR0_BADDR_WIDTH  48
#	define AARCH64_TTBR0_BADDR_MASK   BIT_64_MASK(AARCH64_TTBR0_BADDR_WIDTH + AARCH64_TTBR0_BADDR_SHIFT, AARCH64_TTBR0_BADDR_SHIFT)
#	define AARCH64_TTBR0_BADDR(reg)   (((reg) >> AARCH64_TTBR0_BADDR_SHIFT) & (BIT_64(AARCH64_TTBR0_BADDR_WIDTH) - 1))

SYSREG64(id_aa64mmfr0_el1);
#	define AARCH64_ID_AA64MMFR0_PARANGE_SHIFT  0
#	define AARCH64_ID_AA64MMFR0_PARANGE_WIDTH  4
#	define AARCH64_ID_AA64MMFR0_PARANGE(reg)   (((reg) >> AARCH64_ID_AA64MMFR0_PARANGE_SHIFT) & (BIT_64(AARCH64_ID_AA64MMFR0_PARANGE_WIDTH) - 1))

SYSREG(daif);
#	define AARCH64_DAIF_D  BIT_32(9)
#	define AARCH64_DAIF_A  BIT_32(8)
#	define AARCH64_DAIF_I  BIT_32(7)
#	define AARCH64_DAIF_F  BIT_32(6)

SYSREG64(tpidr_el2);

SYSREG64(par_el1);
#	define AARCH64_PAR_PA_SHIFT  12
#	define AARCH64_PAR_PA_WIDTH  36
#	define AARCH64_PAR_PA_MASK   BIT_64_MASK(AARCH64_PAR_PA_SHIFT + AARCH64_PAR_PA_WIDTH, AARCH64_PAR_PA_SHIFT)
#	define AARCH64_PAR_F         BIT_64(0)

SYSREG(ctr_el0);

SYSREG64(ttbr0_el1);
SYSREG64(ttbr1_el1);
SYSREG64(tcr_el1);
#	define AARCH64_TCR_EL1_T0SZ_SHIFT  0
#	define AARCH64_TCR_EL1_T0SZ_WIDTH  6
#	define AARCH64_TCR_EL1_T0SZ(reg)   (((reg) >> AARCH64_TCR_EL1_T0SZ_SHIFT) & (BIT_64(AARCH64_TCR_EL1_T0SZ_WIDTH) - 1))
#define AARCH64_TCR_EL1_EPD1 BIT_64(23)
#define AARCH64_TCR_EL1_EPD0 BIT_64(7)

SYSREG(esr_el1);
SYSREG64(elr_el1);
SYSREG(spsr_el1);
SYSREG64(far_el1);
SYSREG64(vbar_el1);

SYSREG(isr_el1);

SYSREG64(cntpct_el0);
SYSREG(cntfrq_el0);

#ifndef __ASSEMBLER__
struct gpreg_context {
	uint64_t x[31];
};
struct sysreg_context {
	uint64_t ttbr0_el1;
	uint64_t ttbr1_el1;
	uint64_t tcr_el1;
	uint64_t elr_el1;
	uint32_t spsr_el1;
	uint64_t far_el1;
	uint32_t esr_el1;
	uint64_t vbar_el1;
};
struct exception_context {
	uint64_t elr;
	uint32_t spsr;
	uint64_t esr;
	uint64_t far;
};
#endif

#ifndef __ASSEMBLER__
#define AARCH64_OP_UNKNOWN          0
#define AARCH64_OP_MSR_R            1
#define AARCH64_OP_MSR_I            2
#define AARCH64_OP_MRS              3
#define AARCH64_OP_HVC              4
#define AARCH64_OP_STR_IMM_8        5
#define AARCH64_OP_STR_IMM_16       6
#define AARCH64_OP_LDR_IMM_32       7
#define AARCH64_OP_STR_IMM_32       8
#define AARCH64_OP_STR_IMM_64       9
#define AARCH64_OP_STR_R_64         10
#define AARCH64_OP_STR_R_8          11
#define AARCH64_OP_STR_R_16         12
#define AARCH64_OP_STR_R_32         13
#define AARCH64_OP_LDR_IMM_16       14
#define AARCH64_OP_SVC              15
#define AARCH64_OP_LDR_IMM_POST_64  16
#define AARCH64_OP_STP_IMM_64       17
#define AARCH64_OP_STP_32           18
#define AARCH64_OP_DC               19
#define AARCH64_OP_STUR_8           20
#define AARCH64_OP_STUR_16          21
#define AARCH64_OP_STUR_32          22
#define AARCH64_OP_STUR_64          23
#define AARCH64_OP_STNP_32          24
#define AARCH64_OP_STNP_128         25
#define AARCH64_OP_STXR_64          26

#define AARCH64_COPROC_REVIDR_EL1  0x4006
#define AARCH64_COPROC_AIDR_EL1    0x4807
#define AARCH64_COPROC_CTR_EL0     0x5801
#define AARCH64_COPROC_CCSIDR_EL1  0x4800
#define AARCH64_COPROC_CLIDR_EL1   0x4801
#define AARCH64_COPROC_CSSELR_EL1  0x5000

#define AARCH64_COPROC_SCTLR_EL1  0X4080
#define AARCH64_COPROC_TTBR0_EL1  0X4100
#define AARCH64_COPROC_TTBR1_EL1  0X4101
#define AARCH64_COPROC_TCR_EL1    0X4102
#define AARCH64_COPROC_ESR_EL1    0X4290
#define AARCH64_COPROC_FAR_EL1    0X4300
#define AARCH64_COPROC_AFSR0_EL1  0X4288
#define AARCH64_COPROC_AFSR1_EL1  0X4289
#define AARCH64_COPROC_MAIR_EL1   0X4510
#define AARCH64_COPROC_AMAIR_EL1  0X4518
#define AARCH64_COPROC_CONTEXTIDR_EL1  0X4681

uint32_t aarch64_instr_get_op(uint32_t instr);
uint32_t aarch64_instr_get_coproc(uint32_t instr);
uint32_t aarch64_instr_get_Rt(uint32_t instr);
uint32_t aarch64_instr_get_Rn(uint32_t instr);
uint8_t aarch64_instr_wback(uint32_t instr);
uint8_t aarch64_sysreg_is_id2(uint32_t coproc);
uint8_t aarch64_sysreg_is_id(uint32_t coproc);
uint8_t aarch64_sysreg_is_vmemctrl(uint32_t coproc);
#endif

#endif
