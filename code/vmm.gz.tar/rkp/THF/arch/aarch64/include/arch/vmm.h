#ifndef ARCH_VMM_H_
#define ARCH_VMM_H_

#ifndef __ASSEMBLER__

#include <plat/platform_config.h>
#include <list.h>
#include <hypervisor.h>
#include <bitfield.h>
#include <arch/mmu.h>

#define MAX_VCPU NUM_CORES

struct vm {
	struct vcpu {
		struct gpreg_context gpreg;
		struct sysreg_context sysreg;
		struct exception_context excpreg;
		struct vm *vm;
		uint64_t pc;
		uint32_t cpsr;
		uint8_t vcpu_id;
		uint8_t irq:1;
		uint8_t fiq:1;
	} vcpu[MAX_VCPU];
	struct list_head trap_handlers[MAX_TRAP_TYPE];
	struct mmu_table *s2pt;
	pite_t *root;//tww: pit table for each vm
	uint8_t vmid;
	BITFIELD(trap, MAX_TRAP_TYPE);
	void *plugin_data[];
};

int vcpu_redirect_smc(struct vcpu *vcpu, void *arg);
int vcpu_redirect_mrs(struct vcpu *vcpu, void *arg);
int vcpu_redirect_msr_r(struct vcpu *vcpu, void *arg);
#endif

#endif
