#ifndef ARCH_MMU_H_
#define ARCH_MMU_H_

#include <stdint.h>
#include <compiler.h>

#define VA_L3_SHIFT  12
#define VA_L3_WIDTH  9
#define VA_L2_SHIFT  21
#define VA_L2_WIDTH  9
#define VA_L1_SHIFT  30
#define VA_L1_WIDTH  9
#define VA_L0_SHIFT  39
#define VA_L0_WIDTH  9

#define PT_ENTRY_SIZE      8
#define LOG_PT_ENTRY_SIZE  3

#define pte_valid_not_user(pte) \
  ((pte & (PT_Lx_VALID | PT_L3_EL0_ACCESS)) == PT_Lx_VALID)

#define PT_Lx_VALID_SHIFT       0
#define PT_Lx_VALID             BIT_64(PT_Lx_VALID_SHIFT)
#define PT_Lx_TABLE             BIT_64(1)
#define PT_Lx_BLOCK             0
#define PT_Lx_NEXTLEVEL_SHIFT   12
#define PT_Lx_NEXTLEVEL_WIDTH   36
#define PT_Lx_NEXTLEVEL_MASK    BIT_64_MASK(PT_Lx_NEXTLEVEL_SHIFT + PT_Lx_NEXTLEVEL_WIDTH, PT_Lx_NEXTLEVEL_SHIFT)
#define PT_Lx_PA_SHIFT          12
#define PT_Lx_PA_WIDTH          36
#define PT_Lx_PA_MASK           BIT_64_MASK(PT_Lx_PA_SHIFT + PT_Lx_PA_WIDTH, PT_Lx_PA_SHIFT)
#define PT_Lx_UPPER_ATTR_SHIFT  52
#define PT_Lx_UPPER_ATTR_WIDTH  12
#define PT_Lx_UPPER_ATTR_MASK   BIT_64_MASK(PT_Lx_UPPER_ATTR_SHIFT + PT_Lx_UPPER_ATTR_WIDTH, PT_Lx_UPPER_ATTR_SHIFT)
#define PT_Lx_LOWER_ATTR_SHIFT  2
#define PT_Lx_LOWER_ATTR_WIDTH  10
#define PT_Lx_LOWER_ATTR_MASK   BIT_64_MASK(PT_Lx_LOWER_ATTR_SHIFT + PT_Lx_LOWER_ATTR_WIDTH, PT_Lx_LOWER_ATTR_SHIFT)

#define PT_L3_AP_RO             BIT_64(7)
#define PT_L3_AP_EL0            BIT_64(6)
#define PT_L3_AP_EL2_RW         0
#define PT_L3_AP_EL2_R          BIT_64(7)
#define PT_L3_S2AP_NONE         0
#define PT_L3_S2AP_RO           BIT_64(6)
#define PT_L3_S2AP_WO           BIT_64(7)
#define PT_L3_S2AP_RW           (BIT_64(7) | BIT_64(6))
#define PT_L3_SH_OUTER          BIT_64(9)
#define PT_L3_SH_INNER          (BIT_64(9) | BIT_64(8))
#define PT_L3_ATTR_SHIFT        2
#define PT_L3_ATTR_NORMAL       (1 << PT_L3_ATTR_SHIFT)
#define PT_L3_ATTR_DEVICE       (2 << PT_L3_ATTR_SHIFT)
#define PT_L3_ATTR_NORMAL_NC    (3 << PT_L3_ATTR_SHIFT)
#define PT_L3_S2ATTR_NORMAL     (0xf << PT_L3_ATTR_SHIFT)
#define PT_L3_S2ATTR_DEVICE     (0x3 << PT_L3_ATTR_SHIFT)
#define PT_L3_S2ATTR_NORMAL_NC  (0x5 << PT_L3_ATTR_SHIFT)
#define PT_L3_VALID             (BIT_64(0) | BIT_64(1))
#define PT_L3_EL0_ACCESS        BIT_64(6) /* AP[1] */
#define PT_L3_W                 BIT_64(7) /* AP[2] */
#define PT_L3_AF                BIT_64(10)
#define PT_L3_PXN               BIT_64(53)
#define PT_L3_XN                BIT_64(54)
#define PT_L3_PA_SHIFT          12
#define PT_L3_PA_WIDTH          36
#define PT_L3_PA_MASK           (BIT_64(PT_L3_PA_SHIFT + PT_L3_PA_WIDTH) - BIT_64(PT_L3_PA_SHIFT))

#define DEFAULT_MAIR ((0xff << 8) | (0x00 << 16) | (0x44 << 24))

#define NX BIT_64(1)
#define RO BIT_64(0)
#ifndef __ASSEMBLER__
extern const uint64_t reloc_offset;

extern uint32_t bootstrap_pagetable_inited;
extern uint8_t bootstrap_pagetable[PAGE_SIZE * 50];
extern uint64_t *bootstrap_pagetable_allocp;

#define PIT_ENTRY 512
#define PIT_TABLE_SHIFT 8 /*one byte/entry, and can support max 4G RAM*/
#define PA_MASK 0xfffff

struct pt_entry {
	uint64_t v;
};
struct mmu_table {
	uint8_t va_bit;
	uint8_t stage;
	uint8_t level;
	uint8_t concat;
	struct pt_entry *pt;
};

typedef union {
    struct {
        uint64_t p : 1,
                 reserved : 11,
                 count: 10, /*the number of used entry of next pit table, used to free*/
                 vfn : 42;
    };
    uint64_t l1pite;
} l1pite_t;

typedef union {
    struct {
        uint64_t p : 1,
                 reserved : 11,
                 count: 10, 
                 vfn : 42;
    };
    uint8_t l2pite;
} l2pite_t;
/*page info table entry*/
typedef union {
    struct {
        uint8_t pt : 1, //is page table
                p : 1, //1: valid
                level : 2, //0-3, level of pt
                ap : 2, //bit0: ro bit 1: nx access permission xwr
                reserved : 2;
    };
    uint8_t pite;
} pite_t;

#endif

#endif
