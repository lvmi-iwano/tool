#ifndef LIBHYPERVISOR_CACHE_H_
#define LIBHYPERVISOR_CACHE_H_

#ifndef __ASSEMBLER__
#include <stdint.h>
#endif

#ifndef __ASSEMBLER__
void dcache_flush_range(vaddr_t start, size_t size);
void dcache_invalidate_range(vaddr_t start, size_t size);
void dcache_flush_all(void);
void dcache_invalidate_all(void);
#endif

#define CACHE_OP_ISW  0
#define CACHE_OP_CISW 1
#define CACHE_OP_CSW  2
#ifndef __ASSEMBLER__
void dcsw_op_louis(uint32_t op);
void dcsw_op_all(uint32_t op);
void dcsw_op_level1(uint32_t op);
void dcsw_op_level2(uint32_t op);
void dcsw_op_level3(uint32_t op);
#endif

#ifndef __ASSEMBLER__
#define tlbi(op) asm volatile ("tlbi " op:::"memory");
#define tlbiva(op, va) asm volatile ("tlbi " #op ", %x0"::"r"(va):"memory");
#endif

#endif
