#ifndef AARCH64_IO_H_
#define AARCH64_IO_H_

#include <stdint.h>
#include <arch/barrier.h>

static inline uint32_t read32(void *addr) {
	return *(volatile uint32_t *) addr;
}

static inline void write32(void *addr, uint32_t val) {
	*(volatile uint32_t *) addr = val;
	dsb(sy);
}

static inline uint8_t read8(void *addr) {
	return *(volatile uint8_t *) addr;
}

static inline void write8(void *addr, uint8_t val) {
	*(volatile uint8_t *) addr = val;
	dsb(sy);
}

static inline void write64(void *addr, uint64_t val) {
	*(volatile uint64_t *) addr = val;
}
#endif
