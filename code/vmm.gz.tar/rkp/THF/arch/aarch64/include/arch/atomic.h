#ifndef ARCH_ATOMIC_H_
#define ARCH_ATOMIC_H_

typedef uint64_t atomic_t;
static inline atomic_t atomic_inc_x(atomic_t *v, atomic_t x)
{
	atomic_t ret;
	asm volatile (
		"1: ldaxr x0, [%1]\n"
		"add x0, x0, %2\n"
		"stxr w1, x0, [%1]\n"
		"cbnz w1, 1b\n"
		"mov %0, x0\n"
		: "=r"(ret)
		: "r"(v), "r"(x)
		: "x0", "w1", "memory");
	return ret - x;
}

static inline atomic_t atomic_inc(atomic_t *v)
{
	return atomic_inc_x(v, 1);
}

#endif
