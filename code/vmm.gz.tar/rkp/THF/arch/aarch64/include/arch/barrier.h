#ifndef AARCH64_BARRIER_H_
#define AARCH64_BARRIER_H_

#define dsb(opt)    asm volatile("dsb " #opt : : : "memory")
#define isb()       asm volatile("isb" : : : "memory")

static inline void dmb() {
	asm volatile("dmb sy":::"memory");
}

/*static inline void isb() {
	asm volatile("isb sy":::"memory");
}*/

#endif
