#include <init.h>
#include <arch/aarch64.h>
#include <printf.h>
#include <hypervisor.h>

int arch_init(void)
{
	write_hcr_el2(AARCH64_HCR_RW);
	write_cnthctl_el2(read_cnthctl_el2() | AARCH64_CNTHCTL_EL1PCEN | AARCH64_CNTHCTL_EL1PCTEN);
	write_cntvoff_el2(0);
	// Have GIC v3
	asm volatile (
		"	/* GICv3 system register access */\n"
		"	mrs	x0, id_aa64pfr0_el1\n"
		"	ubfx	x0, x0, #24, #4\n"
		"	cmp	x0, #1\n"
		"	b.ne	3f\n"

		"	mrs	x0, ICC_SRE_EL2\n"
		"	orr	x0, x0, #(1 << 3)	// Set ICC_SRE_EL2.SRE==1\n"
		"	orr	x0, x0, #(1 << 0)	// Set ICC_SRE_EL2.Enable==1\n"
		"	msr	ICC_SRE_EL2, x0\n"
		"	isb					// Make sure SRE is now set\n"
		"	msr	ICH_HCR_EL2, xzr		// Reset ICC_HCR_EL2 to defaults\n"

		"3:\n"
		:
		:
		: "x0", "memory");
	write_vpidr_el2(read_midr_el1());
	write_vmpidr_el2(read_mpidr_el1());
	if (warm_boot[get_core_pos()] != BOOT_TYPE_COLD)
		write_sctlr_el1(AARCH64_SCTLR_EL1_RES);
	write_cptr_el2(AARCH64_CPTR_EL2_RES);
	write_hstr_el2(0);
	write_mdcr_el2((read_pmcr_el0() >> 11) & (0x1f));
	write_vttbr_el2(0);

	return 0;
}

register_init(arch, arch_init);
