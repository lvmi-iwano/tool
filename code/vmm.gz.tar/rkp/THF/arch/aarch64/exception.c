#include <init.h>
#include <stdint.h>
#include <arch/aarch64.h>
#include <arch/exception.h>
#include <printf.h>
#include <arch/barrier.h>
#include <hypervisor.h>
#include <arch/vmm.h>
#include <assert.h>

extern uint8_t exp_vector[];
exception_handler_t exptable[N_EXCEPTION];
extern uint64_t cnt_exception;
extern uint64_t cnt_all;
extern uint8_t print_open;
static uint64_t cnt_exception_;
static uint64_t cnt_all_;
void dummy_exception(uint64_t eno, struct gpreg_context *regs)
{
	EMSG("Unhandled exception %lu\n", eno);
	//EMSG("esr 0x%x elr 0x%lx x30 0x%lx far 0x%lx\n", read_esr_el2(), read_elr_el2(), regs->x[30], read_far_el2());
	EMSG("far 0x%lx esr 0x%x elr 0x%lx x30 0x%lx\n", read_far_el2(), read_esr_el2(), read_elr_el2(), regs->x[30]);
}

void vm_exception(uint64_t eno, struct gpreg_context *regs)
{
    
    /*uint64_t s,e;
    uint64_t s_,e_;
    if (print_open) {
        s = read_cntpct();
    }*/
	assert(vm_get_current_vcpu() != NULL);
	struct vcpu *vcpu = vm_get_current_vcpu();
	vmexit(regs);

	switch (eno) {
	case EXP_EL1_FIQ:
	case EXP_EL1_32_FIQ:
		vcpu_handle_fiq(vcpu);
		break;
	case EXP_EL1_SYNC:
	case EXP_EL1_32_SYNC:
      /*  if (print_open) {
            s_ = read_cntpct();
        }*/
		vcpu_handle_exception(vcpu);
    /*if (print_open) {
        e_ = read_cntpct();
        add_cnt(s_,e_,&cnt_exception_);
    }*/
		break;
	case EXP_EL1_SERROR:
	case EXP_EL1_32_SERROR:
		EMSG("Shouldn't got this exception\n");
		for (;;);
		break;
	}
    /*if (print_open) {
        e = read_cntpct();
        add_cnt(s,e,&cnt_all_);
        cnt_exception = cnt_exception_;
        cnt_all = cnt_all_;    
    }*/
	vm_run(vm_get_next_vcpu());
}

void __weak handle_irq(uint64_t eno, struct gpreg_context *regs)
{
	panic("No IRQ handler\n");
}

int init_vbar(void)
{
	uint32_t i;

	exptable[EXP_EL2T_SYNC    ] = dummy_exception;
	exptable[EXP_EL2T_IRQ     ] = handle_irq;
	exptable[EXP_EL2T_FIQ     ] = dummy_exception;
	exptable[EXP_EL2T_SERROR  ] = dummy_exception;
	exptable[EXP_EL2H_SYNC    ] = dummy_exception;
	exptable[EXP_EL2H_IRQ     ] = handle_irq;
	exptable[EXP_EL2H_FIQ     ] = dummy_exception;
	exptable[EXP_EL2H_SERROR  ] = dummy_exception;
	exptable[EXP_EL1_SYNC     ] = vm_exception;
	exptable[EXP_EL1_IRQ      ] = handle_irq;
	exptable[EXP_EL1_FIQ      ] = vm_exception;
	exptable[EXP_EL1_SERROR   ] = vm_exception;
	exptable[EXP_EL1_32_SYNC  ] = vm_exception;
	exptable[EXP_EL1_32_IRQ   ] = handle_irq;
	exptable[EXP_EL1_32_FIQ   ] = vm_exception;
	exptable[EXP_EL1_32_SERROR] = vm_exception;

	write_vbar_el2((uint64_t) exp_vector);
	dmb();
	return 0;
}

register_init(arch, init_vbar);

uint32_t disable_interrupt(void)
{
	uint32_t daif = read_daif();
	write_daif(AARCH64_DAIF_D | AARCH64_DAIF_A | AARCH64_DAIF_I | AARCH64_DAIF_F);
	return daif;
}

void resume_interrupt(uint32_t daif)
{
	write_daif(daif);
}
