#include <plat/platform_config.h>
#include <stdint.h>
#include <hypervisor.h>

uint64_t stacks[NUM_CORES][(STACK_SIZE + sizeof(uint64_t)) / sizeof(uint64_t)];

void *get_core_stack(void)
{
	return stacks[get_core_pos() + 1];
}
