#include <arch/aarch64.h>
#include <assert.h>

static inline uint32_t aarch64_instr_get_op_C434(uint32_t instr)//
{
	uint8_t L = (instr >> 21) & 1, op0 = (instr >> 19) & 3, op1 = (instr >> 16) & 7,
	        CRn = (instr >> 12) & 0xf, CRm = (instr >> 8) & 0xf, op2 = (instr >> 5) & 7, Rt = instr & 0x1f;
	if (L == 0) {//write operation
		if (op0 == 0 && CRn == 4 && Rt == 0x1f)//MSR(immediate)
			return AARCH64_OP_MSR_I;
		else if (op0 == 2 || op0 == 3)
			return AARCH64_OP_MSR_R;//tww: MSR(register)
        else if (op0 == 1 && CRn == 7)
            return AARCH64_OP_DC; 
		else {
			EMSG("Not implemented: 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x\n", L, op0, op1, CRn, CRm, op2, Rt);
			return AARCH64_OP_UNKNOWN;
		}
	} else {
		if (op0 == 2 || op0 == 3)
			return AARCH64_OP_MRS;//MRS
		else {
			EMSG("Not implemented: 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x\n", L, op0, op1, CRn, CRm, op2, Rt);
			return AARCH64_OP_UNKNOWN;
		}
	}
}

static inline uint32_t aarch64_instr_get_op_C433(uint32_t instr)
{
	uint8_t op = ((instr >> 16) & 0xe0) | (instr & 0x1f);
	switch (op) {
	case 0x02:
		return AARCH64_OP_HVC;
	case 0x01:
		return AARCH64_OP_SVC;
	default:
		EMSG("Not implemented: 0x%x\n", op);
		return AARCH64_OP_UNKNOWN;
	}
}

static inline uint32_t aarch64_instr_get_op_C43(uint32_t instr)
{
	uint8_t op0 = (instr >> 29) & 0x7, op1 = (instr >> 22) & 0xf;
	if (op0 == 6) {
		if (op1 == 4)
			return aarch64_instr_get_op_C434(instr);
		else if ((op1 & 0xc) == 0)
			return aarch64_instr_get_op_C433(instr);
		else {
			EMSG("Not implemented: 0x%x 0x%x\n", op0, op1);
			return AARCH64_OP_UNKNOWN;
		}
	} else {
		EMSG("Not implemented: 0x%x 0x%x\n", op0, op1);
		return AARCH64_OP_UNKNOWN;
	}
}

static inline uint32_t aarch64_instr_get_op_C446(uint32_t instr)
{
    uint8_t size_o2_L_o1_o0 = ((instr >> 26) & 0x30) | ((instr >> 20) & 0xe) | ((instr >> 15) & 1);
    switch (size_o2_L_o1_o0) {
    case 0x30:
        return AARCH64_OP_STXR_64;
	default:
		EMSG("Not implemented: 0x%x\n", size_o2_L_o1_o0);
		return AARCH64_OP_UNKNOWN;
    }
}
static inline uint32_t aarch64_instr_get_op_C447(uint32_t instr)
{
	uint8_t opc_V_L = ((instr >> 28) & 0xC) | ((instr >> 25) & 2) | ((instr >> 22) & 1);
	switch (opc_V_L) {
    case 0x0:
        return AARCH64_OP_STNP_32;
	case 0x10:
		return AARCH64_OP_STNP_128;
	default:
		EMSG("Not implemented: 0x%x\n", opc_V_L);
		return AARCH64_OP_UNKNOWN;
	}
}

static inline uint32_t aarch64_instr_get_op_C448(uint32_t instr)
{
	uint8_t size_V_opc = ((instr >> 27) & 0x18) | ((instr >> 24) & 4) | ((instr >> 22) & 3);
	switch (size_V_opc) {
    case 0x00:
        return AARCH64_OP_STR_IMM_8;
    case 0x08:
        return AARCH64_OP_STR_IMM_16;
	case 0x10:
		return AARCH64_OP_STR_IMM_32;
	case 0x18:
		return AARCH64_OP_STR_IMM_64;
	case 0x19:
		return AARCH64_OP_LDR_IMM_POST_64;
	default:
		EMSG("Not implemented: 0x%x\n", size_V_opc);
		return AARCH64_OP_UNKNOWN;
	}
}

static inline uint32_t aarch64_instr_get_op_C449(uint32_t instr)
{
	uint8_t size_V_opc = ((instr >> 27) & 0x18) | ((instr >> 24) & 4) | ((instr >> 22) & 3);
	switch (size_V_opc) {
    case 0x00:
        return AARCH64_OP_STR_IMM_8;
    case 0x08:
        return AARCH64_OP_STR_IMM_16;
	case 0x10:
		return AARCH64_OP_STR_IMM_32;
	case 0x18:
		return AARCH64_OP_STR_IMM_64;
	default:
		EMSG("Not implemented: 0x%x\n", size_V_opc);
		return AARCH64_OP_UNKNOWN;
	}
}

static inline uint32_t aarch64_instr_get_op_C4410(uint32_t instr)
{
	uint8_t size_V_opc = ((instr >> 27) & 0x18) | ((instr >> 24) & 4) | ((instr >> 22) & 3);
	switch (size_V_opc) {
    case 0x0:
        return AARCH64_OP_STR_R_8;
    case 0x08:
        return AARCH64_OP_STR_R_16;
    case 0x10:
        return AARCH64_OP_STR_R_32;
    case 0x18:
        return AARCH64_OP_STR_R_64;
	default:
		EMSG("Not implemented: 0x%x\n", size_V_opc);
		return AARCH64_OP_UNKNOWN;
    }
}

static inline uint32_t aarch64_instr_get_op_C4412(uint32_t instr)
{
	uint8_t size_V_opc = ((instr >> 27) & 0x18) | ((instr >> 24) & 4) | ((instr >> 22) & 3);
	switch (size_V_opc) {
    case 0x0:
        return AARCH64_OP_STUR_8;
    case 0x08:
        return AARCH64_OP_STUR_16;
    case 0x10:
        return AARCH64_OP_STUR_32;
    case 0x18:
        return AARCH64_OP_STUR_64;
	default:
		EMSG("Not implemented: 0x%x\n", size_V_opc);
		return AARCH64_OP_UNKNOWN;
    }
}

static inline uint32_t aarch64_instr_get_op_C4413(uint32_t instr)
{
	uint8_t size_V_opc = ((instr >> 27) & 0x18) | ((instr >> 24) & 4) | ((instr >> 22) & 3);
	switch (size_V_opc) {
	case 0x00:
        return AARCH64_OP_STR_IMM_8;//wirte the least significant byte of register to memory
    case 0x08:
        return AARCH64_OP_STR_IMM_16;//the least significant halfword of register
	case 0x10:
		return AARCH64_OP_STR_IMM_32;
	case 0x11:
		return AARCH64_OP_LDR_IMM_32;
	case 0x18:
		return AARCH64_OP_STR_IMM_64;
	case 0x19:
		return AARCH64_OP_LDR_IMM_16;
	default:
		EMSG("Not implemented: 0x%x\n", size_V_opc);
		return AARCH64_OP_UNKNOWN;
	}
}

static inline uint32_t aarch64_instr_get_op_C4414(uint32_t instr)
{
	uint8_t opc_V_L = ((instr >> 28) & 0xC) | ((instr >> 25) & 2) | ((instr >> 22) & 1);
	switch (opc_V_L) {
    case 0x0:
        return AARCH64_OP_STP_32;
	case 0x8:
		return AARCH64_OP_STP_IMM_64;
	default:
		EMSG("Not implemented: 0x%x\n", opc_V_L);
		return AARCH64_OP_UNKNOWN;
	}
}

static inline uint32_t aarch64_instr_get_op_C4415(uint32_t instr)
{
	uint8_t opc_V_L = ((instr >> 28) & 0xC) | ((instr >> 25) & 2) | ((instr >> 22) & 1);
	switch (opc_V_L) {
      case 0x0:
        return AARCH64_OP_STP_32;
	case 0x8:
		return AARCH64_OP_STP_IMM_64;
	default:
		EMSG("Not implemented: 0x%x\n", opc_V_L);
		return AARCH64_OP_UNKNOWN;
	}
}

static inline uint32_t aarch64_instr_get_op_C4416(uint32_t instr)
{
	uint8_t opc_V_L = ((instr >> 28) & 0xC) | ((instr >> 25) & 2) | ((instr >> 22) & 1);
	switch (opc_V_L) {
    case 0x0:
        return AARCH64_OP_STP_32;
	case 0x8:
		return AARCH64_OP_STP_IMM_64;
	default:
		EMSG("Not implemented: 0x%x\n", opc_V_L);
		return AARCH64_OP_UNKNOWN;
	}
}

static inline uint32_t aarch64_instr_get_op_C44(uint32_t instr)
{
	uint8_t op0 = (instr >> 31) & 1, op1 = (instr >> 28) & 3, op2 = (instr >> 26) & 1,
	        op3 = (instr >> 23) & 3, op4 = (instr >> 16) & 0x3f, op5 = (instr >> 10) & 3;
	if (op1 == 3) {
		if (op3 == 2 || op3 == 3)
			return aarch64_instr_get_op_C4413(instr);
		else if ((op3 == 0 || op3 == 1) && ((op4 & 0x20) == 0) && op5 == 1)
			return aarch64_instr_get_op_C448(instr);
		else if ((op3 == 0 || op3 == 1) && ((op4 & 0x20) == 0) && op5 == 3)
            return aarch64_instr_get_op_C449(instr);
        else if ((op3 == 0 || op3 == 1) && ((op4 & 0x20) == 0x20) && op5 == 2)
            return aarch64_instr_get_op_C4410(instr);
        else if ((op3 == 0 || op3 == 1) && ((op4 & 0x20) == 0) && op5 == 0)
            return aarch64_instr_get_op_C4412(instr);
		else {
			EMSG("instr: 0x%x Not implemented: 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x\n", instr, op0, op1, op2, op3, op4, op5);//
			return AARCH64_OP_UNKNOWN;
		}
	} else if (op1 == 2 && op3 == 0) 
        return aarch64_instr_get_op_C447(instr);
    else if (op1 == 2 && op3 == 2)
		return aarch64_instr_get_op_C4414(instr);
    else if (op1 == 2 && op3 == 1)
        return aarch64_instr_get_op_C4415(instr);
    else if (op1 == 2 && op3 == 3)
        return aarch64_instr_get_op_C4416(instr);
    else if (op1 == 0 && op2 == 0 && (op3 == 0 || op3 == 1))
        return aarch64_instr_get_op_C446(instr);
	else {
		EMSG("Not implemented: 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x\n", op0, op1, op2, op3, op4, op5);
		return AARCH64_OP_UNKNOWN;
	}
}

uint32_t aarch64_instr_get_op(uint32_t instr)
{
	switch ((instr >> 25) & 0xf) {
	case 0x0:
	case 0x1:
	case 0x2:
	case 0x3:
		// Unallocated
		return AARCH64_OP_UNKNOWN;
	case 0x8:
	case 0x9:
		// Data processing - immediate
		EMSG("Not implemented: 0x%08x\n", instr);
		return AARCH64_OP_UNKNOWN;
	case 0xa:
	case 0xb:
		// Branch, exception generating, system instruction
		return aarch64_instr_get_op_C43(instr);
	case 0x4:
	case 0x6:
	case 0xc:
	case 0xe:
		// Load, store
		return aarch64_instr_get_op_C44(instr);
	case 0x5:
	case 0xd:
		// Data processing - register
		EMSG("Not implemented: 0x%08x\n", instr);
		return AARCH64_OP_UNKNOWN;
	case 0x7:
	case 0xf:
		// Data processing - SIMD
		EMSG("Not implemented: 0x%08x\n", instr);
		return AARCH64_OP_UNKNOWN;
	default:
		return AARCH64_OP_UNKNOWN;
	}
}

uint32_t aarch64_instr_get_coproc(uint32_t instr)
{
	uint32_t op = aarch64_instr_get_op(instr);
	assert(op == AARCH64_OP_MSR_R || op == AARCH64_OP_MRS);
	return (instr >> 5) & 0x7fff;
}

uint32_t aarch64_instr_get_Rt(uint32_t instr)
{
	return instr & 0x1f;
}

uint32_t aarch64_instr_get_Rn(uint32_t instr)
{
	return (instr >> 5) & 0x1f;
}

uint8_t aarch64_instr_wback(uint32_t instr)
{
	switch (aarch64_instr_get_op(instr)) {
	case AARCH64_OP_LDR_IMM_POST_64:
		return 1;
	case AARCH64_OP_LDR_IMM_32:
	case AARCH64_OP_STR_IMM_32:
		return 0;
	default:
		EMSG("Not implemented: %u\n", aarch64_instr_get_op(instr));
		return 0;
	}
}

uint8_t aarch64_sysreg_is_id2(uint32_t coproc)
{
	switch (coproc) {
	case AARCH64_COPROC_CTR_EL0: 
	case AARCH64_COPROC_CCSIDR_EL1:
	case AARCH64_COPROC_CLIDR_EL1:
	case AARCH64_COPROC_CSSELR_EL1:
		return 1;
	default:
		return 0;
	}
}

uint8_t aarch64_sysreg_is_vmemctrl(uint32_t coproc)
{
    switch (coproc) {
       case AARCH64_COPROC_SCTLR_EL1:  
       case AARCH64_COPROC_TTBR0_EL1:  
       case AARCH64_COPROC_TTBR1_EL1:  
       case AARCH64_COPROC_TCR_EL1:    
       case AARCH64_COPROC_ESR_EL1:    
       case AARCH64_COPROC_FAR_EL1:    
       case AARCH64_COPROC_AFSR0_EL1:
       case AARCH64_COPROC_AFSR1_EL1:  
       case AARCH64_COPROC_MAIR_EL1:   
       case AARCH64_COPROC_AMAIR_EL1:  
       case AARCH64_COPROC_CONTEXTIDR_EL1:
	        return 1;
	   default:
		    return 0;
    }
}

uint8_t aarch64_sysreg_is_id(uint32_t coproc)
{
	return aarch64_sysreg_is_id2(coproc);
}
