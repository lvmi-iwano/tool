#include <plat/platform_config.h>
#include <stdint.h>
#include <compiler.h>
#include <arch/aarch64.h>
#include <mmu.h>
#include <alloc.h>
#include <pager.h>
#include <arch/mmu.h>
#include <assert.h>
#include <error.h>
#include <string.h>
#include <init.h>
#include <arch/barrier.h>
#include <arch/cache.h>

uint32_t bootstrap_pagetable_inited __data = 0;
uint64_t *bootstrap_pagetable_allocp __data = NULL;
uint8_t bootstrap_pagetable[PAGE_SIZE * 50] __aligned(PAGE_SIZE) __data = { 0 };
const uint64_t reloc_offset;

#define FLAT_MAPPING_AREA_VA 0x100000000ULL

struct mmu_table *s2pt_alloc(uint8_t va_bit)
{
	struct mmu_table *ret;

	ret = malloc(sizeof(struct mmu_table));
	if (ret == NULL)
		return NULL;

	if (va_bit > 48) {
		free(ret);
		return NULL;
	} else if (va_bit > 43) {
		ret->concat = 0;            // (43, 48]
		ret->level = 0;
	} else if (va_bit > 39) {
		ret->concat = va_bit - 39;  // (39, 43]
		ret->level = 1;
	} else if (va_bit > 34) {
		ret->concat = 0;            // (34, 39]
		ret->level = 1;
	} else if (va_bit > 30) {
		ret->concat = va_bit - 30;  // (30, 34]
		ret->level = 2;
	} else if (va_bit > 24) {
		ret->concat = 0;            // (24, 30]
		ret->level = 2;
	} else {
		free(ret);
		return NULL;
	}

	ret->va_bit = va_bit;
	ret->stage = 2;
	ret->pt = NULL;
	return ret;
}

static void pt_recursive_free(struct pt_entry *pt, uint8_t level, uint8_t concat)
{
	if (level != 3) {
		for (uint32_t i = 0; i < (PAGE_SIZE << concat) / sizeof(struct pt_entry); i++) {
			if ((pt[i].v & PT_Lx_VALID) && (pt[i].v & PT_Lx_TABLE))
				pt_recursive_free((struct pt_entry *) phys_to_virt(pt[i].v & PT_Lx_NEXTLEVEL_MASK), level + 1, 0);
		}
	}

	free_pages(pt, 1 << concat);
}

/**
 * Set a S2 page table entry according to vma
 * Caller must make sure that vma cover whole entry
 */
static void pt_populate_entry_atomic(struct pt_entry *entry, vaddr_t va, struct vm_area *vma, uint8_t stage, uint8_t level)
{
	assert(stage == 1 || stage == 2);
	if (!vma->valid)
		entry->v = 0;
	else if (vma->forbidden)
		entry->v = 0x8000000000000000ULL;
	else if (stage == 2) {
		if (level == 3) {
			entry->v = PT_L3_VALID |
			           PT_L3_AF | PT_L3_SH_INNER |
			           (vma->ro ? PT_L3_S2AP_RO : PT_L3_S2AP_RW) |
			           (vma->device ? PT_L3_S2ATTR_DEVICE : (vma->nocache ? PT_L3_S2ATTR_NORMAL_NC : PT_L3_S2ATTR_NORMAL)) |
			           (vma->xn ? PT_L3_XN : 0) |
			           ((va - vma->va + vma->pa) & PT_L3_PA_MASK);
		} else {
			entry->v = PT_Lx_VALID | PT_Lx_BLOCK |
			           PT_L3_AF | PT_L3_SH_INNER |
			           (vma->ro ? PT_L3_S2AP_RO : PT_L3_S2AP_RW) |
			           (vma->device ? PT_L3_S2ATTR_DEVICE : (vma->nocache ? PT_L3_S2ATTR_NORMAL_NC : PT_L3_S2ATTR_NORMAL)) |
			           (vma->xn ? PT_L3_XN : 0) |
			           ((va - vma->va + vma->pa) & PT_L3_PA_MASK);
		}
	} else {
		if (level == 3) {
			entry->v = PT_L3_VALID |
			           PT_L3_AF | PT_L3_SH_INNER |
			           (vma->ro ? PT_L3_AP_EL2_R : PT_L3_AP_EL2_RW) |
			           (vma->device ? PT_L3_ATTR_DEVICE : (vma->nocache ? PT_L3_ATTR_NORMAL_NC : PT_L3_ATTR_NORMAL)) |
			           (vma->xn ? PT_L3_XN : 0) |
			           ((va - vma->va + vma->pa) & PT_L3_PA_MASK);
		} else {
			entry->v = PT_Lx_VALID | PT_Lx_BLOCK |
			           PT_L3_AF | PT_L3_SH_INNER |
			           (vma->ro ? PT_L3_AP_EL2_R : PT_L3_AP_EL2_RW) |
			           (vma->device ? PT_L3_ATTR_DEVICE : (vma->nocache ? PT_L3_ATTR_NORMAL_NC : PT_L3_ATTR_NORMAL)) |
			           (vma->xn ? PT_L3_XN : 0) |
			           ((va - vma->va + vma->pa) & PT_L3_PA_MASK);
		}
	}
}

static int pt_populate_entry(struct pt_entry *entry, vaddr_t va, struct vm_area *vma, uint8_t overwrite, uint8_t stage, uint8_t level)
{
	uint32_t shift = (3 - level) * 9 + 12;
	assert((vma->va & (PAGE_SIZE - 1)) == 0);
	assert((vma->pa & (PAGE_SIZE - 1)) == 0);
	assert((vma->size & (PAGE_SIZE - 1)) == 0);
	assert(vma->va < va + (1UL << shift));
	assert(vma->va + vma->size > va);
	assert(stage == 1 || stage == 2);

	if (vma->va <= va && vma->va + vma->size >= va + (1ULL << shift) && (vma->va & ((1ULL << shift) - 1)) == (vma->pa & ((1ULL << shift) - 1))) {
		// VMA cover the whole entry and aligned --use huge page
		if (overwrite || entry->v == 0) {
			// If caller want overwriting, or the entry is not valid, set it atomically
			// Else, the code below will handle recursive populating and block entry spliting
			if (level != 3 && (entry->v & PT_Lx_VALID) && (entry->v & PT_Lx_TABLE))
				pt_recursive_free((struct pt_entry *) phys_to_virt(entry->v & PT_Lx_NEXTLEVEL_MASK), level + 1, 0);
			pt_populate_entry_atomic(entry, va, vma, stage, level);
			return 0;
		}
		if (!overwrite && level == 3)
			// Reach the last level, and won't overwrite
			return 0;
	}
	if (level == 3) {
		EMSG("Invalid vma, not aligned (va 0x%lx pa 0x%lx size 0x%lx)\n", vma->va, vma->pa, vma->size);
		return -EINVAL;
	} else {
		struct pt_entry *pt = NULL;
		int alloc = 0;
		if (!(entry->v & PT_Lx_VALID)) {
			// Entry not used
			alloc = 1;
			pt = alloc_pages(1);
			if (pt == NULL) {
				EMSG("Out of memory");
				return -ENOMEM;
			}
			memset(pt, 0, PAGE_SIZE);//
		} else if (!(entry->v & PT_Lx_TABLE)) {
			// Going to overwrite a block entry
			if (!overwrite)
				return 0;

			// Need to split a block entry
			alloc = 1;
			pt = alloc_pages(1);//
			if (pt == NULL) {
				EMSG("Out of memory");
				return -ENOMEM;
			}
			if (level + 1 == 3) {
				for (vaddr_t i = 0; i < PAGE_SIZE / sizeof(struct pt_entry); i++) {
					pt[i].v = PT_L3_VALID |
					          (entry->v & (PT_Lx_UPPER_ATTR_MASK | PT_Lx_LOWER_ATTR_MASK)) |
					          ((entry->v & PT_Lx_PA_MASK) + (i << (shift - 9)));
				}
			} else {//level == 1
				for (vaddr_t i = 0; i < PAGE_SIZE / sizeof(struct pt_entry); i++) {
					pt[i].v = PT_Lx_VALID | PT_Lx_BLOCK |
					          (entry->v & (PT_Lx_UPPER_ATTR_MASK | PT_Lx_LOWER_ATTR_MASK)) |
					          ((entry->v & PT_Lx_PA_MASK) + (i << (shift - 9)));
				}
			}
		} else {
			// Entry contains an allocated next level pt
			pt = (struct pt_entry *) phys_to_virt(entry->v & PT_Lx_NEXTLEVEL_MASK);
		}

		int ret;
		vaddr_t start = va, end = va + (1ULL << shift);
		if (start < vma->va)
			start = vma->va;
		if (end > vma->va + vma->size)
			end = vma->va + vma->size;
		start -= va;
		end -= va;
		shift -= 9;
		for (vaddr_t i = start >> shift; i < ROUNDUP(end, 1ULL << shift) >> shift; i++) {
			if ((ret = pt_populate_entry(&pt[i], va + (i << shift), vma, overwrite, stage, level + 1)) != 0) {
				if (alloc)
					pt_recursive_free(pt, level + 1, 0);
				return ret;
			}
		}
		if (alloc) {
			entry->v = PT_Lx_VALID | PT_Lx_TABLE |
			           virt_to_phys((vaddr_t) pt);
		}
	}

	return 0;
}
/*tww: it will split the huge page if it is necessary (e.g, set 4k page ro)*/
static int _mmu_apply_vma(struct mmu_table *table, struct vm_area *vma, uint8_t overwrite)
{
	uint8_t alloc = 0;
	struct pt_entry *pt = NULL;
	int ret;
	if (vma == NULL) {
		EMSG("vma == NULL\n");
		return -EINVAL;
	}
	if (mmu_check(table) != 0) {
		EMSG("Invalid MMU table\n");
		return -EINVAL;
	}

	if (table->pt == NULL) {
		alloc = 1;
		pt = alloc_pages_aligned(1U << table->concat, PAGE_SHIFT + table->concat);
		if (pt == NULL) {
			EMSG("Out of memory\n");
			ret = -ENOMEM;
			goto error;
		}
		memset(pt, 0, PAGE_SIZE << table->concat);
	} else
		pt = table->pt;

	vaddr_t va;
	uint32_t shift = (3 - table->level) * 9 + 12;
	if ((vma->size & (PAGE_SIZE - 1)) != 0 ||
	    (vma->va & (PAGE_SIZE - 1)) != 0 ||
	    (vma->pa & (PAGE_SIZE - 1)) != 0) {
		EMSG("Invalid vma, not aligned (pa 0x%lx va 0x%lx size 0x%lx)\n", vma->pa, vma->va, vma->size);
		ret = -EINVAL;
		goto error;
	}
	if (vma->va + vma->size > (1ULL << table->va_bit)) {
		EMSG("Invalid vma, too large (pa 0x%lx va 0x%lx size 0x%lx)\n", vma->pa, vma->va, vma->size);
		ret = -EINVAL;
		goto error;
	}
	for (vaddr_t i = vma->va >> shift; i < ROUNDUP(vma->va + vma->size, 1ULL << shift) >> shift; i++) {
		if ((ret = pt_populate_entry(&pt[i], i << shift, vma, overwrite, table->stage, table->level)) != 0)
			goto error;
	}

	if (alloc)
		table->pt = pt;
	return 0;

error:
	if (alloc)
		pt_recursive_free(pt, table->level, table->concat);
	return ret;
}

int mmu_apply_vma(struct mmu_table *table, struct vm_area *vma)
{
	return _mmu_apply_vma(table, vma, 1);
}
/*not overwrite*/
int mmu_apply_vma_nooverwrite(struct mmu_table *table, struct vm_area *vma)
{
	return _mmu_apply_vma(table, vma, 0);
}

static struct pt_entry *_pt_fork(struct pt_entry *pt, uint8_t level, uint8_t concat)
{
	if (pt == NULL)
		return NULL;
	struct pt_entry *new_pt = alloc_pages_aligned(1U << concat, PAGE_SHIFT + concat);
	if (level == 3)
		memcpy(new_pt, pt, PAGE_SIZE << concat);
	else {
		for (vaddr_t i = 0; i < (1ULL << (9 + concat)); i++) {
			new_pt[i] = pt[i];
			if ((pt[i].v & PT_Lx_VALID) && (pt[i].v & PT_Lx_TABLE)) {
				struct pt_entry *sub_pt = _pt_fork((struct pt_entry *) phys_to_virt(pt[i].v & PT_Lx_NEXTLEVEL_MASK), level + 1, 0);
				if (sub_pt == NULL) {
					for (vaddr_t j = 0; j < i; j++) {
						if ((pt[j].v & PT_Lx_VALID) && (pt[j].v & PT_Lx_TABLE))
							pt_recursive_free((struct pt_entry *) phys_to_virt(pt[j].v & PT_Lx_NEXTLEVEL_MASK), level + 1, 0);
					}
					free_pages(pt, 1U << concat);
					return NULL;
				}
				assert((virt_to_phys((vaddr_t) sub_pt) & ~PT_Lx_NEXTLEVEL_MASK) == 0);
				new_pt[i].v &= ~PT_Lx_NEXTLEVEL_MASK;
				new_pt[i].v |= virt_to_phys((vaddr_t) sub_pt) & PT_Lx_NEXTLEVEL_MASK;
			}
		}
	}
	return new_pt;
}

int mmu_check(struct mmu_table *table)
{
	if (table == NULL)
		return -EINVAL;
	if (table->stage == 2) {
		if (table->va_bit <= 24 || table->va_bit > 48) {
			EMSG("Invalid va_bit %u for stage 2\n", table->va_bit);
			return -EINVAL;
		}
		if (table->concat < 0 || table->concat > 4) {
			EMSG("Invalid concat %u for stage 2\n", table->concat);
			return -EINVAL;
		}
		if (table->va_bit > (3 - table->level + 1) * 9 + 12 && table->va_bit != (3 - table->level + 1) * 9 + 12 + table->concat) {
			EMSG("Inconsistent level/va_bit of s2pt\n");
			return -EINVAL;
		}
	} else if (table->stage == 1) {
		if (table->va_bit <= 24 || table->va_bit > 48) {
			EMSG("Invalid va_bit %u for stage 1\n", table->va_bit);
			return -EINVAL;
		}
		if (table->concat != 0) {
			EMSG("Invalid concat %u for stage 1\n", table->concat);
			return -EINVAL;
		}
		if (table->va_bit > (3 - table->level + 1) * 9 + 12) {
			EMSG("Invalid init level %u for va_bit %u in stage 1\n", table->level, table->va_bit);
			return -EINVAL;
		}
	} else
		return -EINVAL;
	return 0;
}

int mmu_populate(struct mmu_table *table, struct vm_area *vma_list)
{
	int ret;
	struct pt_entry *pt = NULL;
	if ((ret = mmu_check(table)) != 0)
		goto error;

	if (table->pt != NULL)
		pt_recursive_free(table->pt, table->level, table->concat);
	table->pt = NULL;

	struct vm_area *vma = vma_list;
	while (vma != NULL) {
		if ((ret = mmu_apply_vma(table, vma)) != 0)
			goto error;
		vma = list_next_entry(vma, list);
		if (vma == vma_list)
			break;
	}

	return 0;

error:
	return ret;
}

int s2pt_apply(struct mmu_table *table, uint8_t vmid)
{
	if (mmu_check(table) != 0)
		return -EINVAL;
	if (table->stage != 2)
		return -EINVAL;
	if (table->pt == NULL) {
		write_vttbr_el2(0);
		write_hcr_el2(read_hcr_el2() & ~AARCH64_HCR_VM);
		return 0;
	}
	write_vttbr_el2((((uint64_t) vmid) << AARCH64_VTTBR_VMID_SHIFT) | virt_to_phys((vaddr_t) table->pt));
	write_vtcr_el2((64 - table->va_bit) |
	               ((2 - table->level) << AARCH64_VTCR_SL0_SHIFT) |
	               AARCH64_VTCR_IRGN0_WBWA |
	               AARCH64_VTCR_ORGN0_WBWA |
	               AARCH64_VTCR_SH0_INNER |
	               AARCH64_VTCR_TG0_4K |
	               (AARCH64_ID_AA64MMFR0_PARANGE(read_id_aa64mmfr0_el1()) << AARCH64_VTCR_PS_SHIFT) |
	               AARCH64_VTCR_RES);
	write_hcr_el2(read_hcr_el2() | AARCH64_HCR_VM);
//	dsb();
//	isb();
//	tlbi("vmalls12e1");
//	dsb();
//	isb();
	return 0;
}

struct mmu_table *s2pt_export(void)
{
	if (!(read_hcr_el2() & AARCH64_HCR_VM))
		return NULL;

	struct mmu_table *ret = malloc(sizeof(struct mmu_table));
	if (ret == NULL)
		return NULL;
	ret->va_bit = 64 - AARCH64_VTCR_T0SZ(read_vtcr_el2());
	ret->level = 2 - AARCH64_VTCR_SL0(read_vtcr_el2());
	if (ret->va_bit > (3 - ret->level + 1) * 9 + 12)
		ret->concat = ret->va_bit - ((3 - ret->level + 1) * 9 + 12);
	else
		ret->concat = 0;
	ret->stage = 2;
	ret->pt = (struct pt_entry *) phys_to_virt(AARCH64_VTTBR_BADDR(read_vttbr_el2()));
	return ret;
}

void mmu_free(struct mmu_table *table)
{
	if (table->pt != NULL)
		pt_recursive_free(table->pt, table->level, table->concat);
	free(table);
}

struct mmu_table *mmu_fork(struct mmu_table *table)
{
	if (table == NULL)
		return NULL;

	struct mmu_table *ret = malloc(sizeof(struct mmu_table));
	if (ret == NULL)
		return NULL;

	ret->va_bit = table->va_bit;
	ret->level = table->level;
	ret->stage = table->stage;
	ret->concat = table->concat;
	ret->pt = _pt_fork(table->pt, table->level, table->concat);
	if (ret->pt == NULL) {
		free(ret);
		return NULL;
	}
	return ret;
}
/*tww: allocate s1pt for hypervisor or vm*/
struct mmu_table *s1pt_alloc(uint8_t va_bit)
{
	struct mmu_table *ret;

	ret = malloc(sizeof(struct mmu_table));
	if (ret == NULL)
		return NULL;

	if (va_bit > 48) {
		EMSG("Invalid va_bit %u\n", va_bit);
		free(ret);
		return NULL;
	} else if (va_bit > 39)
		ret->level = 0;  // (39, 48]
	else if (va_bit > 30)
		ret->level = 1;  // (30, 39]
	else if (va_bit > 24)
		ret->level = 2;  // (24, 30]
	else {
		EMSG("Invalid va_bit %u\n", va_bit);
		free(ret);
		return NULL;
	}

	ret->concat = 0;
	ret->va_bit = va_bit;
	ret->stage = 1;
	ret->pt = NULL;
	return ret;
}

int s1pt_apply(struct mmu_table *table)
{
	if (mmu_check(table) != 0)
		return -EINVAL;
	if (table->stage != 1)
		return -EINVAL;
	if (table->pt == NULL)
		return -EINVAL;
	dsb(sy);
	isb();
	write_ttbr0_el2(virt_to_phys((vaddr_t) table->pt));
	write_tcr_el2((64 - table->va_bit) |
	              AARCH64_TCR_IRGN0_WBWA |
	              AARCH64_TCR_ORGN0_WBWA |
	              AARCH64_TCR_SH0_INNER |
	              AARCH64_TCR_TG0_4K |
	              (AARCH64_ID_AA64MMFR0_PARANGE(read_id_aa64mmfr0_el1()) << AARCH64_VTCR_PS_SHIFT));
	dsb(sy);
	isb();
	tlbi("alle2");
	dsb(sy);
	isb();
	return 0;
}

struct mmu_table *s1pt_export(void)
{
	if (!(read_sctlr_el2() & AARCH64_SCTLR_M))
		return NULL;

	struct mmu_table *ret = malloc(sizeof(struct mmu_table));
	if (ret == NULL)
		return NULL;
	ret->va_bit = 64 - AARCH64_TCR_T0SZ(read_tcr_el2());
	if (ret->va_bit > 48) {
		free(ret);
		return NULL;
	} else if (ret->va_bit > 39)
		ret->level = 0;  // (39, 48]
	else if (ret->va_bit > 30)
		ret->level = 1;  // (30, 39]
	else if (ret->va_bit > 24)
		ret->level = 2;  // (24, 30]
	else {
		free(ret);
		return NULL;
	}
	ret->concat = 0;
	ret->stage = 1;
	ret->pt = (struct pt_entry *) phys_to_virt(AARCH64_TTBR0_BADDR(read_ttbr0_el2()));
	return ret;
}

static int _mmu_traverse(struct mmu_table *table, struct pt_entry *pt, vaddr_t va,
                         uint8_t level, mmu_traverse_func_t *func, void *arg)
{
	int ret;
	vaddr_t shift = (3 - level) * 9 + 12;
	if (level == 3) {
		for (vaddr_t i = 0; i < PAGE_SIZE / sizeof(struct pt_entry); i++) {
			if ((pt[i].v & PT_L3_VALID) == PT_L3_VALID) {
				if ((ret = func(table, &pt[i], level, pt[i].v & PT_L3_PA_MASK, va + (i << shift), arg)) != 0)
					return ret;
			}
		}
	} else {
		for (vaddr_t i = 0; i < PAGE_SIZE / sizeof(struct pt_entry); i++) {
			if (pt[i].v & PT_Lx_VALID && !(pt[i].v & PT_Lx_TABLE)) {
				if ((ret = func(table, &pt[i], level, pt[i].v & PT_Lx_PA_MASK, va + (i << shift), arg)) != 0)
					return ret;
			} else if (pt[i].v & PT_Lx_VALID) {
				if ((ret = _mmu_traverse(table, (struct pt_entry *) phys_to_virt(pt[i].v & PT_Lx_NEXTLEVEL_MASK),
				                         va + (i << shift), level + 1, func, arg)) != 0)
					return ret;
			}
		}
	}
	return 0;
}

int mmu_traverse(struct mmu_table *table, mmu_traverse_func_t *func, void *arg)
{
	int ret;
	if (mmu_check(table) != 0)
		return -EINVAL;
	if (func == NULL)
		return -EINVAL;
	if (table->pt == NULL)
		return 0;

	struct pt_entry *pt = table->pt;
	vaddr_t shift = (3 - table->level) * 9 + 12;
	for (vaddr_t i = 0; i < ((PAGE_SIZE / sizeof(struct pt_entry)) << table->concat); i++) {
		if (pt[i].v & PT_Lx_VALID && !(pt[i].v & PT_Lx_TABLE)) {
			if ((ret = func(table, &pt[i], table->level, pt[i].v & PT_Lx_PA_MASK, i << shift, arg)) != 0)
				return ret;
		} else if (pt[i].v & PT_Lx_VALID) {
			if ((ret = _mmu_traverse(table, (struct pt_entry *) phys_to_virt(pt[i].v & PT_Lx_NEXTLEVEL_MASK),
			                         i << shift, table->level + 1, func, arg)) != 0)
				return ret;
		}
	}
	return 0;
}
/*tww: gpa, hpa->virtual addr (gpa==hpa)*/
vaddr_t phys_to_virt(paddr_t x)
{
	if (x + reloc_offset >= HYPERVISOR_RAM_VA && x + reloc_offset < HYPERVISOR_RAM_VA + HYPERVISOR_RAM_SIZE)
		return x + reloc_offset;
	else
		return x + FLAT_MAPPING_AREA_VA;
}

paddr_t virt_to_phys(vaddr_t x) {
	if (x >= HYPERVISOR_RAM_VA && x < HYPERVISOR_RAM_VA + HYPERVISOR_RAM_SIZE)
		return x - reloc_offset;
	else if (x >= FLAT_MAPPING_AREA_VA)
		return x - FLAT_MAPPING_AREA_VA;
	else
		panic("Unknown VA 0x%lx\n", x);
}

void *ioremap(vaddr_t base, size_t size) {
	struct vm_area vma;
	vma.va = phys_to_virt(base);
	vma.pa = base;
	vma.size = size;
	vma.valid = 1;
	vma.ro = 0;
	vma.xn = 1;
	vma.nocache = 0;
	vma.device = 1;
	vma.forbidden = 0;
	if (mmu_apply_vma(s1pt, &vma) == 0)
		return (void *) phys_to_virt(base);
	else
		return NULL;
}

static int _mmu_dump(struct mmu_table *table, struct pt_entry *entry, uint8_t level, paddr_t pa,
                     vaddr_t va, void *arg __unused)
{
	uint64_t size = 1ULL << ((3 - level) * 9 + 12);
	DMSG("0x%016lx-0x%016lx: 0x%016lx\n", va, va + size, entry->v);
	return 0;
}

void mmu_dump(struct mmu_table *table)
{
	DMSG("MMU table stage %u (parameter %s)\n", table->stage, (mmu_check(table) == 0) ? "valid" : "invalid");
	DMSG("VA %ubit, start level %u, concat %u\n", table->va_bit, table->level, table->concat);
	mmu_traverse(table, _mmu_dump, NULL);
}

int pte_valid(struct mmu_table *table, uint8_t level, struct pt_entry *entry)
{
	switch (table->stage) {
	case 1:
	case 2:
		switch (level) {
		case 0:
		case 1:
		case 2:
			return (entry->v & PT_Lx_VALID) == PT_Lx_VALID;
		case 3:
			return (entry->v & PT_L3_VALID) == PT_L3_VALID;
		default:
			return -EINVAL;
		}
	default:
		return -EINVAL;
	}
}

int pte_writable(struct mmu_table *table, uint8_t level, struct pt_entry *entry)
{
	switch (table->stage) {
	case 1:
		switch (level) {
		case 0:
		case 1:
		case 2:
		case 3:
			return pte_valid(table, level, entry) && !(entry->v & PT_L3_AP_RO);
		default:
			return -EINVAL;
		}
	case 2:
		switch (level) {
		case 0:
		case 1:
		case 2:
		case 3:
			return pte_valid(table, level, entry) && (entry->v & PT_L3_S2AP_WO);
		default:
			return -EINVAL;
		}
	default:
		return -EINVAL;
	}
}

int pte_executable(struct mmu_table *table, uint8_t level, struct pt_entry *entry)
{
	switch (table->stage) {
	case 1:
		switch (level) {
		case 0:
		case 1:
		case 2:
		case 3:
			return pte_valid(table, level, entry) && !(entry->v & PT_L3_XN);
		default:
			return -EINVAL;
		}
	case 2:
		switch (level) {
		case 0:
		case 1:
		case 2:
		case 3:
			return pte_valid(table, level, entry) && (entry->v & PT_L3_XN);
		default:
			return -EINVAL;
		}
	default:
		return -EINVAL;
	}
}

struct mmu_table *s1pt = NULL;
/*tww init 3 level s1pt for hypervisor (39bit)*/
static int init_s1pt(void)
{
	if (s1pt == NULL) {
		struct vm_area vma_hyp, vma_uart, vma_flat;

		vma_hyp.va = HYPERVISOR_RAM_VA;
		vma_hyp.pa = virt_to_phys(HYPERVISOR_RAM_VA);
		vma_hyp.size = HYPERVISOR_RAM_SIZE;
		vma_hyp.valid = 1;
		vma_hyp.ro = 0;
		vma_hyp.xn = 0;
		vma_hyp.nocache = 0;
		vma_hyp.device = 0;
		vma_hyp.forbidden = 0;
		list_init(&vma_hyp.list);

#ifdef UART_BASE
		vma_uart.va = ROUNDDOWN(UART_BASE, PAGE_SIZE);
		vma_uart.pa = ROUNDDOWN(UART_BASE, PAGE_SIZE);
		vma_uart.size = ROUNDUP(UART_BASE + UART_SIZE, PAGE_SIZE) - ROUNDDOWN(UART_BASE, PAGE_SIZE);
		vma_uart.valid = 1;
		vma_uart.ro = 0;
		vma_uart.xn = 0;
		vma_uart.nocache = 0;
		vma_uart.device = 1;
		vma_uart.forbidden = 0;
		list_init(&vma_hyp.list);
		list_add_tail(&vma_uart.list, &vma_hyp.list);
#endif

		vma_flat.va = FLAT_MAPPING_AREA_VA;
		vma_flat.pa = 0;
		vma_flat.size = 0x1000000000ULL;
		vma_flat.valid = 1;
		vma_flat.ro = 0;
		vma_flat.xn = 1;
		vma_flat.nocache = 0;
		vma_flat.device = 0;
		vma_flat.forbidden = 0;
		list_init(&vma_flat.list);
		list_add_tail(&vma_flat.list, &vma_hyp.list);

		//s1pt = s1pt_alloc(48);
		s1pt = s1pt_alloc(39);//3 level
		if (s1pt == NULL) {
			EMSG("Allocate s1pt failed\n");
			return -1;
		}
		if (mmu_populate(s1pt, &vma_hyp) != 0) {
			EMSG("Populate s1pt failed\n");
			return -1;
		}
	}

	if (s1pt_apply(s1pt) != 0) {
		EMSG("Apply s1pt failed\n");
		return -1;
	}
	return 0;
}
register_init(arch, init_s1pt);
