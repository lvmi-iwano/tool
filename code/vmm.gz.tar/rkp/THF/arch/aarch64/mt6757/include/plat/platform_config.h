#ifndef HIKEY_PLATFORM_CONFIG_H_
#define HIKEY_PLATFORM_CONFIG_H_

#define NUM_CORES 8
#define STACK_SIZE_SHIFT 13
#define STACK_SIZE (1 << STACK_SIZE_SHIFT)

#define HYPERVISOR_RAM_SIZE (4 * 1024 * 1024)

// ======== Devices ========

// UART
#define UART0_BASE 0x11002000
#define UART_BASE UART0_BASE
#define UART_SIZE 0x1000

#endif
