#include <hypervisor.h>
#include <alloc.h>
#include <arch/aarch64.h>
#include <compiler.h>
#include <assert.h>
#include <string.h>
#include <mmu.h>
#include <error.h>
#include <init.h>
#include <arch/vmm.h>
#include <arch/atomic.h>
#include <smc.h>
#include <arch/mmu.h>
#include <pager.h>
#ifdef HAS_GIC
#include <drivers/gic.h>
#endif
#include <plugin.h>
#include <vdevice.h>
#include <plat/platform_config.h>
#include <arch/barrier.h>
#include <arch/cache.h>
#include <arch/io.h>
#include <arch/spinlock.h>

#define MAX_SECTIONS 4 //maximum recored sections
/*Readme: this file defines the handlers of vm exits
 */
/*we protect kernel contents:
 *code: ro x(s2pt), user unaccessable(s1pt) 
 *  vdso code: user accessable, rx  [vdso_start, vdso_end)
 *rodata: ro x(s2pt), user unaccessable(s1pt)
 *
 *data/bss: rw nx (s2pt), user unaccessable(s1pt)
 *  empty_zero_page: sometimes it is used as a page table, kernel and user have different permission for the page, protect it using s1pt. rwx (s2pt) kernel: rw,pxn(s1pt) user:ro,x(s1pt)
 *  vdso data: user accessable, rw, it is a page
 *all page tables:ro nx(s2pt), user unaccessable(s1pt)
    if the empty_zero_page is pt, set s2pt ro and x, kenrel:pxn(s1pt), user:ro,x
 *they can not be accessed and executed in user space, except some share memory
 */
/*pite table 
 *p:0 not uesed
 *p:1 pt:1 pt
 *p:1 pt:0 not pt , code/rodata: ap == 1, data/bss: ap == 2  zero_page: ap == 0
 * */
/*panic case: 1. can not handle the unsupported vm exits
 * 2. operation fail: gva->gpa failed, allocate pit table failed
 * 3. unreasonable situlation:
 *    page is not aligned
 *    zero page override ro buffer
 *    bad page table entry
 *    level of pt is not between 1 and 3 //
 *    pt is in kernel executable range //
 *    data abort: data size is not 64 bytes //
 *    write unreasonable value to vmemctrl registers //
 */
struct trap_handler_list {
	struct list_head list;
	trap_handler_t *handler;
	void *arg;
};
//should be same as the data structure in linux
typedef struct rtkp_info {
    uint64_t _text;
    uint64_t _etext;
    uint64_t _srodata;
    uint64_t _erodata;//ro
    uint64_t _sdata;
    uint64_t _edata;//rw
    uint64_t _bss_start;
    uint64_t _bss_stop;//rw
    uint64_t swapper_pg_dir;
    uint64_t vdso_start;//start physical address of vdso code pages
    uint64_t vdso_end;
    uint64_t vdso_data;
    uint64_t phys_offset;  
    uint64_t high_memory;//pa of high_memory, the pa in direct mapping area should be smaller than this value
    uint64_t page_offset;
    uint64_t empty_zero_page;
    uint64_t ro_buffer_va;
    uint64_t ro_buffer_size;
} rtkp_info;
//section:[va_s,va_e) [pa_s,pa_e)
typedef struct section_info {
    uint64_t va_s;
    uint64_t va_e;
    uint64_t pa_s;
    uint64_t pa_e;
    uint8_t ap; //access permission
} section_info;
typedef struct nx_section_info {
    uint64_t pa_s;
    uint64_t pa_e;
} nx_section_info;
/*ro_buffer: [ro_buffer_pa_s, ro_buffer_pa_e)*/
static uint64_t ro_buffer_pa_s, ro_buffer_pa_e;
static uint64_t ro_buffer_va_s, ro_buffer_va_e;
static uint64_t ttbr1_el1 = 0;
static rtkp_info kernel_info;
static struct vcpu *next_vcpu[NUM_CORES] = { NULL };
static uint8_t rtkp_start = 0;
static uint64_t phys_offset_pfn = 0;
static spinlock_t pit_lock = SPINLOCK_INITIALIZER;/*FIXME use different lock for each range*/
static uint8_t num_section = 0;
static uint8_t num_nx_section = 0;
static section_info sections[MAX_SECTIONS];//store the info of kernel sections
static nx_section_info nx_sections[MAX_SECTIONS];//store the pa of kernel nx sections

/*for 64 bit kernel, the page table page is located in the direct map area, 
 *so we can do gpa vs gva conversion
 *@phys_offset: the gpa of the start of memory
 *@page_offset: the virtual address of the start of the kernel image
 */
vaddr_t phys_to_virt_linux(paddr_t gpa, uint64_t phys_offset, uint64_t page_offset) {
   return (vaddr_t)(gpa - phys_offset) | page_offset; 
}
//Note we only consider one gva for one page table, no double mapping
//only consider one vm now
/*invalid stage 1 and stage 2 tlb in el1 using gvn and gpn*/
void invalid_tlb_s12(uint64_t gvn, uint64_t gpn) {
     tlbiva(vaae1is, gvn);
     tlbiva(ipas2e1is, gpn);
	 dsb(sy);
}
void invalid_tlb_s2(uint64_t gpn) {
     tlbiva(ipas2e1is, gpn);
	 dsb(sy);
}

static int vcpu_gva_to_gpa_elx(struct vcpu *vcpu, uint64_t va, uint64_t *pa, uint8_t el)
{
    if (vcpu->sysreg.ttbr0_el1 == read_ttbr0_el1() && vcpu->sysreg.ttbr1_el1 == read_ttbr1_el1()) {
        switch (el) {
            case 1:
                asm volatile ("at s1e1r, %0"::"r"(va));
                break;
            case 0:
                asm volatile ("at s1e0r, %0"::"r"(va));
                break;
            default:
                return -EINVAL;
        }
        if (read_par_el1() & AARCH64_PAR_F) {
            *pa = read_par_el1();
            return -EIO;
        }
        *pa = (read_par_el1() & AARCH64_PAR_PA_MASK) | (va & (PAGE_SIZE - 1));
        return 0;
    } else {
        uint64_t ttbr0 = read_ttbr0_el1(), ttbr1 = read_ttbr1_el1();
        int ret;
        write_ttbr0_el1(vcpu->sysreg.ttbr0_el1);//tww: the status of cpu is newer than vcpu
        write_ttbr1_el1(vcpu->sysreg.ttbr1_el1);
        ret = vcpu_gva_to_gpa_elx(vcpu, va, pa, el);
        write_ttbr0_el1(ttbr0);
        write_ttbr1_el1(ttbr1);
        return ret;
    }
}

int vcpu_gva_to_gpa_el1(struct vcpu *vcpu, uint64_t va, uint64_t *pa)
{
    return vcpu_gva_to_gpa_elx(vcpu, va, pa, 1);
}

int vcpu_gva_to_gpa_el0(struct vcpu *vcpu, uint64_t va, uint64_t *pa)
{
    return vcpu_gva_to_gpa_elx(vcpu, va, pa, 0);
}

int vcpu_gva_to_gpa(struct vcpu *vcpu, uint64_t va, uint64_t *pa)
{
    if (vcpu_gva_to_gpa_el1(vcpu, va, pa) != 0 && vcpu_gva_to_gpa_el0(vcpu, va, pa) != 0)
        return -1;
    else
        return 0;
}

void vcpu_gva_to_gpa_try(struct vcpu *vcpu, uint64_t va, uint64_t *pa) {
   if (vcpu_gva_to_gpa(vcpu, va, pa) < 0) 
        panic("vcpu_gva_to_gpa failed\n");
}
/*Store the info of kenrel sections(text, rodata, data, bss). Do merge if two sections are adjacent for performance
 *@section_va: store the va of section
 *
 */
void store_section_info(struct vcpu *vcpu, rtkp_info *prtkp, section_info *sections, uint8_t *num_section, nx_section_info *nx_sections, uint8_t *num_nx_section) {
    section_info *sec = sections;
    nx_section_info *sec_nx = nx_sections;
    //text
    sec->ap = RO & 0x3;
    sec->va_s = (vaddr_t)(prtkp->_text);
    vcpu_gva_to_gpa_try(vcpu, (vaddr_t)(prtkp->_text), &(sec->pa_s));
    (*num_section)++;
    if ((vaddr_t)(prtkp->_etext) != (vaddr_t)(prtkp->_srodata)) {//sections are not adjacent
        sec->va_e = (vaddr_t)(prtkp->_etext);
        vcpu_gva_to_gpa_try(vcpu, (vaddr_t)(prtkp->_etext), &(sec->pa_e));
        sec++;
        //rodata
        sec->ap = RO & 0x3;
        sec->va_s = (vaddr_t)(prtkp->_srodata);
        vcpu_gva_to_gpa_try(vcpu, (vaddr_t)(prtkp->_srodata), &(sec->pa_s));
        (*num_section)++;
        DMSG("_etext 0x%lx != _srodata 0x%lx\n", (vaddr_t)(prtkp->_etext), (vaddr_t)(prtkp->_srodata));
    }
    sec->va_e = (vaddr_t)(prtkp->_erodata);
    vcpu_gva_to_gpa_try(vcpu, (vaddr_t)(prtkp->_erodata), &(sec->pa_e));
    sec++;
    //data
    sec->ap = NX & 0x3;
    sec->va_s = (vaddr_t)(prtkp->_sdata);
    vcpu_gva_to_gpa_try(vcpu, (vaddr_t)(prtkp->_sdata), &(sec->pa_s));
    vcpu_gva_to_gpa_try(vcpu, (vaddr_t)(prtkp->_sdata), &(sec_nx->pa_s));
    (*num_section)++;
    (*num_nx_section)++;
    if ((vaddr_t)(prtkp->_edata) != (vaddr_t)(prtkp->_bss_start)) {
        sec->va_e = (vaddr_t)(prtkp->_edata);
        vcpu_gva_to_gpa_try(vcpu, (vaddr_t)(prtkp->_edata), &(sec->pa_e));
        vcpu_gva_to_gpa_try(vcpu, (vaddr_t)(prtkp->_edata), &(sec_nx->pa_e));
        sec++;
        sec_nx++;
        //bss
        sec->ap = NX & 0x3;
        sec->va_s = (vaddr_t)(prtkp->_bss_start);
        vcpu_gva_to_gpa_try(vcpu, (vaddr_t)(prtkp->_bss_start), &(sec->pa_s));
        vcpu_gva_to_gpa_try(vcpu, (vaddr_t)(prtkp->_bss_start), &(sec_nx->pa_s));
        (*num_section)++;
        (*num_nx_section)++;
        DMSG("_edata 0x%lx != _bss_start 0x%lx\n", (vaddr_t)(prtkp->_edata), (vaddr_t)(prtkp->_bss_start));
    }
    sec->va_e = (vaddr_t)(prtkp->_bss_stop);
    vcpu_gva_to_gpa_try(vcpu, (vaddr_t)(prtkp->_bss_stop), &(sec->pa_e));
    sec_nx->pa_e = sec->pa_e;
}
/*To check if the address range is located in a kernel section, return 1 if it is
 *@range: [pa_s,pa_e]
 */
int8_t is_kernel_section(uint64_t pa_s, uint64_t pa_e, section_info *sections, uint8_t num_section)
{
    uint8_t i;
    for (i = 0; i < num_section; i++) {
       if ((pa_s >= sections[i].pa_s) && (pa_e < sections[i].pa_e)) 
            return 1;
    }
    return 0;
}
/*To check if the address of a page is located in a kernel nx section, return 1 if it is
 */
int8_t is_kernel_nx_section(uint64_t pa, nx_section_info *nx_sections, uint8_t num_nx_section)
{
    uint8_t i;
    for (i = 0; i < num_nx_section; i++) {
       if ((pa >= nx_sections[i].pa_s) && (pa < nx_sections[i].pa_e)) 
            return 1;
    }
    return 0;
}
/*set permission for page (gpa)
 *@type bit[2:0] xwr
 */
void set_memtype_in_s2pt(uint64_t gpa, uint64_t size, struct mmu_table *s2pt, uint8_t ro, uint8_t xn)
{
     struct vm_area vma;
     vma.va = gpa;//should align
     vma.pa = gpa;
     vma.size = size;
	 vma.valid = 1;//make entry valid
	 vma.ro = ro;
	 vma.xn = xn;
	 vma.nocache = 0;
	 vma.device = 0;
     vma.forbidden = 0;
     if (mmu_apply_vma(s2pt, &vma) != 0) //will check the align for gpa
	    panic("Allow Dom0 access whole memory failed\n"); 
}
/*check if the entry is valid and points to the table*/
void check_entry(uint8_t level, struct pt_entry entry, int8_t *valid, int8_t *pto_table)
{
    if (level < 1 || level > 3){
        panic("check_entry fail level%hhd is invalid\n", level);
        return;
    }
    if (level == 3) {
        if (!(entry.v & 0x1))
            *valid = 0;
        else if (entry.v & 0x2) {
            *valid = 1;
            *pto_table = 0;
        }
        else 
            panic("bad lev3 entry 0x%lx\n", entry.v);
    } else {
        if (!(entry.v & 0x1))
            *valid = 0;
        else {
            *valid = 1;
            if (entry.v & PT_Lx_TABLE)
                *pto_table = 1;
            else
                *pto_table = 0;
        }
    }
    return;
}
/*check whether the addr is align with the size of @align*/
void check_align(uint64_t addr, uint64_t align) {
    assert(!(addr & (align - 1)));
}

void check_sections_align(rtkp_info *prtkp)
{
    check_align((vaddr_t)(prtkp->_text), PAGE_SIZE);
    check_align((vaddr_t)(prtkp->_etext), PAGE_SIZE);
    check_align((vaddr_t)(prtkp->_srodata), PAGE_SIZE);
    check_align((vaddr_t)(prtkp->_erodata), PAGE_SIZE);
    check_align((vaddr_t)(prtkp->_sdata), PAGE_SIZE);
    check_align((vaddr_t)(prtkp->_edata), PAGE_SIZE);
    check_align((vaddr_t)(prtkp->empty_zero_page), PAGE_SIZE);
    check_align((vaddr_t)(prtkp->_bss_start), PAGE_SIZE);
    check_align((vaddr_t)(prtkp->_bss_stop), PAGE_SIZE);
} 
/*traverse the kernel pt by gva and renturn the entry
 *@gvn: gvn of current pt page
 *@level: level of current pt page, first level can be 0,1,2.
 last level is always 3
 *@ptr: point to current pt
 */
struct pt_entry *traverse_page_table(uint64_t gvn, struct pt_entry *ptr, uint8_t *level)
{
   struct pt_entry* pt = NULL;
   uint32_t shift = (3 - *level) * 9;   
     
   if (*level > 3)
        return pt;
   pt = ptr + ((gvn >> shift) & 0x1FF);
   if (pt->v & PT_Lx_VALID) {
       if (*level == 3) {
            if (pt->v & 0x2)//point to 4k data page
                return pt;
            else {
                EMSG("lev3 invalid\n");
                return pt;
            }
       }
       else if (pt->v & PT_Lx_TABLE) {//point to next table
            (*level)++;
            return traverse_page_table(gvn, (struct pt_entry *) phys_to_virt(pt->v & PT_Lx_NEXTLEVEL_MASK), level); //gpa == hpa
       }
       else {//point to huge data page
         return pt;
       }
   }
   return pt;
}
/*debug tool:print contents of code page
 *@gpa: should align
 */
void print_page_contents(uint64_t gpa, uint32_t size, uint64_t* data) 
{
     if ((gpa & (PAGE_SIZE -1)) != 0)
        EMSG("not aligned 0x%lx\n", gpa);
     uint64_t *ptr = (uint64_t *) phys_to_virt(gpa);
     DMSG("page contents for gpa 0x%lx:\n",gpa);
     for (int n = 0; n < size; n+=8, ptr++) {
        if (ptr == data)
            DMSG("data-%d 0x%lx\n", n, *data);
        DMSG("%lx\n", *ptr);
     }
}

/*walk through the s2pt using gpn and return the entry 
 *@level: the level of the found entry,start form 1
 */
struct pt_entry* traverse_s2pt(uint64_t gpn, struct pt_entry *s2pt, uint8_t *level)
{
   struct pt_entry* pt = NULL;
   uint32_t shift = (3 - *level) * 9;   

   if (*level > 3)
        return pt;
   pt = s2pt + ((gpn >> shift) & 0x1FF);
   if (pt->v & PT_Lx_VALID) {
       if (*level == 3) {
            if (pt->v & 0x2) {//point to 4k data page
                return pt;
            }
            else {
                EMSG("lev3 invalid\n");
            }
       }
       else if (pt->v & PT_Lx_TABLE) {//point to next table
            (*level)++; 
            return traverse_s2pt(gpn, (struct pt_entry *) phys_to_virt(pt->v & PT_Lx_NEXTLEVEL_MASK), level); 
       }
       else {//huge page
            return pt;
       }
   }
   return pt;//invalid
}
/*check the whether the ap is set in the pt entry
 *@ptable: point to the first table of stage 1 or 2
 *@ap rw or read only
 *@lev: first level
*/
void check_after_set_ap(uint64_t pfn, struct pt_entry *ptable, uint8_t ap, uint8_t stage, uint8_t lev) 
{
    uint8_t level = lev;
    struct pt_entry* pt;
    uint8_t idx;
    if (stage == 1) //gvn
        pt = traverse_page_table(pfn, ptable, &level);
    else if (stage == 2)//gpn
        pt = traverse_s2pt(pfn, ptable, &level);
    if (!pt) {
        DMSG("invalid entry\n");
        return;
    }
    if (pt->v & PT_Lx_VALID) {
        if (level != 3 && pt->v & PT_Lx_TABLE) {
            DMSG("pto pt\n");
        }
        else if (level == 3 && !(pt->v & 0x2)) {
            DMSG("lev3 invalid\n");
        }
        else if (stage == 1) {//point to data
            //DMSG("in s1pt level %hhd pto gpn:0x%lx x-el0 %x x-el1 %x w %x r 1 el0-ac %lx entry 0x%lx\n", level, (pt->v >> (12 + (3- level) * 9)) & (0xfffffffff >> (3-level) * 9), !((pt->v >> 54) & 1), !((pt->v >> 53) & 1), !((pt->v >> 7) & 1), (pt->v >> 6) & 1, pt->v);
            idx = (pt->v >> 2) & 0x7;
            uint8_t attri = (read_mair_el2() >> (idx*8)) & 0xff;
            uint8_t attri_h = (attri >> 4) & 0xf;
            uint8_t attri_l = attri & 0xf;
            if (!attri_h) {
                DMSG("s1pt level %hhu gvn 0x%lx gpn 0x%lx Continu %lu nG %lu SH 0x%lx device memory idx %hhu attri-3:0 0x%hhx entry 0x%lx\n", level, pfn, (pt->v >> 12) & 0xfffffffff, (pt->v >> 52) & 1, (pt->v >> 11) & 1, (pt->v >> 8) & 3, idx, attri_l, pt->v);
            } else {
                DMSG("s1pt level %hhu gvn 0x%lx gpn 0x%lx Continu %lu nG %lu SH 0x%lx normal memory idx %hhu attri-7:4 0x%hhx 3:0 0x%hhx entry 0x%lx\n", level, pfn, (pt->v >> 12) & 0xfffffffff, (pt->v >> 52) & 1, (pt->v >> 11) & 1, (pt->v >> 8) & 3, idx, attri_h, attri_l, pt->v);
            }
        }
        else if (stage == 2) {
            //DMSG("s2pt ap %lu pto gpn:0x%lx lev%hhd mfn:0x%lx nx %lx\n", (pt->v >> 6) & 0x3, pfn, level, (pt->v >> (12 + (3- level) * 9)) & (0xfffffffff >> (3-level) * 9), (pt->v >> 54) & 1);//FIXME the gpn is right?
            DMSG("s2pt lev%hhd pto gpn:0x%lx mfn:0x%lx ap %lu nx %lx\n", level, pfn, (pt->v >> (12 + (3- level) * 9)) & (0xfffffffff >> (3-level) * 9), (pt->v >> 6) & 0x3 ,(pt->v >> 54) & 1);//FIXME the gpn is right?
        }
    } else
        DMSG("invalid entry\n");
}
/*In my implementation, the member of pite_t can have follw values:
*page table: p 1 pt 1 (updated when pt is mapped) *only if pt == 1, we think the page table is valid
*used pages for code or data: p 1 pt 0
*other: has no entry or p 0 pt 0
* */
/*Init one pit table for each vm: recored the level and mapped times of page table
 */
void init_pit(struct vm *vm) {
   pite_t * root = (pite_t *)alloc_pages_aligned(1 << PIT_TABLE_SHIFT, PAGE_SHIFT + 9);//2M aligned
   if ((root == NULL) || ((uint64_t)(root) & (PAGE_SIZE - 1)))
       panic("init_pit failed\n");
   memset(root, 0, PAGE_SIZE * (1 << PIT_TABLE_SHIFT));
   vm->root = root;
   DMSG("allocate pit table at %p\n", root);
}
/*Update pit for pages that are not pt*/
void set_pit_not_pt(pite_t *pite, uint8_t valid, uint8_t is_pt, uint8_t ap) {
    if (valid) {
        pite->p = valid;
        pite->pt = is_pt;
        pite->ap = ap;
        pite->level = 0;
    } else {
        pite->pite = 0;
    }
}

/*Store the level and mapped times of page table pages, will override the info
 *@gpa: gpa of current pt page
 *count: times of being mapped by not-final level page table
 *Use: check the level before invoking this function
 */
void set_pit_pt(pite_t *pite, uint8_t level, uint8_t ap) {
   if (!pite->p || !pite->pt) {//new allocated or it is in kernel data (override it)
        pite->p = 1;
        pite->pt = 1;
        pite->ap = ap;
        pite->level = level;
   }
   else {
        EMSG("double mapping level %hhd\n", pite->level);//noamlly, only one va can be used to access the pt page
   }
   return;
}

/*used for huge page
 *@phyaddr: phyaddr of page
 **/
void check_entry_ap_huge_page(struct vcpu *vcpu, uint64_t phyaddr, uint8_t level, struct pt_entry *ptr, uint8_t *flush)
{
    uint8_t flush_ = 0;
    check_align(phyaddr, PAGE_SIZE);
    uint64_t phyaddr_e = phyaddr + (PAGE_SIZE << ((3- level) * 9)) - PAGE_SIZE; //huge page: [phyaddr,phyaddr_e] 
    do {
        //only consider the huge page located in kerel code/data
        if (is_kernel_section(phyaddr, phyaddr_e, sections, num_section)) {
            if ((kernel_info.vdso_end > phyaddr && kernel_info.vdso_start <= phyaddr_e) || (kernel_info.vdso_data >= phyaddr && kernel_info.vdso_data <= phyaddr_e) || (kernel_info.empty_zero_page >= phyaddr && kernel_info.empty_zero_page <= phyaddr_e)) {//override with user accessable pages
                return;
            }
            //check the permission if it is not override
            if (ptr->v & PT_L3_EL0_ACCESS) {
                ptr->v &= ~PT_L3_EL0_ACCESS;//el0 unaccessable
                DMSG("RTKP: protect kernel memory gpn 0x%lx el0_ac 1->%lu\n", phyaddr >> PAGE_SHIFT, (ptr->v >> 6) & 1);
                flush_ = 1;
            }
            if (!(ptr->v & PT_L3_XN)) {
                ptr->v |= PT_L3_XN;//el0 not executable 
                DMSG("RTKP: protect kernel memory gpn 0x%lx uxn 0->%lu\n", phyaddr >> PAGE_SHIFT, (ptr->v >> 54) & 1);
                flush_ = 1;
            }
       } else {
           //FIXME protect kernel module if we know it's memory
       }
    } while(0);
    if (flush && flush_) {
        *flush = flush_;
    }
}

/*check the permission of entry and reset it if it is illegal
 *check the ap based on the phyaddr of page no matter who(kernel or user) use it
 *@phyaddr: gpa of data page
 *@ptr: point to the entry
 *@level: level of pt which points to the data
 *@init: 1: check permission of entry when setting page table ro 0: check entry when updating it
 *Note: this function is used for 4k page
 *TSET OK
 */
void check_entry_ap(struct vcpu *vcpu, uint64_t phyaddr, struct pt_entry *ptr, uint8_t *flush)
{
    uint8_t flush_ = 0;
    check_align(phyaddr, PAGE_SIZE);
    
    do {
        //not require lock there, because this function is called after setting pt ro and updating pit table
        pite_t *pite = vcpu->vm->root + ((phyaddr >> PAGE_SHIFT) & PA_MASK);
        if (!pite->p) {
            if (!(ptr->v & PT_L3_PXN)) {
            }
            return;
        } else if (pite->pt) {//ro and nx(except zero_page)
            //the tlb of pt has been flushed in set_page_table_ro()
            if (phyaddr == kernel_info.empty_zero_page) {
                if (!(ptr->v & PT_L3_PXN)) {
                    ptr->v = ptr->v | PT_L3_PXN;
                    DMSG("RTKP: protect kernel zero page gpn 0x%lx pxn 0->%lx\n", phyaddr >> PAGE_SHIFT, (ptr->v >> 53) & 1);
                } 
                if ((ptr->v & PT_L3_EL0_ACCESS) && !(ptr->v & PT_L3_W)) {
                    ptr->v |= PT_L3_W;//el0 ro
                    DMSG("RTKP: protect kernel zero page gpn 0x%lx ro 0->%lx\n", phyaddr >> PAGE_SHIFT, (ptr->v >> 7) & 1);
                }
                return;
            }
            if (ptr->v & PT_L3_EL0_ACCESS) {
                ptr->v =  ptr->v & ~PT_L3_EL0_ACCESS;
                DMSG("RTKP: protect kernel pt gpn 0x%lx el0_ac 1->%lu\n", phyaddr >> PAGE_SHIFT, (ptr->v >> 6) & 1);
            }
            return;
        } else {//kernel data/code
            if ((phyaddr >= kernel_info.vdso_start && phyaddr < kernel_info.vdso_end) || (phyaddr == kernel_info.vdso_data)) {
                return;
            }
            if (phyaddr == kernel_info.empty_zero_page) {
                if (!(ptr->v & PT_L3_PXN)) {
                    ptr->v = ptr->v | PT_L3_PXN;
                    DMSG("RTKP: protect kernel zero page in gpn 0x%lx pxn 0->%lx\n", phyaddr >> PAGE_SHIFT, (ptr->v >> 53) & 1);
                    flush_ = 1;
                } 
                if ((ptr->v & PT_L3_EL0_ACCESS) && !(ptr->v & PT_L3_W)) {
                    ptr->v |= PT_L3_W;//el0 ro
                    DMSG("RTKP: protect kernel zero page in gpn 0x%lx ro 0->%lx\n", phyaddr >> PAGE_SHIFT, (ptr->v >> 7) & 1);
                    flush_ = 1;
                }
                break;
            }
            if (ptr->v & PT_L3_EL0_ACCESS) {
                ptr->v &= ~PT_L3_EL0_ACCESS;//el0 unaccessable
                DMSG("RTKP: protect kernel memory gpn 0x%lx el0_ac 1->%lu\n", phyaddr >> PAGE_SHIFT, (ptr->v >> 6) & 1);
                flush_ = 1;
            }
            if (!(ptr->v & PT_L3_XN)) {
                ptr->v |= PT_L3_XN;//el0 not executable 
                DMSG("RTKP: protect kernel memory gpn 0x%lx uxn 0->%lu\n", phyaddr >> PAGE_SHIFT, (ptr->v >> 54) & 1);
                flush_ = 1;
            }
        }
    } while(0);
    if (flush && flush_) {
        *flush = flush_;
    }
}

void check_entry_ap_all(struct vcpu *vcpu, uint64_t phyaddr, uint8_t level, struct pt_entry *ptr, uint8_t *flush) {
    if (level > 0 && level < 3) {
       check_entry_ap_huge_page(vcpu, phyaddr, level, ptr, flush);
    } else if (level == 3) {
       check_entry_ap(vcpu, phyaddr, ptr, flush);
    }
}
/*set page table of vm RO: ok
 *@gva: gva of current pt page
 *@gpa: gpa of current pt page
 *@level: level of current pt page
 *@pite: pite table entry for pt page
 *in 64 bit system, the level of page table is not more than 3
 */
void set_page_table_ro(struct vcpu *vcpu, paddr_t gpa, struct mmu_table *s2pt, uint8_t level, uint8_t *flush)
{
    check_align(gpa, PAGE_SIZE);
    struct pt_entry *ptr = (struct pt_entry *) phys_to_virt(gpa);

    if (level < 3) {
        for (uint16_t i = 0; i < PAGE_SIZE / sizeof(struct pt_entry); i++, ptr++) {
            if (ptr->v & 0x1) {
                if (ptr->v & 0x2) {//vaild and point to next table
	                uint64_t addr;
                    addr = ptr->v & PT_Lx_NEXTLEVEL_MASK;//gpa of next page table
                    pite_t *pite = vcpu->vm->root + ((addr >> PAGE_SHIFT) & PA_MASK);
                    if (pite->p && !pite->pt && (pite->ap == RO)) {
                        panic("pt is located in kernel executable page, level %u gpa 0x%lx esr 0x%x elr 0x%lx far 0x%lx pc 0x%lx x30 0x%lx\n", level+1, addr, read_esr_el2(), read_elr_el2(), read_far_el2(), vcpu->pc, vcpu->gpreg.x[30]);
                    }

                    if (addr == kernel_info.empty_zero_page) {
                        set_pit_pt(pite, level + 1, RO & 0x3);
                        set_memtype_in_s2pt(addr, PAGE_SIZE, s2pt, 1, 0);
                    } else {
                        set_pit_pt(pite, level + 1, (RO|NX) & 0x3);
                        set_memtype_in_s2pt(addr, PAGE_SIZE, s2pt, 1, 1);
                    }
                    invalid_tlb_s12(phys_to_virt_linux(addr, kernel_info.phys_offset, kernel_info.page_offset) >> PAGE_SHIFT, addr >> PAGE_SHIFT);
                    set_page_table_ro(vcpu, addr, s2pt, level + 1, flush);
                } else {//we don't split the huge page
                    check_entry_ap_huge_page(vcpu, ptr->v & (BIT_64(48) - BIT_64(39 - level*9)), level, ptr, flush);
                }
           }
       }
    } else if (level == 3) {
        for (uint16_t i = 0; i < PAGE_SIZE / sizeof(struct pt_entry); i++, ptr++) {
            if ((ptr->v & 0x1) && (ptr->v & 0x2)) {//vaild and point to data
                check_entry_ap(vcpu, ptr->v & PT_L3_PA_MASK, ptr, flush);
            }
        } 
    }
}

/*when map the page table page with gpa, update the pit table, override is allowed
 *check if the mapped pages are in secure range
 *@gpa: gpa of page table page
 *@level: level of page table page
 *tlb flush is necessary for new pt, because the pt page may has been wrote
 */
void update_pit_for_map(struct vcpu *vcpu, uint8_t level, paddr_t gpa, vaddr_t gva)
{
    if (level < 1 || level > 3) {
        panic("invalid level %hhu, gpa 0x%lx esr 0x%x elr 0x%lx far 0x%lx pc 0x%lx x30 0x%lx\n", level, gpa, read_esr_el2(), read_elr_el2(), read_far_el2(), vcpu->pc, vcpu->gpreg.x[30]);
    }
    pite_t *pite = vcpu->vm->root + ((gpa >> PAGE_SHIFT) & PA_MASK);
    if (pite->p && !pite->pt && (pite->ap == RO)) {
        panic("pt is located in kernel executable page, level %hhu gpa 0x%lx esr 0x%x elr 0x%lx far 0x%lx pc 0x%lx x30 0x%lx\n", level, gpa, read_esr_el2(), read_elr_el2(), read_far_el2(), vcpu->pc, vcpu->gpreg.x[30]);
    }
    if (gpa == kernel_info.empty_zero_page) {
        set_pit_pt(pite, level, RO & 0x3);
        set_memtype_in_s2pt(gpa, PAGE_SIZE, vcpu->vm->s2pt, 1, 0);
    } else {
        set_pit_pt(pite, level, (RO|NX) & 0x3);
        set_memtype_in_s2pt(gpa, PAGE_SIZE, vcpu->vm->s2pt, 1, 1);
    }
    invalid_tlb_s12(gva >> PAGE_SHIFT, gpa >> PAGE_SHIFT);//FIXME check all contents of the page table
    uint8_t flush = 0;
    set_page_table_ro(vcpu, gpa, vcpu->vm->s2pt, level, &flush);               
    if (flush) {
	    dsb(sy);          
	    tlbi("vmalle1");//or vmallelis. not flush satge 2 because we only change the pt entry 
	    dsb(sy); 
    }
}

 /*@gpa: gpa of page table page, should align
 *@gva: gva belong to a page table page
 *@level: level of page table page
 *@the function can be called only if the page tabel (gpa) is mapped
 */
void update_pit_for_unmap(struct vcpu *vcpu, paddr_t gpa, vaddr_t gva, pite_t *pite)
{
    uint8_t valid; 
    uint8_t is_pt;
    uint8_t type;
    if (gpa == kernel_info.empty_zero_page) {
        valid = 1;
        is_pt = 0;
        type = 0;
    }
    else if (is_kernel_nx_section(gpa, nx_sections, num_nx_section)) {
        valid = 1;
        is_pt = 0;
        type = NX & 0x3;
        DMSG("gpa 0x%lx is nx section\n", gpa);
    }
    else {   
        valid = 0;
        type = 0;//the ro and nx are set when it's mapped again
    }
    set_pit_not_pt(pite,valid,is_pt,type);
    set_memtype_in_s2pt(gpa, PAGE_SIZE, vcpu->vm->s2pt, type & 0x1, ((type >> 1) & 0x1));
    invalid_tlb_s12(gva >> PAGE_SHIFT, gpa >> PAGE_SHIFT);
}

static int init_plugin(struct vm *vm)
{
	int res = 0;
	size_t i = 0;
	struct plugin *plugin;
	for_each_plugin(plugin) {
		plugin->idx = i++;
		if (plugin->init != NULL) {
			res = plugin->init(vm, &vm->plugin_data[i - 1]);
			if (res != 0) {
				for (struct plugin **pplugin2 = &__plugin_start; *pplugin2 != plugin; pplugin2++) {
					if ((*pplugin2)->deinit != NULL)
						(*pplugin2)->deinit(vm, vm->plugin_data[pplugin2 - &__plugin_start]);
				}
				return res;
			}
		} else
			vm->plugin_data[i - 1] = NULL;
	}
	return 0;
}

static void deinit_plugin(struct vm *vm)
{
	struct plugin *plugin;
	for_each_plugin(plugin) {
		if (plugin->deinit != NULL)
			plugin->deinit(vm, vm->plugin_data[plugin->idx]);
	}
}

atomic_t vmid = 0;
struct vm *vm_create(void)
{
	struct vm *ret = malloc(sizeof(struct vm) + sizeof(void *) * get_plugin_num());
	if (ret == NULL) {
		EMSG("Alloc struct vm failed\n");
		return NULL;
	}

	for (uint8_t i = 0; i < MAX_VCPU; i++) {
		ret->vcpu[i].vm = ret;
		ret->vcpu[i].vcpu_id = i;
		ret->vcpu[i].irq = 0;
		ret->vcpu[i].fiq = 0;
	}
	ret->s2pt = s2pt_alloc(39);
	if (ret->s2pt == NULL) {
		EMSG("Alloc s2pt for VM failed\n");
		free(ret);
		return NULL;
	}
	for (uint32_t i = 0; i < MAX_TRAP_TYPE; i++) {
		list_init(&ret->trap_handlers[i]);
		clear_bit(&ret->trap, i);
	}
	if (init_plugin(ret) != 0) {
		EMSG("Init plugin failed\n");
		mmu_free(ret->s2pt);
		free(ret);
		return NULL;
	}

	ret->vmid = atomic_inc(&vmid) & 0xFF;
    init_pit(ret);//init pit table
	return ret;
}

void vm_destroy(struct vm *vm)
{
	deinit_plugin(vm);
	if (vm->s2pt != NULL)
		mmu_free(vm->s2pt);
	for (uint32_t i = 0; i < MAX_TRAP_TYPE; i++) {
		struct trap_handler_list *e, *n;
		list_for_each_entry_safe(e, n, &vm->trap_handlers[i], list) {
			list_del(&e->list);
			free(e);
		}
	}
	free(vm);
}
/*tww: run dom0*/
void vm_run(struct vcpu *vcpu)
{
	extern void _vm_run(struct gpreg_context *gpreg, void *sp);
	disable_interrupt();
	struct plugin *plugin;
	for_each_plugin(plugin) {
		if (plugin->vmenter != NULL) {
			int ret = plugin->vmenter(vm_get_current_vcpu(), vcpu);
			if (ret != 0)
				panic("Plugin %p refuse to enter VM %u\n", plugin, vcpu->vm->vmid);
		}
	}
	assert(vcpu && vcpu->vm && vcpu->vm->s2pt);
	restore_sysreg(&vcpu->sysreg);
	if (s2pt_apply(vcpu->vm->s2pt, vcpu->vm->vmid) != 0)
		panic("s2pt_apply failed for VM %u vCPU %u\n", vcpu->vm->vmid, vcpu->vcpu_id);
	write_elr_el2(vcpu->pc);
	write_spsr_el2(vcpu->cpsr);
	vm_set_current_vcpu(vcpu);
	if (get_bit(&vcpu->vm->trap, TRAP_SMC))
		write_hcr_el2(read_hcr_el2() | AARCH64_HCR_TSC);
	else
		write_hcr_el2(read_hcr_el2() & ~AARCH64_HCR_TSC);
	if (get_bit(&vcpu->vm->trap, TRAP_READ_IDREG2))
		write_hcr_el2(read_hcr_el2() | AARCH64_HCR_TID2);
	else
		write_hcr_el2(read_hcr_el2() & ~AARCH64_HCR_TID2);
	if (get_bit(&vcpu->vm->trap, TRAP_WRITE_VMEMCTRL))
		write_hcr_el2(read_hcr_el2() | AARCH64_HCR_TVM);//protect virtual memory control registers
	else
		write_hcr_el2(read_hcr_el2() & ~AARCH64_HCR_TVM);
	if (get_bit(&vcpu->vm->trap, TRAP_HVC))
        write_hcr_el2(read_hcr_el2() & ~AARCH64_HCR_HVC);//enable hvc
	else
		write_hcr_el2(read_hcr_el2() | AARCH64_HCR_HVC);
	write_hcr_el2((read_hcr_el2() & ~(AARCH64_HCR_AMO | AARCH64_HCR_IMO | AARCH64_HCR_FMO)) |
	              (get_bit(&vcpu->vm->trap, TRAP_IRQ) ? AARCH64_HCR_IMO : 0) |
	              (get_bit(&vcpu->vm->trap, TRAP_FIQ) ? AARCH64_HCR_FMO : 0));
	write_hcr_el2((read_hcr_el2() & ~(AARCH64_HCR_VSE | AARCH64_HCR_VI | AARCH64_HCR_VF)) |
	              (vcpu->irq ? AARCH64_HCR_VI : 0) |
	              (vcpu->fiq ? AARCH64_HCR_VF : 0));

	_vm_run(&vcpu->gpreg, get_core_stack());
}

struct vcpu *vm_get_vcpu(struct vm *vm, uint8_t vcpu)
{
	if (vcpu < 0 || vcpu >= MAX_VCPU)
		return NULL;
	return &vm->vcpu[vcpu];
}

void vcpu_set_gpreg(struct vcpu *vcpu, const struct gpreg_context *gpreg)
{
	assert(vcpu != NULL);
	memcpy(&vcpu->gpreg, gpreg, sizeof(struct gpreg_context));
}

void vcpu_set_sysreg(struct vcpu *vcpu, const struct sysreg_context *sysreg)
{
	assert(vcpu != NULL);
	memcpy(&vcpu->sysreg, sysreg, sizeof(struct sysreg_context));
}

int vm_import_sysreg(struct vm *vm, uint8_t vcpu)
{
	uint8_t old_excp = disable_interrupt();
	assert(vcpu < MAX_VCPU);
	backup_sysreg(&vm->vcpu[vcpu].sysreg);
	resume_interrupt(old_excp);
	return 0;
}

int vm_set_pt(struct vm *vm, struct mmu_table *table)
{
	if (table == NULL)
		return -EINVAL;
	if (vm->s2pt != NULL)
		return -EINVAL;
	vm->s2pt = table;
	return 0;
}

void vm_set_current_vcpu(struct vcpu *vcpu)
{
	write_tpidr_el2((vaddr_t) vcpu);
}

struct vcpu *vm_get_current_vcpu(void)
{
	return (struct vcpu *) read_tpidr_el2();
}

struct vm *vm_get_current(void)
{
	return vm_get_current_vcpu()->vm;
}

void vm_set_next_vcpu(struct vcpu *vcpu)
{
	next_vcpu[get_core_pos()] = vcpu;
}

struct vcpu *vm_get_next_vcpu(void)
{
	return next_vcpu[get_core_pos()];
}

int vm_enable_trap(struct vm *vm, uint32_t type)
{
	switch (type) {
	case TRAP_SMC:
	case TRAP_HVC:
	case TRAP_READ_IDREG2:
    case TRAP_WRITE_VMEMCTRL:
	case TRAP_DA:
	case TRAP_IA:
	case TRAP_IRQ:
	case TRAP_FIQ:
		set_bit(&vm->trap, type);
		return 0;
	default:
		return -EINVAL;
	}
}
/*tww: add handler to the handler list*/
int vm_add_trap_handler(struct vm *vm, uint32_t type, trap_handler_t *handler, void *arg)
{
	struct trap_handler_list *e;
	if (type >= MAX_TRAP_TYPE)
		return -EINVAL;

	list_for_each_entry(e, &vm->trap_handlers[type], list) {
		if (e->handler == handler && e->arg == arg)//handler exsits
			return 0;
	}

	e = malloc(sizeof(struct trap_handler_list));
	if (e == NULL)
		return -ENOMEM;

	e->handler = handler;
	e->arg = arg;/*extral arg of handler except "vcpu" arg*/
	list_add(&e->list, &vm->trap_handlers[type]);

	return 0;
}

int vm_remove_trap_handler(struct vm *vm, uint32_t type, trap_handler_t *handler, void *arg)
{
	struct trap_handler_list *e;
	if (type >= MAX_TRAP_TYPE)
		return -EINVAL;
	list_for_each_entry(e, &vm->trap_handlers[type], list) {
		if (e->handler == handler && e->arg == arg) {
			list_del(&e->list);
			free(e);
			return 0;
		}
	}

	return -EINVAL;
}

void backup_sysreg(struct sysreg_context *sysreg)
{
	sysreg->ttbr0_el1 = read_ttbr0_el1();
	sysreg->ttbr1_el1 = read_ttbr1_el1();
	sysreg->tcr_el1 = read_tcr_el1();
	sysreg->elr_el1 = read_elr_el1();
	sysreg->far_el1 = read_far_el1();
	sysreg->spsr_el1 = read_spsr_el1();
	sysreg->esr_el1 = read_esr_el1();
	sysreg->vbar_el1 = read_vbar_el1();
}

void restore_sysreg(struct sysreg_context *sysreg)
{
	write_ttbr0_el1(sysreg->ttbr0_el1);
	write_ttbr1_el1(sysreg->ttbr1_el1);
	write_tcr_el1(sysreg->tcr_el1);
	write_elr_el1(sysreg->elr_el1);
	write_far_el1(sysreg->far_el1);
	write_spsr_el1(sysreg->spsr_el1);
	write_esr_el1(sysreg->esr_el1);
	write_vbar_el1(sysreg->vbar_el1);
}
/*tww: the specific handler for vmexit*/
static int vcpu_handle_trap(struct vcpu *vcpu, uint32_t type)
{
	struct trap_handler_list *e;
	int ret;

	assert(type < MAX_TRAP_TYPE);
	list_for_each_entry(e, &vcpu->vm->trap_handlers[type], list) {//tww: call the handler orderly
		ret = (e->handler)(vcpu, e->arg);
		if (ret < 0) {
			EMSG("VM %u vCPU %u %p handle trap %u failed: %d\n", vcpu->vm->vmid, vcpu->vcpu_id, e->handler, type, ret);
			return ret;
		} else if (ret == 0)
			return ret;//handled successfully
	}

	return 1;
}

/*tww: handle the MSR instruction (virtual mem contrl register) --ok
 *protect: sctlr_el1 ttbr0_el1 ttbr1_el1
 *FIXME make unprotected registers untrapped
 *arm64: 3 level page table, Input address [38:12], T0SZ and T1SZ are both 25
 */
int vcpu_handle_msr_vmemctrl(struct vcpu *vcpu, void *arg __unused)
{
    assert(vcpu == vm_get_current_vcpu());
    uint32_t instr = vm_get_current_vcpu_instr();
    uint32_t coproc = aarch64_instr_get_coproc(instr);
    uint32_t gpreg = instr & 0x1f;
    //Note: vcpu recoreds the old value that represents the cpu status at the trap time
    switch (coproc) {
       case AARCH64_COPROC_SCTLR_EL1:
            //FIXME bit0: enable MMU
            /*if (!(vcpu->gpreg.x[gpreg] & AARCH64_SCTLR_M)) {//TODO: handle the normal disable and illegal disable
                DMSG("disable MMU pc 0x%lx\n", vcpu->pc);
            }
            if (!(vcpu->gpreg.x[gpreg] & AARCH64_SCTLR_WXN)) {
                DMSG("wxn disable pc 0x%lx\n", vcpu->pc);
            } */
            write_sctlr_el1(vcpu->gpreg.x[gpreg]);
            //In arm64, AFE falg(bit 29) is res1
            break;
       case AARCH64_COPROC_TTBR0_EL1: {
            uint64_t ttbr0_el1;
            ttbr0_el1 = vcpu->sysreg.ttbr0_el1 = vcpu->gpreg.x[gpreg]; 
            ttbr0_el1 &= AARCH64_TTBR0_BADDR_MASK;
            if ((ttbr0_el1  < ro_buffer_pa_s) || (ttbr0_el1 >= ro_buffer_pa_e)) {//not in ro_buffer
	            spin_lock(&pit_lock);
              if ((vcpu->vm->root + ((ttbr0_el1 >> PAGE_SHIFT) & PA_MASK))->pt == 0) {
                pite_t *pite = vcpu->vm->root + ((ttbr0_el1 >> PAGE_SHIFT) & PA_MASK);
                if (pite->p && !pite->pt && (pite->ap == RO)) {
                    panic("pt is located in kernel executable page, level 1 gpa 0x%lx esr 0x%x elr 0x%lx far 0x%lx pc 0x%lx x30 0x%lx\n", ttbr0_el1, read_esr_el2(), read_elr_el2(), read_far_el2(), vcpu->pc, vcpu->gpreg.x[30]);
                }
                if (ttbr0_el1 == kernel_info.empty_zero_page) {
                    set_pit_pt(pite, 1, RO & 0x3);
	                spin_unlock(&pit_lock);
                    set_memtype_in_s2pt(ttbr0_el1, PAGE_SIZE, vcpu->vm->s2pt, 1, 0);
                } else {
                    set_pit_pt(pite, 1, (RO|NX) & 0x3);
	                spin_unlock(&pit_lock);
                    set_memtype_in_s2pt(ttbr0_el1, PAGE_SIZE, vcpu->vm->s2pt, 1, 1);
                }
                invalid_tlb_s12(phys_to_virt_linux(ttbr0_el1, kernel_info.phys_offset, kernel_info.page_offset) >> PAGE_SHIFT, ttbr0_el1 >> PAGE_SHIFT);
                uint8_t flush = 0;
                set_page_table_ro(vcpu, ttbr0_el1, vcpu->vm->s2pt, 1, &flush);
                if (flush) {
                    DMSG("flush tlb for pt ttbr0 0x%lx\n", ttbr0_el1);
                    dsb(sy);         
                    tlbi("vmalle1");
                    dsb(sy); 
                }
              } else {//fast path
	            spin_unlock(&pit_lock);
              }
            }
            break; }
       case AARCH64_COPROC_TTBR1_EL1: {
            if ((vcpu->gpreg.x[gpreg]  & AARCH64_TTBR0_BADDR_MASK) != ttbr1_el1)
                panic("invaid value vcpu->gpreg.x[%d] 0x%lx ttbr1_el1 0x%lx esr 0x%x elr 0x%lx far 0x%lx pc 0x%lx x30 0x%lx\n", gpreg, vcpu->gpreg.x[gpreg], ttbr1_el1, read_esr_el2(), read_elr_el2(), read_far_el2(), vcpu->pc, vcpu->gpreg.x[30]);
            vcpu->sysreg.ttbr1_el1 = vcpu->gpreg.x[gpreg]; 
            break; }
       case AARCH64_COPROC_TCR_EL1: {
            if (((vcpu->gpreg.x[gpreg] >> 30) & 0x3) != 0x2)
                panic("ttbr1_el1 not 4kB granule size, esr 0x%x elr 0x%lx far 0x%lx pc 0x%lx x30 0x%lx\n", read_esr_el2(), read_elr_el2(), read_far_el2(), vcpu->pc, vcpu->gpreg.x[30]);
            if (((vcpu->gpreg.x[gpreg] >> 14) & 0x3) != 0x0)
                panic("ttbr0_el1 not 4kB granule size, esr 0x%x elr 0x%lx far 0x%lx pc 0x%lx x30 0x%lx\n", read_esr_el2(), read_elr_el2(), read_far_el2(), vcpu->pc, vcpu->gpreg.x[30]);
            if ((vcpu->gpreg.x[gpreg] & 0x3f) != 25) //T0SZ
                panic("invalid t0sz %lu, should be 25. esr 0x%x elr 0x%lx far 0x%lx pc 0x%lx x30 0x%lx\n", vcpu->gpreg.x[gpreg] & 0x3f, read_esr_el2(), read_elr_el2(), read_far_el2(), vcpu->pc, vcpu->gpreg.x[30]);
            if (((vcpu->gpreg.x[gpreg] >> 16) & 0x3f) != 25) //manul D4.2.5
                panic("invalid t1sz %lu, should be 25. esr 0x%x elr 0x%lx far 0x%lx pc 0x%lx x30 0x%lx\n", vcpu->gpreg.x[gpreg] & 0x3f, read_esr_el2(), read_elr_el2(), read_far_el2(), vcpu->pc, vcpu->gpreg.x[30]);
            vcpu->sysreg.tcr_el1 = vcpu->gpreg.x[gpreg];
            break; }
       case AARCH64_COPROC_ESR_EL1:    
            vcpu->sysreg.esr_el1 = vcpu->gpreg.x[gpreg]; 
            break;
       case AARCH64_COPROC_FAR_EL1:    
            vcpu->sysreg.far_el1 = vcpu->gpreg.x[gpreg]; 
            break;
       case AARCH64_COPROC_AFSR0_EL1:
            write_afsr0_el1(vcpu->gpreg.x[gpreg]); 
            break;
       case AARCH64_COPROC_AFSR1_EL1:  
            write_afsr1_el1(vcpu->gpreg.x[gpreg]); 
            break;
       case AARCH64_COPROC_MAIR_EL1:   
            write_mair_el1(vcpu->gpreg.x[gpreg]); 
            break;
       case AARCH64_COPROC_AMAIR_EL1:  
            write_amair_el1(vcpu->gpreg.x[gpreg]); 
            break;
       case AARCH64_COPROC_CONTEXTIDR_EL1:
            write_contextidr_el1(vcpu->gpreg.x[gpreg]); 
            break;
       default:
            panic("Unkown sysreg: 0x%x, esr 0x%x elr 0x%lx far 0x%lx pc 0x%lx x30 0x%lx\n", coproc, read_esr_el2(), read_elr_el2(), read_far_el2(), vcpu->pc, vcpu->gpreg.x[30]);
    }
	vcpu->pc += 4;//ins length of arm-v8
    return 0;
}
/*store the memtype of memory range (gva_s to gva_e)in pit table and set them in the s2pt
 *this function is used to store the information of initial kernel memory
 *@type:bit2:0 xwr
 *@gva_s @gva_e: should both align. we store the info of memory: [gva_s, gva_e)
 *gpa should be continues: [gpa_s, gpa_e) 
 *invoked at initializing time
 */
void set_memtype_by_gva(struct vcpu *vcpu, vaddr_t gva_s, vaddr_t gva_e, uint8_t ispt, uint8_t valid, uint8_t type, uint8_t override) {
   pite_t *root = vcpu->vm->root;
   vaddr_t gva_s_align, gva_e_align;
   paddr_t gpa;
   pite_t *pite;
   gva_s_align = ROUNDUP(gva_s, PAGE_SIZE*512);//2M align
   gva_e_align = ROUNDDOWN(gva_e, PAGE_SIZE*512);

   for (vaddr_t gva = gva_s; gva < gva_e; gva += PAGE_SIZE) {

        if (gva == gva_s_align) {
            for (; gva < gva_e_align; gva += PAGE_SIZE*512) {
                vcpu_gva_to_gpa_try(vcpu, gva, &gpa);
                set_memtype_in_s2pt(gpa, PAGE_SIZE*512, vcpu->vm->s2pt, type & 0x1, ((type >> 1) & 0x1));
            }
            for (gva = gva_s_align; gva < gva_e_align; gva += PAGE_SIZE) {
                vcpu_gva_to_gpa_try(vcpu, gva, &gpa);
                pite = root + ((gpa >> PAGE_SHIFT) & PA_MASK);
                if (!pite->pite || override) {
                    if (ispt) {
                        set_pit_pt(pite, 1, type & 0x3);
                    }
                    else { 
                        set_pit_not_pt(pite, valid, ispt, type & 0x3);
                    }
                    invalid_tlb_s2(gpa >> PAGE_SHIFT);
                } 
                //check_after_set_ap(gpa>>PAGE_SHIFT, vcpu->vm->s2pt->pt, 1, 2, 1);//s2pt is 3 level
            }
            //gva == gva_e_align
            if (gva == gva_e) {
                break;
            }
        }
        vcpu_gva_to_gpa_try(vcpu, gva, &gpa);
        pite = root + ((gpa >> PAGE_SHIFT) & PA_MASK);
        if (!pite->pite || override) {
            if (ispt) {
                set_pit_pt(pite, 1, type & 0x3);
            }
            else { 
               set_pit_not_pt(pite, valid, ispt, type & 0x3);
            }
            set_memtype_in_s2pt(gpa, PAGE_SIZE, vcpu->vm->s2pt, type & 0x1, ((type >> 1) & 0x1));
            invalid_tlb_s2(gpa >> PAGE_SHIFT);
        } else //not override
            DMSG("set_memtype_by_gva-not-override pite->pt %hhx p %hhx arg ispt %hhx\n", pite->pt, pite->p, ispt);
   }
}
/*set ap for kernel sections*/
void set_section_memtype(struct vcpu *vcpu, section_info *sections, uint8_t num_section) 
{
   uint8_t i;
   for (i = 0; i < num_section; i++) {
       set_memtype_by_gva(vcpu, sections[i].va_s, sections[i].va_e, 0, 1, sections[i].ap, 0);
   }
}

int vcpu_handle_trap_da(struct vcpu *vcpu, void *arg __unused)
{
	uint32_t instr = vcpu_get_instr(vcpu);
	uint32_t fault_type = vcpu_get_fault_type(vcpu);
    paddr_t gpa, phyaddr;
    vaddr_t gva;
    uint8_t stxr = 0;
    uint64_t data_64;
    pite_t *pite;
    //Note kernel usually use str or stxr (FAULT_WRITE64_S or FAULT_WRITE64) to update pt, other fault type may be a write on the non-page-table page
	switch (fault_type) {
        case FAULT_WRITE64_S://stxr
            stxr = 1;
        case FAULT_WRITE64: {//str
            uint8_t t = instr & 0x1f;
            gva = vcpu_get_fault_addr(vcpu);
            vcpu_gva_to_gpa_try(vcpu, gva, &gpa);
            if (t == 31) {//xzr register
                data_64 = 0;
            }
            else {
                data_64 = vcpu->gpreg.x[t];
            }
            break; }
        default: {
            gva = vcpu_get_fault_addr(vcpu);
            vcpu_gva_to_gpa_try(vcpu, gva, &gpa);
            pite = vcpu->vm->root + ((gpa >> PAGE_SHIFT) & PA_MASK);
	        spin_lock(&pit_lock);
            if (pite->p && pite->pt) {
	            spin_unlock(&pit_lock);
                panic("Unexpected data access type %u esr 0x%x elr 0x%lx far 0x%lx pc 0x%lx x30 0x%lx\n", fault_type, read_esr_el2(), read_elr_el2(), read_far_el2(), vcpu->pc, vcpu->gpreg.x[30]);
                return -EINVAL;
            }
	        spin_unlock(&pit_lock);
            //do not write pt, check if it is illegal write
            break; }
    }
    pite = vcpu->vm->root + ((gpa >> PAGE_SHIFT) & PA_MASK);
	spin_lock(&pit_lock);
    if (pite->p && pite->pt) {//is pt
        if (stxr) {
                //s = (instr >> 16) & 0x1f;
                //vcpu->gpreg.x[s] = 0; //update successfully
                //TODO emulate the stxr
                //BUG: emualte stxr instruction the vmalloc() will fail to allocate page in kernel
                phyaddr = ROUNDDOWN(gpa, PAGE_SIZE);
                update_pit_for_unmap(vcpu, phyaddr, gva, pite);//Test: is always level 3, change the pite and unlock
	            spin_unlock(&pit_lock);
                return 0; //not emualte let kernel do it
         }
	     spin_unlock(&pit_lock);
         struct pt_entry old_entry = *(struct pt_entry *) phys_to_virt(gpa);
         struct pt_entry new_entry = {data_64};
         int8_t valid_old = 0, pto_table_old = 0;
         int8_t valid_new = 0, pto_table_new = 0;   
         uint64_t * pdata = (uint64_t *) phys_to_virt(gpa);
         uint8_t level = pite->level;
         check_entry(level, old_entry, &valid_old, &pto_table_old);
         check_entry(level, new_entry, &valid_new, &pto_table_new);
         /*if (valid_old && pto_table_old) {
             if (!valid_new || !pto_table_new || ((old_entry.v & PT_Lx_NEXTLEVEL_MASK) != (new_entry.v & PT_Lx_NEXTLEVEL_MASK))) {
                 phyaddr = old_entry.v & PT_Lx_NEXTLEVEL_MASK;
                 pite = vcpu->vm->root + ((phyaddr >> PAGE_SHIFT) & PA_MASK);
                 update_pit_for_unmap(vcpu, phyaddr, phys_to_virt_linux(phyaddr, kernel_info.phys_offset, kernel_info.page_offset), pite);
             }
         }*/
         if (valid_new) {
            if (pto_table_new) {
                 if (!valid_old || !pto_table_old || ((old_entry.v & PT_Lx_NEXTLEVEL_MASK) != (new_entry.v & PT_Lx_NEXTLEVEL_MASK))) {//map new pt 
                     phyaddr = new_entry.v & PT_Lx_NEXTLEVEL_MASK;
                     update_pit_for_map(vcpu, level + 1, phyaddr, phys_to_virt_linux(phyaddr, kernel_info.phys_offset, kernel_info.page_offset)); 
                 }
            } else {//point to data
                 phyaddr = new_entry.v & (BIT_64(48) - BIT_64(39 - level * 9));//gpa of data page
                 check_entry_ap_all(vcpu, phyaddr, level, &new_entry, NULL);
            }
         }
         write64(pdata, new_entry.v);
	     dsb(ishst);
    } else if (!pite->p) {
        //inreasonable abort because we may free set permission for these pagesa
	    spin_unlock(&pit_lock);
        EMSG("abort on pages gva 0x%lx gpn 0x%lx pt %hhx ap %hhx\n", gva, gpa >> PAGE_SHIFT, pite->pt, pite->ap);//FIXME sometimes run there, may be we has set it ro, but tlb failed to flush
        set_memtype_in_s2pt(ROUNDDOWN(gpa, PAGE_SIZE), PAGE_SIZE, vcpu->vm->s2pt, 0, 0);//the ro and nx are set when it's mapped again
        invalid_tlb_s12(gva >> PAGE_SHIFT, gpa >> PAGE_SHIFT);//abort on gva: means it use the stage 1
        return 0; //not emualte, let kernel do it
    }
    else if (!pite->pt) {//data/code
	    spin_unlock(&pit_lock);
        if (pite->ap & RO) {//write ro page, do not emulate FIXME some side effects?
            EMSG("RTKP: ro page writting detected: gvn 0x%lx gpn 0x%lx\n", gva >> PAGE_SHIFT, gpa >> PAGE_SHIFT);
        } 
    }

	vcpu->pc += 4;
    return 0; 
}
/*Hvc handler
*the elr_el2 stores the address of instruction after the hvc
*/
int vcpu_handle_trap_hvc(struct vcpu *vcpu, void *arg __unused) {
    uint64_t cmd = vcpu->gpreg.x[0];
    switch (cmd) {
        case RTKP_INIT: {
            if (rtkp_start) {
                panic("The rtkp has initialized, can not initialize again. esr 0x%x elr 0x%lx far 0x%lx pc 0x%lx x30 0x%lx\n", read_esr_el2(), read_elr_el2(), read_far_el2(), vcpu->pc, vcpu->gpreg.x[30]);
            }
            uint64_t gva = vcpu->gpreg.x[1];
            rtkp_info *prtkp;
            paddr_t gpa;
            rtkp_start = 1;
            /*Check and store the address of kernel objects*/
            vcpu_gva_to_gpa_try(vcpu, gva, &gpa);
            prtkp = (rtkp_info *) phys_to_virt(gpa);
            kernel_info.vdso_start = prtkp->vdso_start;//gpa
            kernel_info.vdso_end = prtkp->vdso_end; //gpa
            kernel_info.vdso_data = prtkp->vdso_data; //gpa
            kernel_info.phys_offset = prtkp->phys_offset;//gpa
            kernel_info.high_memory = prtkp->high_memory; //gpa
            kernel_info.page_offset = prtkp->page_offset; 
            ro_buffer_va_s = (vaddr_t)prtkp->ro_buffer_va;
            ro_buffer_va_e = ro_buffer_va_s + prtkp->ro_buffer_size;
            phys_offset_pfn = prtkp->phys_offset >> PAGE_SHIFT;
            //Note: the address should aligned
            check_align(ro_buffer_va_s, PAGE_SIZE*512);
            check_sections_align(prtkp);
            //Note: the empty_zero_page should not override ro buf
            assert(((vaddr_t)(prtkp->empty_zero_page) < ro_buffer_va_s) || ((vaddr_t)(prtkp->empty_zero_page) >= ro_buffer_va_e));
            vcpu_gva_to_gpa_try(vcpu, prtkp->swapper_pg_dir, &ttbr1_el1);
            vcpu_gva_to_gpa_try(vcpu, ro_buffer_va_s, &ro_buffer_pa_s);
            vcpu_gva_to_gpa_try(vcpu, ro_buffer_va_e, &ro_buffer_pa_e);
            vcpu_gva_to_gpa_try(vcpu, (vaddr_t)(prtkp->empty_zero_page), &(kernel_info.empty_zero_page));
            store_section_info(vcpu, prtkp, sections, &num_section, nx_sections, &num_nx_section);
            /*Set permission for kernel sections in s2pt*/
            set_memtype_by_gva(vcpu, ro_buffer_va_s, ro_buffer_va_e, 1, 1, NX|RO, 1);
            set_section_memtype(vcpu, sections, num_section);
            set_memtype_by_gva(vcpu, (vaddr_t)(prtkp->empty_zero_page), (vaddr_t)(prtkp->empty_zero_page + PAGE_SIZE), 0, 1, 0, 1);//rwx

            pite_t *pite = vcpu->vm->root + ((ttbr1_el1 >> PAGE_SHIFT) & PA_MASK);
            if (pite->p && !pite->pt && (pite->ap == RO)) {
                panic("pt is located in kernel executable page, level 1 gpa 0x%lx esr 0x%x elr 0x%lx far 0x%lx pc 0x%lx x30 0x%lx\n", ttbr1_el1, read_esr_el2(), read_elr_el2(), read_far_el2(), vcpu->pc, vcpu->gpreg.x[30]);
            }
            DMSG("set ttbr1 ro 0x%lx\n", ttbr1_el1);
            if ((ttbr1_el1 < ro_buffer_pa_s) || (ttbr1_el1 >= ro_buffer_pa_e)) {//not in ro_buffer
                if (ttbr1_el1 == kernel_info.empty_zero_page) {
                    set_pit_pt(pite, 1, RO & 0x3);
                    set_memtype_in_s2pt(ttbr1_el1, PAGE_SIZE, vcpu->vm->s2pt, 1, 0);
                } else {
                    set_pit_pt(pite, 1, (RO|NX) & 0x3);
                    set_memtype_in_s2pt(ttbr1_el1, PAGE_SIZE, vcpu->vm->s2pt, 1, 1);
                }
            }

            set_page_table_ro(vcpu, ttbr1_el1, vcpu->vm->s2pt, 1, NULL);
            dsb(sy);
            tlbi("vmalle1is");//flush tlb for kernel code/data
            dsb(sy);
            vm_add_trap_handler(vcpu->vm, TRAP_WRITE_VMEMCTRL, vcpu_handle_msr_vmemctrl, NULL);
            vm_enable_trap(vcpu->vm, TRAP_WRITE_VMEMCTRL);
            vm_add_trap_handler(vcpu->vm, TRAP_DA, vcpu_handle_trap_da, NULL);
            vm_enable_trap(vcpu->vm, TRAP_DA);
            break; }
        case RTKP_PGD_FREE://level 1
        case RTKP_PMD_FREE://level 2
        case RTKP_PTE_FREE: {
            paddr_t gpa;
            vaddr_t gva;
            if (cmd != RTKP_PTE_FREE) {
                gva = vcpu->gpreg.x[1];//TODO check whether all free function have been intercepted, gva of freed page
                vcpu_gva_to_gpa_try(vcpu, gva, &gpa);
            }
            else { 
                gpa = vcpu->gpreg.x[1];
                gva = phys_to_virt_linux(gpa, kernel_info.phys_offset, kernel_info.page_offset);
            }
            pite_t *pite = vcpu->vm->root + ((gpa >> PAGE_SHIFT) & PA_MASK);
	        spin_lock(&pit_lock);
            if (pite->p && pite->pt) {
                uint8_t valid; 
                uint8_t is_pt;
                uint8_t type;
                if (gpa == kernel_info.empty_zero_page) {
                    valid = 1;
                    is_pt = 0;
                    type = 0;
                }
                else if (is_kernel_nx_section(gpa, nx_sections, num_nx_section)) {
                    valid = 1;
                    is_pt = 0;
                    type = NX & 0x3;
                    DMSG("gpa 0x%lx is nx section\n", gpa);
                }
                else {   
                    valid = 0;
                    type = 0;//the ro and nx are set when it's mapped again
                }
                set_pit_not_pt(pite,valid,is_pt,type);
	            spin_unlock(&pit_lock);
                set_memtype_in_s2pt(gpa, PAGE_SIZE, vcpu->vm->s2pt, type & 0x1, ((type >> 1) & 0x1));
                invalid_tlb_s12(gva >> PAGE_SHIFT, gpa >> PAGE_SHIFT);
            } else {//may be freed when emulating stxr
	            spin_unlock(&pit_lock);
                if (pite->p && !pite->pt && (pite->ap == RO)) 
                    panic("pt is located in kernel executable page, level %lu gpa 0x%lx esr 0x%x elr 0x%lx far 0x%lx pc 0x%lx x30 0x%lx\n", cmd, gpa, read_esr_el2(), read_elr_el2(), read_far_el2(), vcpu->pc, vcpu->gpreg.x[30]);
            }
            break; }
        case RTKP_PGD_CREATE: {
            paddr_t gpa;
            vaddr_t gva;
            gva = vcpu->gpreg.x[1];
            vcpu_gva_to_gpa_try(vcpu, gva, &gpa);

            pite_t *pite = vcpu->vm->root + ((gpa >> PAGE_SHIFT) & PA_MASK);
            if (pite->p && !pite->pt && (pite->ap == RO)) {
               panic("pt is located in kernel executable page, level 1 gpa 0x%lx esr 0x%x elr 0x%lx far 0x%lx pc 0x%lx x30 0x%lx\n", gpa, read_esr_el2(), read_elr_el2(), read_far_el2(), vcpu->pc, vcpu->gpreg.x[30]);
            }
            if (gpa == kernel_info.empty_zero_page) {
                set_pit_pt(pite, cmd-3, RO & 0x3);
                set_memtype_in_s2pt(gpa, PAGE_SIZE, vcpu->vm->s2pt, 1, 0);
            } else {
                set_pit_pt(pite, cmd-3, (RO|NX) & 0x3);
                set_memtype_in_s2pt(gpa, PAGE_SIZE, vcpu->vm->s2pt, 1, 1);
            }
            invalid_tlb_s12(gva >> PAGE_SHIFT, gpa >> PAGE_SHIFT);
            break; }
        /*case RTKP_EXECUTE:
            DMSG("attacker elr 0x%lx pc 0x%lx tries to execute on gva 0x%lx\n", read_elr_el2(), vcpu->pc, vcpu->gpreg.x[1]);
            vcpu->pc = vcpu->gpreg.x[1];
            break;*/
        default:
            panic("hvc unkown cmd %lu esr 0x%x elr 0x%lx far 0x%lx pc 0x%lx x30 0x%lx\n", cmd, read_esr_el2(), read_elr_el2(), read_far_el2(), vcpu->pc, vcpu->gpreg.x[30]);
            return -EINVAL;
    }
    return 0;
}

int vcpu_handle_irq(struct vcpu *vcpu)
{
    int ret;
    if (get_bit(&vcpu->vm->trap, TRAP_IRQ))
        return vcpu_handle_trap(vcpu, TRAP_IRQ);
    else {
        EMSG("Unexpected trap %u from VM %u\n", TRAP_IRQ, vcpu->vm->vmid);
        return -EINVAL;
    }
}

int vcpu_handle_fiq(struct vcpu *vcpu)
{
    int ret;
    if (get_bit(&vcpu->vm->trap, TRAP_FIQ))
        return vcpu_handle_trap(vcpu, TRAP_FIQ);
    else {
        EMSG("Unexpected trap %u from VM %u\n", TRAP_FIQ, vcpu->vm->vmid);
        return -EINVAL;
    }
}

int vcpu_redirect_smc(struct vcpu *vcpu, void *arg __unused)
{
    struct smc_param param;
    param.func_id = vcpu->gpreg.x[0];
    param.arg0 = vcpu->gpreg.x[1];
    param.arg1 = vcpu->gpreg.x[2];
    param.arg2 = vcpu->gpreg.x[3];
    param.arg3 = vcpu->gpreg.x[4];
    param.arg4 = vcpu->gpreg.x[5];
    param.arg5 = vcpu->gpreg.x[6];
    do_smc(&param);
    vcpu->gpreg.x[0] = param.ret0;
    vcpu->gpreg.x[1] = param.ret1;
    vcpu->gpreg.x[2] = param.ret2;
    vcpu->gpreg.x[3] = param.ret3;
    vcpu->pc += 4;
    return 0;
}

int vcpu_redirect_mrs(struct vcpu *vcpu, void *arg __unused)
{
    assert(vcpu == vm_get_current_vcpu());
    uint32_t instr = vm_get_current_vcpu_instr();
    assert(aarch64_instr_get_op(instr) == AARCH64_OP_MRS);
    uint32_t reg = aarch64_instr_get_Rt(instr);
    assert(reg < ARRAY_SIZE(vcpu->gpreg.x));
    switch (aarch64_instr_get_coproc(instr)) {
        case AARCH64_COPROC_CTR_EL0:
            vcpu->gpreg.x[reg] = read_ctr_el0();
            break;
        case AARCH64_COPROC_CCSIDR_EL1:
            vcpu->gpreg.x[reg] = read_ccsidr_el1();
            break;
        case AARCH64_COPROC_CLIDR_EL1:
            vcpu->gpreg.x[reg] = read_clidr_el1();
            break;
        case AARCH64_COPROC_CSSELR_EL1:
            vcpu->gpreg.x[reg] = read_csselr_el1();
            break;
        default:
            EMSG("Unknown coproc\n");
            return -EINVAL;
    }
    vcpu->pc += 4;
    return 0;
}

int vcpu_redirect_msr_r(struct vcpu *vcpu, void *arg __unused)
{
    assert(vcpu == vm_get_current_vcpu());
    uint32_t instr = vm_get_current_vcpu_instr();
    assert(aarch64_instr_get_op(instr) == AARCH64_OP_MSR_R);
    uint32_t reg = aarch64_instr_get_Rt(instr);
    switch (aarch64_instr_get_coproc(instr)) {
        case AARCH64_COPROC_CSSELR_EL1:
            write_csselr_el1(vcpu_get_reg_force(vcpu, REG_GP0 + reg));
            break;
        default:
            EMSG("Unknown coproc\n");
            return -EINVAL;
    }
    vcpu->pc += 4;
    return 0;
}

/*tww: general handler for vmexit*/
void vcpu_handle_exception(struct vcpu *vcpu)
{
    struct exception_context *excp = &vcpu->excpreg;
    uint32_t trap = MAX_TRAP_TYPE;

    //DMSG("vcpu_handle_exception\n");
    switch (AARCH64_ESR_EC(excp->esr)) {
        case AARCH64_EC_SMC_32:
        case AARCH64_EC_SMC_64:
            trap = TRAP_SMC;
            break;
        case AARCH64_EC_HVC:
            trap = TRAP_HVC;
            break;
        case AARCH64_EC_MSR_MRS: {
            assert(vcpu == vm_get_current_vcpu());
            uint32_t instr = vm_get_current_vcpu_instr();
            switch (aarch64_instr_get_op(instr)) {
                case AARCH64_OP_MRS:
                case AARCH64_OP_MSR_R:
                    if (aarch64_sysreg_is_id2(aarch64_instr_get_coproc(instr)))
                        trap = TRAP_READ_IDREG2;
                    else if (aarch64_sysreg_is_vmemctrl(aarch64_instr_get_coproc(instr))){
                        if (aarch64_instr_get_op(instr) == AARCH64_OP_MSR_R){
                            trap = TRAP_WRITE_VMEMCTRL;
                        }
                        else
                            panic("Unsupported instruction:MSR_R 0x%08x, pc 0x%lx\n", instr, vcpu->pc);
                    }
                    else
                        panic("Unknown coprocessor 0x%x, pc 0x%lx, instr 0x%08x\n", aarch64_instr_get_coproc(instr), vcpu->pc, instr);
                    break;
                default:
                    panic("Unknown instruction 0x%08x, pc 0x%lx\n", instr, vcpu->pc);
                    break;
            }
            break; }
        case AARCH64_EC_IA_LOW: {//exception during the execution of instruction 
            trap = TRAP_IA;
            paddr_t gpa;
            vcpu_gva_to_gpa_try(vcpu, read_far_el2(), &gpa);
            pite_t *pite = vcpu->vm->root + ((gpa >> PAGE_SHIFT) & PA_MASK);
            if (pite->p && (pite->ap & NX)) {
                EMSG("RTKP: execute on none-executable page detected: gva 0x%lx gpa 0x%lx\n", read_far_el2(), gpa);
	            vcpu->pc += 4;
            } else
                panic("IA abort cpsr 0x%x esr 0x%x elr 0x%lx far va 0x%lx pa 0x%lx pc 0x%lx x30 0x%lx\n", vcpu->cpsr, read_esr_el2(), read_elr_el2(), read_far_el2(), gpa, vcpu->pc, vcpu->gpreg.x[30]);
            return; }
        case AARCH64_EC_DA_LOW: {//exception when accessing data
            trap = TRAP_DA;
            break; }
        default:
            panic("Unknown exception from VM %d, esr 0x%08x pc 0x%lx\n", vcpu->vm->vmid, read_esr_el2(), vcpu->pc);
            break;
    }
    if (trap < MAX_TRAP_TYPE) {
        if (get_bit(&vcpu->vm->trap, trap)) {
            if (vcpu_handle_trap(vcpu, trap) == 0) 
                return;
            else
                panic("Unhandled trap %u from VM %u far: 0x%lx esr 0x%08x pc 0x%lx\n", trap, vcpu->vm->vmid, read_far_el1(), read_esr_el2(), vcpu->pc);
        } else {
            paddr_t gpa;
            vcpu_gva_to_gpa_try(vcpu, read_far_el2(), &gpa);
            panic("Unexpected trap %u from VM %u cpsr 0x%x esr 0x%x elr 0x%lx far va 0x%lx pa 0x%lx pc 0x%lx x30 0x%lx\n", trap, vcpu->vm->vmid, vcpu->cpsr, read_esr_el2(), read_elr_el2(), read_far_el2(), gpa, vcpu->pc, vcpu->gpreg.x[30]);
        }
    } else
        panic("Unknown trap from VM %u esr 0x%08x pc 0x%lx\n", vcpu->vm->vmid, read_esr_el2(), vcpu->pc);
}

static int vcpu_gva_to_hpa_elx(struct vcpu *vcpu, uint64_t va, uint64_t *pa, uint8_t el)
{
    if (vcpu->sysreg.ttbr0_el1 == read_ttbr0_el1() &&
            vcpu->sysreg.ttbr1_el1 == read_ttbr1_el1() &&
            virt_to_phys((vaddr_t) vcpu->vm->s2pt->pt) == (read_vttbr_el2() & AARCH64_VTTBR_BADDR_MASK)) {
        switch (el) {
            case 1:
                asm volatile ("at s12e1r, %0"::"r"(va));
                break;
            case 0:
                asm volatile ("at s12e0r, %0"::"r"(va));
                break;
            default:
                return -EINVAL;
        }
        if (read_par_el1() & AARCH64_PAR_F) {
            *pa = read_par_el1();
            return -EIO;
        }
        *pa = (read_par_el1() & AARCH64_PAR_PA_MASK) | (va & (PAGE_SIZE - 1));
        return 0;
    } else {
        uint64_t ttbr0 = read_ttbr0_el1(), ttbr1 = read_ttbr1_el1(), vttbr = read_vttbr_el2();
        int ret;
        write_ttbr0_el1(vcpu->sysreg.ttbr0_el1);
        write_ttbr1_el1(vcpu->sysreg.ttbr1_el1);
        if (s2pt_apply(vcpu->vm->s2pt, vcpu->vm->vmid) != 0)
            panic("s2pt_apply failed for VM %u vCPU %u\n", vcpu->vm->vmid, vcpu->vcpu_id);
        ret = vcpu_gva_to_gpa_elx(vcpu, va, pa, el);
        write_ttbr0_el1(ttbr0);
        write_ttbr1_el1(ttbr1);
        write_vttbr_el2(vttbr);
        return ret;
    }
}

int vcpu_gva_to_hpa_el1(struct vcpu *vcpu, uint64_t va, uint64_t *pa)
{
    return vcpu_gva_to_hpa_elx(vcpu, va, pa, 1);
}

int vcpu_gva_to_hpa_el0(struct vcpu *vcpu, uint64_t va, uint64_t *pa)
{
    return vcpu_gva_to_hpa_elx(vcpu, va, pa, 0);
}

int vcpu_gva_to_hpa(struct vcpu *vcpu, uint64_t va, uint64_t *pa)
{
    if (vcpu_gva_to_hpa_el1(vcpu, va, pa) != 0 && vcpu_gva_to_hpa_el0(vcpu, va, pa) != 0)
        return -1;
    else
        return 0;
}

static int vcpu_read_ux_ely(struct vcpu *vcpu, vaddr_t va, void *v, size_t x, uint8_t y)
{
    uint64_t pa;
    int ret;
    if ((ret = vcpu_gva_to_hpa_elx(vcpu, va, &pa, y)) != 0)
        return ret;
    memcpy(v, (void *) phys_to_virt(pa), x);
    return 0;
}

int vcpu_read_ux_el1(struct vcpu *vcpu, vaddr_t va, void *v, size_t x)
{
    return vcpu_read_ux_ely(vcpu, va, v, x, 1);
}

int vcpu_read_ux_el0(struct vcpu *vcpu, vaddr_t va, void *v, size_t x)
{
    return vcpu_read_ux_ely(vcpu, va, v, x, 0);
}

int vcpu_read_ux(struct vcpu *vcpu, vaddr_t va, void *v, size_t x)
{
    if (vcpu_read_ux_el1(vcpu, va, v, x) != 0 && vcpu_read_ux_el0(vcpu, va, v, x) != 0)
        return -1;
    else
        return 0;
}

int vcpu_read_u32(struct vcpu *vcpu, vaddr_t va, uint32_t *v)
{
    return vcpu_read_ux(vcpu, va, v, 4);
}

int vcpu_read_u64(struct vcpu *vcpu, vaddr_t va, uint64_t *v)
{
    return vcpu_read_ux(vcpu, va, v, 8);
}

uint32_t vm_get_current_vcpu_instr()
{
    struct vcpu *vcpu = vm_get_current_vcpu();
    vaddr_t pc = vcpu->pc;
    switch (AARCH64_SPSR_M(vcpu->cpsr)) {
        case AARCH64_MODE_EL1t:
        case AARCH64_MODE_EL1h:
            asm volatile ("at s12e1r, %0"::"r"(pc));
            break;
        case AARCH64_MODE_EL0t:
            asm volatile ("at s12e0r, %0"::"r"(pc));
            break;
        default:
            panic("Unexpected mode 0x%x of VM %u vCPU %u\n", AARCH64_SPSR_M(vcpu->cpsr), vcpu->vm->vmid, vcpu->vcpu_id);
    }
    if (read_par_el1() & AARCH64_PAR_F)
        panic("Translation fault when try to get PA of VM %u vCPU %u's PC\n", vcpu->vm->vmid, vcpu->vcpu_id);
    pc = (read_par_el1() & AARCH64_PAR_PA_MASK) | (pc & (PAGE_SIZE - 1));
    return *(uint32_t *) phys_to_virt(pc);
}

uint32_t vcpu_get_instr(struct vcpu *vcpu)
{
    if (vcpu == vm_get_current_vcpu())
        return vm_get_current_vcpu_instr();
    else
        panic("Not implemented\n");
}

struct vm *vm_fork(struct vm *vm)
{
    struct vm *ret = malloc(sizeof(struct vm) + sizeof(void *) * get_plugin_num());
    if (ret == NULL)
        return NULL;
    memset(ret, 0, sizeof(struct vm) + sizeof(void *) * get_plugin_num());

    memcpy(ret->vcpu, vm->vcpu, sizeof(vm->vcpu));
    for (uint8_t i = 0; i < MAX_VCPU; i++)
        ret->vcpu[i].vm = ret;
    ret->s2pt = mmu_fork(vm->s2pt);
    if (ret->s2pt == NULL) {
        EMSG("Fork s2pt failed\n");
        free(ret);
        return NULL;
    }
    for (uint32_t i = 0; i < MAX_TRAP_TYPE; i++) {
        struct trap_handler_list *p;
        list_init(&ret->trap_handlers[i]);
        list_for_each_entry(p, &vm->trap_handlers[i], list) {
            int res = vm_add_trap_handler(ret, i, p->handler, p->arg);
            if (res != 0) {
                EMSG("Copy trap handler failed: %d\n", res);
                struct trap_handler_list *p2, *p3;
                list_for_each_entry_safe(p2, p3, &ret->trap_handlers[i], list)
                    free(p2);
                mmu_free(ret->s2pt);
                free(ret);
                return NULL;
            }
        }
        if (get_bit(&ret->trap, i))
            set_bit(&ret->trap, i);
        else
            clear_bit(&ret->trap, i);
    }
    if (init_plugin(ret) != 0) {
        EMSG("Init plugin failed\n");
        struct trap_handler_list *p2, *p3;
        for (uint32_t i = 0; i < MAX_TRAP_TYPE; i++) {
            list_for_each_entry_safe(p2, p3, &ret->trap_handlers[i], list)
                free(p2);
        }
        mmu_free(ret->s2pt);
        free(ret);
        return NULL;
    }

    ret->vmid = atomic_inc(&vmid) & 0xFF;
    return ret;
}

struct mmu_table *vm_get_s2pt(struct vm *vm)
{
    return vm->s2pt;
}

struct mmu_table *vcpu_export_s1pt0(struct vcpu *vcpu)
{
    struct mmu_table *table = s1pt_alloc(64 - AARCH64_TCR_EL1_T0SZ(vcpu->sysreg.tcr_el1));
    if (table == NULL)
        return NULL;
    table->pt = (struct pt_entry *) phys_to_virt(vcpu->sysreg.ttbr0_el1 & AARCH64_TTBR0_BADDR_MASK);
    return table;
}

uint8_t vcpu_get_id(struct vcpu *vcpu)
{
    return vcpu->vcpu_id;
}

struct gpreg_context *vcpu_get_gpreg(struct vcpu *vcpu)
{
    return &vcpu->gpreg;
}

struct sysreg_context *vcpu_get_sysreg(struct vcpu *vcpu)
{
    return &vcpu->sysreg;
}

uint64_t vcpu_get_pc(struct vcpu *vcpu)
{
    return vcpu->pc;
}

void vcpu_set_pc(struct vcpu *vcpu, uint64_t pc)
{
    vcpu->pc = pc;
}

uint32_t vcpu_get_cpsr(struct vcpu *vcpu)
{
    return vcpu->cpsr;
}

void vcpu_set_cpsr(struct vcpu *vcpu, uint32_t cpsr)
{
    vcpu->cpsr = cpsr;
}

int vcpu_assert_irq(struct vcpu *vcpu)
{
    vcpu->irq = 1;
    return 0;
}

int vcpu_deassert_irq(struct vcpu *vcpu)
{
    vcpu->irq = 0;
    return 0;
}

uint32_t vm_get_id(struct vm *vm)
{
    return vm->vmid;
}

void vmexit(struct gpreg_context *regs)
{
    struct vcpu *vcpu = vm_get_current_vcpu();
    assert(vcpu != NULL);
    vcpu_set_gpreg(vcpu, regs);
    vm_import_sysreg(vcpu->vm, vcpu->vcpu_id);
    vcpu->pc = read_elr_el2();
    vcpu->cpsr = read_spsr_el2();
    vcpu->excpreg.elr = read_elr_el2();
    vcpu->excpreg.spsr = read_spsr_el2();
    vcpu->excpreg.esr = read_esr_el2();
    vcpu->excpreg.far = read_far_el2();

    struct plugin *plugin;
    for_each_plugin(plugin) {
        if (plugin->vmexit != NULL) {
            int ret = plugin->vmexit(vcpu);
            if (ret != 0)
                panic("Plugin %p refuse to exit VM %u\n", plugin, vcpu->vm->vmid);
        }
    }
}

vaddr_t vcpu_get_fault_addr(struct vcpu *vcpu)
{
    switch (AARCH64_ESR_EC(vcpu->excpreg.esr)) {
        case AARCH64_EC_DA_LOW:
            return vcpu->excpreg.far;
        default:
            return 0;
    }
}

struct vm *vcpu_get_vm(struct vcpu *vcpu)
{
    return vcpu->vm;
}

void *vm_get_plugin_data(struct vm *vm, size_t i)
{
    if (i >= get_plugin_num())
        return NULL;
    else
        return vm->plugin_data[i];
}

uint32_t vcpu_get_fault_type(struct vcpu *vcpu)
{
    assert(vcpu == vm_get_current_vcpu());
    uint32_t inst = vm_get_current_vcpu_instr();
    switch (aarch64_instr_get_op(inst)) {
        case AARCH64_OP_STR_R_8:
        case AARCH64_OP_STR_IMM_8:
        case AARCH64_OP_STUR_8:
            return FAULT_WRITE8;
        case AARCH64_OP_STR_IMM_16:
        case AARCH64_OP_STR_R_16:
        case AARCH64_OP_STUR_16:
            return FAULT_WRITE16;
        case AARCH64_OP_LDR_IMM_32:
            return FAULT_READ32;
        case AARCH64_OP_STR_IMM_32:
        case AARCH64_OP_STR_R_32:
        case AARCH64_OP_STUR_32:
            return FAULT_WRITE32;
        case AARCH64_OP_STR_IMM_64:
        case AARCH64_OP_STR_R_64:
        case AARCH64_OP_STUR_64:
            return FAULT_WRITE64;//
        case AARCH64_OP_STXR_64:
            return FAULT_WRITE64_S;//should update the status register
        case AARCH64_OP_LDR_IMM_16:
            return FAULT_READ16;
        case AARCH64_OP_LDR_IMM_POST_64:
            return FAULT_READ64;//
        case AARCH64_OP_STP_IMM_64:
        case AARCH64_OP_STNP_128:
            return FAULT_WRITE128;//
        case AARCH64_OP_DC:
            return FAULT_DC;
        case AARCH64_OP_STP_32:
        case AARCH64_OP_STNP_32:
            return FAULT_WRITE32_2;
        default:
            EMSG("Unknown instr 0x%x\n", inst);
            return FAULT_UNKNOWN;
    }
}

uint32_t vcpu_get_fault_reg(struct vcpu *vcpu)
{
    assert(vcpu == vm_get_current_vcpu());
    uint32_t inst = vm_get_current_vcpu_instr();
    return REG_GP0 + aarch64_instr_get_Rt(inst);
}

int vcpu_set_reg(struct vcpu *vcpu, uint32_t reg_id, uint64_t v)
{
    if (reg_id >= REG_GP0 && reg_id < REG_GP0 + 31) {
        vcpu->gpreg.x[reg_id - REG_GP0] = v;
        return 0;
    } else {
        switch (reg_id) {
            case REG_ELR_EL1:
                vcpu->sysreg.elr_el1 = v;
                return 0;
            default:
                return -EINVAL;
        }
    }
}

int vcpu_get_reg(struct vcpu *vcpu, uint32_t reg_id, uint64_t *v)
{
    if (reg_id >= REG_GP0 && reg_id < REG_GP0 + 31) {
        *v = vcpu->gpreg.x[reg_id - REG_GP0];
        return 0;
    } else {
        switch (reg_id) {
            case REG_GP0 + 31:
                *v = 0;
                return 0;
            case REG_ELR_EL1:
                *v = vcpu->sysreg.elr_el1;
                return 0;
            case REG_VBAR_EL1:
                *v = vcpu->sysreg.vbar_el1;
                return 0;
            case REG_ESR_EL1:
                *v = vcpu->sysreg.esr_el1;
                return 0;
            case REG_SPSR_EL1:
                *v = vcpu->sysreg.spsr_el1;
                return 0;
            case REG_TTBR0_EL1:
                *v = vcpu->sysreg.ttbr0_el1;
                return 0;
            default:
                return -EINVAL;
        }
    }
}

uint64_t vcpu_get_reg_force(struct vcpu *vcpu, uint32_t reg_id)
{
    uint64_t v;
    assert(vcpu_get_reg(vcpu, reg_id, &v) == 0);
    return v;
}

int vcpu_has_irq(struct vcpu *vcpu)
{
#ifdef HAS_GIC
    return gic_has_irq(vcpu);
#else
    return -ENOSYS;
#endif
}

int vm_copy_trap(struct vm *dst, struct vm *src)
{
    for (uint32_t i = 0; i < MAX_TRAP_TYPE; i++) {
        struct trap_handler_list *p, *p2, *p3;
        list_for_each_entry_safe(p, p2, &dst->trap_handlers[i], list)
            free(p);
        list_init(&dst->trap_handlers[i]);
        list_for_each_entry(p, &src->trap_handlers[i], list) {
            int res = vm_add_trap_handler(dst, i, p->handler, p->arg);
            if (res != 0) {
                EMSG("vm_copy_trap failed: %d\n", res);
                list_for_each_entry_safe(p2, p3, &dst->trap_handlers[i], list)
                    free(p2);
                return res;
            }
        }
        if (get_bit(&src->trap, i))
            set_bit(&dst->trap, i);
        else
            clear_bit(&dst->trap, i);
    }

    return 0;
}

struct vm *dom0 = NULL;
static int init_dom0(void)
{
    if (dom0 == NULL) {
        dom0 = vm_create();
        if (dom0 == NULL)
            return -1;
        assert(dom0->vmid == 0);

        struct vm_area vma;
        /*set entry of ept*/
        vma.va = 0;
        vma.pa = 0;/*va == pa*/
        vma.size = (1ULL << dom0->s2pt->va_bit);
        vma.valid = 1;
        vma.ro = 0;
        vma.xn = 0;
        vma.nocache = 0;
        vma.device = 0;
        vma.forbidden = 0;/*tww forbidden == 1: forbidden access; forbidden == 0 and bit0 == 0: entry is not vaild*/
        if (mmu_apply_vma_nooverwrite(dom0->s2pt, &vma) != 0) {//s2pt: ept
            EMSG("Allow Dom0 access whole memory failed\n");
            vm_destroy(dom0);
            dom0 = NULL;
            return -1;
        }

        vma.va = virt_to_phys(HYPERVISOR_RAM_VA);
        vma.pa = virt_to_phys(HYPERVISOR_RAM_VA);//tww: in order to unmap the memory of hypervisor in the s2pt of dom0
        vma.size = HYPERVISOR_RAM_SIZE;
        vma.valid = 1;
        vma.forbidden = 1; 
        if (mmu_apply_vma(dom0->s2pt, &vma) != 0) {
            EMSG("Deny Dom0 access hypervisor RAM failed\n");
            vm_destroy(dom0);
            dom0 = NULL;
            return -1;
        }
    }
    vcpu_set_gpreg(vm_get_vcpu(dom0, get_core_pos()), boot_context[get_core_pos()]);
    vm_import_sysreg(dom0, get_core_pos());
    //tww: set somes register values of vcpu
    dom0->vcpu[get_core_pos()].pc = read_elr_el2();
    dom0->vcpu[get_core_pos()].cpsr = read_spsr_el2();
    vm_add_trap_handler(dom0, TRAP_SMC, vcpu_redirect_smc, NULL);
    dsb(sy);
    tlbi("alle1");
    dsb(sy);

    return 0;
}
register_init(arch, init_dom0);
