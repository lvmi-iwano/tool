#include <hypervisor.h>
#include <arch/aarch64.h>
#include <smc.h>
#include <printf.h>

int hyp_enable_smc_trap(void)
{
	write_hcr_el2(read_hcr_el2() | AARCH64_HCR_TSC);
	return 0;
}

void do_smc(struct smc_param *param)
{
	asm volatile (
		"mov x30, %0\n"
		"ldp x0, x1, [x30], #16\n"
		"ldp x2, x3, [x30], #16\n"
		"ldp x4, x5, [x30], #16\n"
		"ldr x6, [x30], #8\n"
		"smc #0\n"
		"stp x0, x1, [x30], #16\n"
		"stp x2, x3, [x30], #16\n"
		:
		: "r"(param)
		: "memory", "x0", "x1", "x2", "x3", "x4", "x5", "x6", "x7", "x8", "x9", "x10", "x11", "x12", "x13", "x14", "x15", "x16", "x17", "x30");
}
