#include <init.h>
#include <hypervisor.h>
#include <compiler.h>
#include <arch/exception.h>
#include <psci.h>
#include <printf.h>
#include <smc.h>
#include <plat/platform_config.h>
#include <arch/aarch64.h>
#include <arch/barrier.h>
#include <arch/cache.h>
#include <arch/mmu.h>
#include <arch/vmm.h>
#include <assert.h>
#include <smp.h>

static uint8_t booting[NUM_CORES] __data = { 0 };
static struct {
	uint64_t elr;
	uint64_t x0;
} boot_param[NUM_CORES];

static int smc_psci(struct vcpu *vcpu, void *arg __unused)
{
	struct smc_param param;
	param.func_id = vcpu->gpreg.x[0];
	param.arg0 = vcpu->gpreg.x[1];
	param.arg1 = vcpu->gpreg.x[2];
	param.arg2 = vcpu->gpreg.x[3];
	param.arg3 = vcpu->gpreg.x[4];
	param.arg4 = vcpu->gpreg.x[5];
	param.arg5 = vcpu->gpreg.x[6];

	switch (vcpu->gpreg.x[0]) {
	case PSCI_FUNC_ID_PSCI_VERSION:
	case PSCI_FUNC_ID_AFFINITY_INFO_32:
	case PSCI_FUNC_ID_AFFINITY_INFO_64:
	case PSCI_FUNC_ID_MIGRATE_32:
	case PSCI_FUNC_ID_MIGRATE_64:
	case PSCI_FUNC_ID_MIGRATE_INFO_TYPE:
	case PSCI_FUNC_ID_MIGRATE_INFO_UP_CPU_32:
	case PSCI_FUNC_ID_MIGRATE_INFO_UP_CPU_64:
	case PSCI_FUNC_ID_SYSTEM_OFF:
	case PSCI_FUNC_ID_SYSTEM_RESET:
	case PSCI_FUNC_ID_PSCI_FEATURES:
	case PSCI_FUNC_ID_CPU_FREEZE:
	case PSCI_FUNC_ID_CPU_DEFAULT_SUSPEND_32:
	case PSCI_FUNC_ID_CPU_DEFAULT_SUSPEND_64:
	case PSCI_FUNC_ID_NODE_HW_STATE_32:
	case PSCI_FUNC_ID_NODE_HW_STATE_64:
	case PSCI_FUNC_ID_PSCI_SET_SUSPEND_MODE:
	case PSCI_FUNC_ID_PSCI_STAT_RESIDENCY_32:
	case PSCI_FUNC_ID_PSCI_STAT_RESIDENCY_64:
	case PSCI_FUNC_ID_PSCI_STAT_COUNT_32:
	case PSCI_FUNC_ID_PSCI_STAT_COUNT_64:
		break;
	case PSCI_FUNC_ID_CPU_OFF:
		cpu_down();
		dcache_flush_all();
		break;
	case PSCI_FUNC_ID_CPU_ON_32:
		param.arg0 = (uint32_t) vcpu->gpreg.x[1];
		param.arg1 = (uint32_t) vcpu->gpreg.x[2];
		param.arg2 = (uint32_t) vcpu->gpreg.x[3];
		param.func_id = PSCI_FUNC_ID_CPU_ON_64;
	case PSCI_FUNC_ID_CPU_ON_64: {
		uint32_t cpu_pos = (param.arg0 & 0x3) | ((param.arg0 & 0x300) >> 6);
		boot_param[cpu_pos].x0 = param.arg2;
		boot_param[cpu_pos].elr = param.arg1;
		param.arg1 = virt_to_phys((vaddr_t) hyp_secondary_start);
		booting[cpu_pos] = 1;
		cpu_going_up(cpu_pos);
		break; }
	case PSCI_FUNC_ID_CPU_SUSPEND_32:
	case PSCI_FUNC_ID_CPU_SUSPEND_64: {
		uint32_t cpu_pos = get_core_pos();
		if (vcpu_has_irq(vm_get_vcpu(dom0, cpu_pos)) > 0) {
			vcpu->gpreg.x[0] = -2;
			vcpu->pc += 4;
			return 0;
		}
		cpu_down();
		param.arg1 = virt_to_phys((vaddr_t) hyp_resume);
		booting[get_core_pos()] = 1;
		boot_param[get_core_pos()].elr = vcpu->gpreg.x[2];
		dcache_flush_all();
		break; }
	case PSCI_FUNC_ID_SYSTEM_SUSPEND_32:
	case PSCI_FUNC_ID_SYSTEM_SUSPEND_64:
//		param.arg0 = (uint64_t) hyp_resume;
//		booting[0] = 1;
//		boot_param[0].elr = regs->x[1];
//		dmb();
		break;
	default:
		return 1;
	}

	do_smc(&param);
	vcpu->gpreg.x[0] = param.ret0;
	vcpu->gpreg.x[1] = param.ret1;
	vcpu->gpreg.x[2] = param.ret2;
	vcpu->gpreg.x[3] = param.ret3;
	vcpu->pc += 4;
	return 0;
}

static int psci_init(void)
{
	int res;

	assert(dom0 != NULL);
	vm_enable_trap(dom0, TRAP_SMC);
	res = vm_add_trap_handler(dom0, TRAP_SMC, smc_psci, NULL);
	if (res != 0)
		return res;

	if (booting[get_core_pos()]) {
//		assert(warm_boot[get_core_pos()] == BOOT_TYPE_SECONDARY || warm_boot[get_core_pos()] == BOOT_TYPE_WARM);
		dom0->vcpu[get_core_pos()].gpreg.x[0] = boot_param[get_core_pos()].x0;
		dom0->vcpu[get_core_pos()].pc = boot_param[get_core_pos()].elr;
		dom0->vcpu[get_core_pos()].cpsr = AARCH64_SPSR(AARCH64_MODE_EL1h, AARCH64_SPSR_DAIF);
		booting[get_core_pos()] = 0;
	} else if (warm_boot[get_core_pos()] != BOOT_TYPE_COLD) {
		EMSG("Unexcepted boot of core %d\n", get_core_pos());
		for (;;);
	}

	return 0;
}

register_init(platform, psci_init);
