#if defined(__aarch64__)
#include <arch/aarch64.h>
#elif defined(__arm__)
#include <arch/arm.h>
#else
#error "Unknown platform"
#endif
