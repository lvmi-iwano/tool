#ifndef LIBHYPERVISOR_VDEVICE_H_
#define LIBHYPERVISOR_VDEVICE_H_

#include <stdint.h>
#include <hypervisor.h>

struct vdevice_mmio_range {
	paddr_t addr;
	size_t size;
	int (*read)(struct vcpu *vcpu, paddr_t addr, uint32_t access_size, uint64_t *v, void *data);//vgicd_read
	int (*write)(struct vcpu *vcpu, paddr_t addr, uint32_t access_size, uint64_t v, void *data);//vgicd_write
};
struct vdevice {
	struct vdevice_mmio_range *mmio;
	int (*init)(struct vm *vm, void **pdata);
	void (*deinit)(struct vm *vm, void *data);
};

int vdevice_handle_access(struct vcpu *vcpu);
int vdevice_add(struct vm *vm, const struct vdevice *desc);

#endif
