#ifndef LIBHYPERVISOR_BLIST_H_
#define LIBHYPERVISOR_BLIST_H_

#ifndef __ASSEMBLER__

#include <compiler.h>
#include <list.h>
#include <string.h>

struct blist_head {
	struct list_head list;
	size_t n, alloc, size;
	uint64_t self;
};

struct blist_block {
	struct list_head list;
	size_t n, alloc, size;
	uint8_t data[] __aligned(8);
};

struct packed64 {
	uint64_t v;
} __packed;

#define BLIST_INITIALIZER(name, alloc, size) \
	{ \
		.list = LIST_INITIALIZER(name.list), \
		.alloc = alloc, \
		.size = size, \
		.n = n, \
		.self = (uint64_t) &name \
	}

#define DEFINE_BLIST(name, alloc, size) \
	struct blist_head name = BLIST_INITIALIZER(name, alloc, size)
#define DEFINE_STATIC_BLIST(name, alloc, size) \
	static struct blist_head name = BLIST_INITIALIZER(name, alloc, size)

static inline void blist_init(struct blist_head *list, size_t alloc, size_t size)
{
	list_init(&list->list);
	list->alloc = alloc;
	list->size = size;
	list->n = 0;
	list->self = (uint64_t) list;
}

static inline void blist_add(const void *v, struct blist_head *list)
{
	if (list_empty(&list->list) || list_first_entry(&list->list, struct blist_block, list)->n == list->alloc) {
		struct blist_block *block = (struct blist_block *) malloc(sizeof(struct blist_block) + list->alloc * (list->size + sizeof(uint64_t)));
		block->n = 0;
		block->size = list->size;
		block->alloc = list->alloc;
		list_add(&block->list, &list->list);
		blist_add(v, list);
	} else {
		struct blist_block *block = list_first_entry(&list->list, struct blist_block, list);
		for (size_t i = block->n; i > 0; i--)
			memcpy(&block->data[i * (list->size + sizeof(uint64_t))], &block->data[(i - 1) * (list->size + sizeof(uint64_t))], list->size + sizeof(uint64_t));
		memcpy(&block->data[sizeof(uint64_t)], v, list->size);
		((struct packed64 *) &block->data[0])->v = (uint64_t) block;
		block->n++;
	}
}

static inline int blist_add_tail(const void *v, struct blist_head *list)
{
	if (list_empty(&list->list) || list_last_entry(&list->list, struct blist_block, list)->n == list->alloc) {
		struct blist_block *block = (struct blist_block *) malloc(sizeof(struct blist_block) + list->alloc * (list->size + sizeof(uint64_t)));
		if (block == NULL)
			return -ENOMEM;
		block->n = 0;
		block->size = list->size;
		block->alloc = list->alloc;
		list_add_tail(&block->list, &list->list);
		return blist_add_tail(v, list);
	} else {
		struct blist_block *block = list_last_entry(&list->list, struct blist_block, list);
		memcpy(&block->data[block->n * (list->size + sizeof(uint64_t)) + sizeof(uint64_t)], v, list->size);
		((struct packed64 *) &block->data[block->n * (list->size + sizeof(uint64_t))])->v = (uint64_t) block;
		block->n++;
		return 0;
	}
}

static inline void blist_del(void *v)
{
	struct blist_block *block = (struct blist_block *) ((struct packed64 *) &((uint8_t *) v)[-sizeof(uint64_t)])->v;
	size_t i = (&((uint8_t *) v)[-sizeof(uint64_t)] - block->data) / (block->size + sizeof(uint64_t));
	for (size_t j = i + 1; j < block->n; j++)
		memcpy(&block->data[(j - 1) * (block->size + sizeof(uint64_t))], &block->data[j * (block->size + sizeof(uint64_t))], block->size + sizeof(uint64_t));
	if (--(block->n) == 0 && block->list.next->next != &block->list) {
		list_del(&block->list);
		free(block);
	}
}

static inline uint8_t blist_empty(struct blist_head *list)
{
	return list_empty(&list->list) || (list_first_entry(&list->list, struct blist_block, list)->n == 0);
}

#define blist_first_entry(_list, type) \
	({ \
		struct blist_block *block = list_first_entry(&(_list)->list, struct blist_block, list); \
		type *ret; \
		if (block->n) \
			ret = (type *) &block->data[sizeof(uint64_t)]; \
		else \
			ret = blist_hang_entry(_list); \
		ret; \
	})
#define blist_last_entry(_list, type) \
	({ \
		struct blist_block *block = list_last_entry(&(_list)->list, struct blist_block, list); \
		type *ret; \
		if (block->n) \
			ret = (type *) &block->data[(block->n - 1) * (block->size + sizeof(uint64_t)) + sizeof(uint64_t)]; \
		else \
			ret = blist_hang_entry(_list); \
		ret; \
	})

#define blist_hang_entry(_list) \
	((void *) &(list_entry(&(_list)->list, struct blist_block, list))->data[sizeof(uint64_t)])

#define blist_next_entry(pos) \
	({ \
		void *ret; \
		struct blist_block *block = (struct blist_block *) ((struct packed64 *) &((uint8_t *) pos)[-sizeof(uint64_t)])->v; \
		size_t i = (&((uint8_t *) pos)[-sizeof(uint64_t)] - block->data) / (block->size + sizeof(uint64_t)); \
		if (i + 1 >= block->n) { \
			block = list_next_entry(block, list); \
			ret = &block->data[sizeof(uint64_t)]; \
		} else \
			ret = ((uint8_t *) pos) + block->size + sizeof(uint64_t); \
		ret; \
	})
/*
#define list_prev_entry(pos, member) \
	list_entry((pos)->member.prev, typeof(*(pos)), member)
*/

#define blist_for_each_entry(pos, head) \
	for (pos = blist_first_entry(head, typeof(*pos)); \
	     (void *) pos != (void *) blist_hang_entry(head); \
	     pos = blist_next_entry(pos))

/*
#define list_for_each_entry_reverse(pos, head, member) \
	for (pos = list_last_entry(head, typeof(*pos), member); \
	     &pos->member != (head); \
	     pos = list_prev_entry(pos, member))
*/

#define blist_for_each_entry_safe(pos, n, head) \
	for (pos = blist_first_entry(head, typeof(*pos)), \
	     n = blist_next_entry(pos); \
	     (void *) pos != (void *) blist_hang_entry(head); \
	     pos = n, n = blist_next_entry(n))

/*
#define list_for_each_entry_safe_reverse(pos, n, head, member) \
	for (pos = list_last_entry(head, typeof(*pos), member), \
	     n = list_prev_entry(pos, member); \
	     &pos->member != (head); \
	     pos = n, n = list_prev_entry(n, member))
*/
#endif

#endif
