#ifndef LIBHYPERVISOR_STDINT_H_
#define LIBHYPERVISOR_STDINT_H_

#ifndef __ASSEMBLER__
#include_next <stdint.h>
typedef __SIZE_TYPE__ size_t;
#if __SIZEOF_SIZE_T__ == 8
typedef int64_t ssize_t;
#elif __SIZEOF_SIZE_T__ == 4
typedef int32_t ssize_t;
#endif
#if __SIZEOF_POINTER__ == 8
typedef uint64_t vaddr_t;
typedef uint64_t paddr_t;
#elif __SIZEOF_POINTER__ == 4
typedef uint32_t vaddr_t;
typedef uint32_t paddr_t;
#endif
#endif
#endif
