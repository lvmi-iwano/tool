#ifndef LIBHYPERVISOR_CTYPES_H_
#define LIBHYPERVISOR_CTYPES_H_

#include <stdint.h>

struct ctype {
	uint8_t isupper:1; // UPPERCASE.
	uint8_t islower:1; // lowercase.
	uint8_t isalpha:1; // Alphabetic.
	uint8_t isdigit:1; // Numeric.
	uint8_t isxdigit:1; // Hexadecimal numeric.
	uint8_t isspace:1; // Whitespace.
	uint8_t isprint:1; // Printing.
	uint8_t isgraph:1; // Graphical.
	uint8_t isblank:1; // Blank (usually SPC and TAB).
	uint8_t iscntrl:1; // Control character.
	uint8_t ispunct:1; // Punctuation.
	uint8_t isalnum:1; // Alphanumeric.
};

extern const struct ctype __ctype[];

#define __is_func(name) \
	static inline uint8_t name(uint8_t ch) { return __ctype[ch].name; }

__is_func(isupper);
__is_func(isprint);

#endif
