#ifndef LIBHYPERVISOR_PPOOL_H_
#define LIBHYPERVISOR_PPOOL_H_

#include <list.h>
#include <arch/spinlock.h>
#include <compiler.h>
#include <arch.h>

struct page_header {
	struct page_header *prev, *next;
	struct page_header *hole_start, *hole_end;
} __aligned(PAGE_SIZE);

struct ppool {
	struct page_header *fph;
	spinlock_t lock;
};

void ppool_init(struct ppool *pool);
void ppool_add(struct ppool *pool, vaddr_t start, vaddr_t end);
void *ppool_alloc(struct ppool *pool, size_t num);
void *ppool_alloc_aligned(struct ppool *pool, size_t num, uint32_t align);
void *ppool_alloc_last(struct ppool *pool, size_t num);
void *ppool_alloc_last_aligned(struct ppool *pool, size_t num, uint32_t align);
void ppool_free(struct ppool *pool, void *p, size_t num);
int ppool_validate(struct ppool *pool);
void ppool_dump(struct ppool *pool);

#endif
