#ifndef LIBHYPERVISOR_INIT_H_
#define LIBHYPERVISOR_INIT_H_

#include <compiler.h>
#include <hypervisor.h>
#include <assert.h>

void hyp_start(void);
void hyp_init(int boot_type, struct gpreg_context *boot_context);
void hyp_resume(void);
void hyp_secondary_start(void);

#define register_init(sect, func) \
	static int (*__registed_##sect##_##func)(void) __section(".initcall." #sect) __used = func
#define call_init(sect) \
	({ \
		int res = 0; \
		typedef int (initcall_t)(void); \
		extern void *__initcall_##sect##_start; \
		extern void *__initcall_##sect##_end; \
		for (void **call = &__initcall_##sect##_start; call != &__initcall_##sect##_end; call++) { \
			if ((*call) != NULL) \
				assert((((initcall_t *) (*call))()) == 0); \
		} \
		res; \
	})
#define register_driver_init(func) \
	register_init(driver, func)

#endif
