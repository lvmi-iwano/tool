#ifndef LIBHYPERVISOR_PLUGIN_H_
#define LIBHYPERVISOR_PLUGIN_H_

struct plugin {
	size_t idx;
	int (*init)(struct vm *vm, void **pdata);
	void (*deinit)(struct vm *vm, void *data);
	int (*vmexit)(struct vcpu *vcpu);
	int (*vmenter)(struct vcpu *old_vcpu, struct vcpu *new_vcpu);
};
#define register_plugin_order(order, _plugin) \
	static struct plugin *__registed_plugin_##order##_##_plugin __section(".plugin") __used = &_plugin
#define register_plugin(_plugin) \
	register_plugin_order(99, _plugin)

extern struct plugin *__plugin_start;
extern struct plugin *__plugin_end;
static size_t get_plugin_num(void)
{
	return &__plugin_end - &__plugin_start;
}
void *vm_get_plugin_data(struct vm *vm, size_t i);
#define get_plugin_data(vm, _plugin) \
	({ extern struct plugin _plugin; vm_get_plugin_data(vm, _plugin.idx); })

#define for_each_plugin(var_plugin) \
	for (struct plugin **__pplugin = &__plugin_start; \
	     (__pplugin != &__plugin_end) && (var_plugin = *__pplugin); \
	     __pplugin++)

#endif
