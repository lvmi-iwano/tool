#ifndef LINKAGE_H_
#define LINKAGE_H_

#ifdef __ASSEMBLER__
#define ENTRY(x) \
	.globl x; \
	.align 4, 0x90; \
	x:
#define END(x) \
	.size x, . - x
#define ENDPROC(x) \
	.type x, function; \
	END(x)
#endif

#endif
