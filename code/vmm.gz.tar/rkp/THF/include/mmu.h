#ifndef LIBHYPERVISOR_MMU_H_
#define LIBHYPERVISOR_MMU_H_

#ifndef __ASSEMBLER__

#include <list.h>
#include <stdint.h>

struct vm_area {
	struct list_head list;
	vaddr_t va;
	paddr_t pa;
	size_t size;
	void *data;
	uint8_t valid:1;
	uint8_t ro:1;
	uint8_t nocache:1;
	uint8_t xn:1;
	uint8_t device:1;
	uint8_t forbidden:1;
};

struct mmu_table;
struct pt_entry;
extern struct mmu_table *s1pt;
struct mmu_table *s1pt_alloc(uint8_t va_bit);
struct mmu_table *s2pt_alloc(uint8_t va_bit);
void mmu_free(struct mmu_table *table);
int mmu_populate(struct mmu_table *table, struct vm_area *vma_list);
int mmu_apply_vma(struct mmu_table *table, struct vm_area *vma);
int mmu_apply_vma_nooverwrite(struct mmu_table *table, struct vm_area *vma);
int s1pt_apply(struct mmu_table *table);
int s2pt_apply(struct mmu_table *table, uint8_t vmid);
struct mmu_table *s1pt_export(void);
struct mmu_table *s2pt_export(void);
struct mmu_table *mmu_fork(struct mmu_table *table);
int mmu_check(struct mmu_table *table);
typedef int (mmu_traverse_func_t)(struct mmu_table *table, struct pt_entry *entry,
                                  uint8_t level, paddr_t pa, vaddr_t va, void *arg);
int mmu_traverse(struct mmu_table *table, mmu_traverse_func_t *func, void *arg);
void mmu_dump(struct mmu_table *table);
int pte_valid(struct mmu_table *table, uint8_t level, struct pt_entry *entry);
int pte_writable(struct mmu_table *table, uint8_t level, struct pt_entry *entry);
int pte_executable(struct mmu_table *table, uint8_t level, struct pt_entry *entry);

vaddr_t phys_to_virt(paddr_t x);
paddr_t virt_to_phys(vaddr_t x);
void *ioremap(vaddr_t base, size_t size);

#endif

#endif
