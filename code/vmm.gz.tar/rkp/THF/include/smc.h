#ifndef LIBHYPERVISOR_SMC_H_
#define LIBHYPERVISOR_SMC_H_

#define SMC_FUNC_ID(call_type, call_bit, service_range, func_id) \
	(((call_type) & 0x80000000U) | ((call_bit) & 0x40000000U) | ((service_range) & 0x3F000000U) | ((func_id) & 0xFFFFU))
#define SMC_YIELD_CALL              0x00000000U
#define SMC_FAST_CALL               0x80000000U
#define SMC_32_CALL                 0x00000000U
#define SMC_64_CALL                 0x40000000U
#define SMC_STD_SECURE_SERVICE_CALL 0x04000000U

#define SMC_CALL_IS_YIELD(id) (!((id) & 0x80000000U))
#define SMC_CALL_IS_FAST(id) (!!((id) & 0x80000000U))
#define SMC_CALL_IS_32(id) (!((id) & 0x80000000U))
#define SMC_CALL_IS_64(id) (!((id) & 0x80000000U))
#define SMC_CALL_SERVICE_RANGE(id) ((id) & 0x3F000000U)

struct smc_param {
	uint64_t func_id;
	uint64_t arg0;
	uint64_t arg1;
	uint64_t arg2;
	uint64_t arg3;
	uint64_t arg4;
	uint64_t arg5;
	uint64_t ret0;
	uint64_t ret1;
	uint64_t ret2;
	uint64_t ret3;
};
void do_smc(struct smc_param *param);

#endif
