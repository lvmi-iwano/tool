#ifndef LIBHYPERVISOR_HYPERVISOR_H_
#define LIBHYPERVISOR_HYPERVISOR_H_

#include <stdint.h>
#include <arch/exception.h>
#include <plat/platform_config.h>
#include <arch.h>
#include <mmu.h>

#ifndef __ASSEMBLER__
struct gpreg_context;
struct sysreg_context;
struct exception_context;
struct vm;
struct vcpu;

uint32_t get_core_pos(void);
void *get_core_stack(void);

extern volatile uint8_t warm_boot[NUM_CORES];
extern struct gpreg_context *boot_context[NUM_CORES];

struct vm *vm_create(void);
struct vm *vm_fork(struct vm *vm);
void vm_destroy(struct vm *vm);
void vm_run(struct vcpu *vcpu);
int vm_import_sysreg(struct vm *vm, uint8_t vcpu);
int vm_set_pt(struct vm *vm, struct mmu_table *table);
struct vm *vm_get_current(void);
void vm_set_current_vcpu(struct vcpu *vcpu);
struct vcpu *vm_get_current_vcpu(void);
void vm_set_next_vcpu(struct vcpu *vcpu);
struct vcpu *vm_get_next_vcpu(void);
int vcpu_handle_irq(struct vcpu *vcpu);
int vcpu_handle_fiq(struct vcpu *vcpu);
void vcpu_handle_exception(struct vcpu *vcpu);
struct vcpu *vm_get_vcpu(struct vm *vm, uint8_t vcpu);
struct mmu_table *vm_get_s2pt(struct vm *vm);
struct mmu_table *vcpu_export_s1pt0(struct vcpu *vcpu);
void vcpu_set_pc(struct vcpu *vcpu, uint64_t pc);
void vcpu_set_cpsr(struct vcpu *vcpu, uint32_t cpsr);
void vcpu_set_sysreg(struct vcpu *vcpu, const struct sysreg_context *sysreg);
void vcpu_set_gpreg(struct vcpu *vcpu, const struct gpreg_context *gpreg);
struct sysreg_context *vcpu_get_sysreg(struct vcpu *vcpu);
struct gpreg_context *vcpu_get_gpreg(struct vcpu *vcpu);
uint8_t vcpu_get_id(struct vcpu *vcpu);
uint64_t vcpu_get_pc(struct vcpu *vcpu);
uint32_t vcpu_get_cpsr(struct vcpu *vcpu);
uint32_t vm_get_id(struct vm *vm);
void vmexit(struct gpreg_context *regs);
struct vm *vcpu_get_vm(struct vcpu *vcpu);
int vcpu_get_reg(struct vcpu *vcpu, uint32_t reg_id, uint64_t *v);
uint64_t vcpu_get_reg_force(struct vcpu *vcpu, uint32_t reg_id);
int vcpu_set_reg(struct vcpu *vcpu, uint32_t reg_id, uint64_t v);
int vm_copy_trap(struct vm *dst, struct vm *src);

#define FAULT_UNKNOWN   0
#define FAULT_READ8     1
#define FAULT_WRITE8    2
#define FAULT_READ16    3
#define FAULT_WRITE16   4
#define FAULT_READ32    5
#define FAULT_WRITE32   6
#define FAULT_READ64    7
#define FAULT_WRITE64   8
#define FAULT_READ128   9
#define FAULT_WRITE128  10
#define FAULT_DC        11
#define FAULT_WRITE32_2 12
#define FAULT_WRITE64_S 13

vaddr_t vcpu_get_fault_addr(struct vcpu *vcpu);
uint32_t vcpu_get_fault_type(struct vcpu *vcpu);
#define REG_UNKNOWN    0
#define REG_GP0        1
#define REG_ELR_EL1    0x100
#define REG_VBAR_EL1   0x101
#define REG_ESR_EL1    0x102
#define REG_SPSR_EL1   0x103
#define REG_TTBR0_EL1  0x104
uint32_t vcpu_get_fault_reg(struct vcpu *vcpu);

#define TRAP_SMC          0
#define TRAP_HVC          1
#define TRAP_READ_IDREG2  2
#define TRAP_WRITE_VMEMCTRL 3
#define TRAP_DA           4
#define TRAP_IA           5
#define TRAP_IRQ          6
#define TRAP_FIQ          7
#define MAX_TRAP_TYPE     8

#define RTKP_INIT 0
#define RTKP_PGD_FREE 1
//#define RTKP_PUD_FREE
#define RTKP_PMD_FREE 2
#define RTKP_PTE_FREE 3
#define RTKP_PGD_CREATE 4
//#define RTKP_PUD_CREATE //not used for 64 bit
#define RTKP_PMD_CREATE 5
#define RTKP_PTE_CREATE 6

/*for attack test*/
#define RTKP_EXECUTE 10

typedef int (trap_handler_t)(struct vcpu *vcpu, void *arg);
int vm_enable_trap(struct vm *vm, uint32_t type);
int vm_add_trap_handler(struct vm *vm, uint32_t type, trap_handler_t *handler, void *arg);
int vm_remove_trap_handler(struct vm *vm, uint32_t type, trap_handler_t *handler, void *arg);

int vcpu_assert_irq(struct vcpu *vcpu);
int vcpu_deassert_irq(struct vcpu *vcpu);
int vcpu_has_irq(struct vcpu *vcpu);

int vcpu_read_u32(struct vcpu *vcpu, vaddr_t va, uint32_t *v);
int vcpu_read_u64(struct vcpu *vcpu, vaddr_t va, uint64_t *v);
uint32_t vm_get_current_vcpu_instr();
uint32_t vcpu_get_instr(struct vcpu *vcpu);
struct vm *dom0;
int vcpu_gva_to_gpa_el1(struct vcpu *vcpu, uint64_t va, uint64_t *pa);
int vcpu_gva_to_gpa_el0(struct vcpu *vcpu, uint64_t va, uint64_t *pa);
int vcpu_gva_to_gpa(struct vcpu *vcpu, uint64_t va, uint64_t *pa);
int vcpu_gva_to_hpa_el1(struct vcpu *vcpu, uint64_t va, uint64_t *pa);
int vcpu_gva_to_hpa_el0(struct vcpu *vcpu, uint64_t va, uint64_t *pa);
int vcpu_gva_to_hpa(struct vcpu *vcpu, uint64_t va, uint64_t *pa);

uint32_t disable_interrupt(void);
void resume_interrupt(uint32_t interrupt);
void backup_sysreg(struct sysreg_context *sysreg);
void restore_sysreg(struct sysreg_context *sysreg);
#endif
#define BOOT_TYPE_WARM 1
#define BOOT_TYPE_COLD 0
#define BOOT_TYPE_SECONDARY 2

#define HYPERVISOR_RAM_VA (512 * PAGE_SIZE) //2M aligned

#endif
