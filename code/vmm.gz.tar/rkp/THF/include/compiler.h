#ifndef COMPILER_H_
#define COMPILER_H_

#include <stdint.h>

#define __section(name) __attribute__((section(name)))
#define __used __attribute__((used))
#define __unused __attribute__((unused))
#define __weak __attribute__((weak))
#define NULL (void *) 0
#define __printf(archetype, sindex, aindex) __attribute__((format(archetype, sindex, aindex)))
#define __aligned(align) __attribute__((aligned(align)))
#define __data __section(".data")
#define __packed __attribute__((packed))

#ifdef __compiler_offsetof
#define offsetof(TYPE,MEMBER) __compiler_offsetof(TYPE,MEMBER)
#else
#define offsetof(TYPE, MEMBER) ((size_t) &((TYPE *) 0)->MEMBER)
#endif
#define container_of(ptr, type, member) ({ \
	const typeof(((type *) 0)->member) *__mptr = (ptr); \
	(type *) ((uint8_t *) __mptr - offsetof(type, member));})
/*tww: get the original value x if aligned, otherwise get the start address of a next aligned range*/
#define ROUNDUP(x, align) \
	({ \
		uint64_t _x = (x); \
		uint64_t _align = (align); \
		(_x + _align - 1) / _align * _align; \
	})
/*tww: get the original value x if aligned, get the start address of a previous aligned range*/
#define ROUNDDOWN(x, align) \
	({ \
		uint64_t _x = (x); \
		uint64_t _align = (align); \
		_x / _align * _align; \
	})

#define __same_type(a, b) __builtin_types_compatible_p(typeof(a), typeof(b))
#define static_assert(e) switch (0) { case 0: break; case (e): break; };
#define ARRAY_SIZE(a) \
	({ \
		static_assert(!__same_type((a), &(a)[0])); \
		sizeof((a)) / sizeof((a)[0]); \
	})

#ifdef __ASSEMBLER__
#define BIT_32(x) (1 << (x))
#define BIT_64(x) (1 << (x))
#define BIT_32_MASK(hi, lo) ((0xffffffff >> (32 - (hi))) ^ (BIT_32(lo) - 1))
#define BIT_64_MASK(hi, lo) ((0xffffffffffffffff >> (64 - (hi))) ^ (BIT_64(lo) - 1))
#else
#define BIT_32(x) (1U << (x))
#define BIT_64(x) (1ULL << (x))
#define BIT_32_MASK(hi, lo) ((~0U >> (32 - (hi))) ^ (BIT_32(lo) - 1))
#define BIT_64_MASK(hi, lo) ((~0ULL >> (64 - (hi))) ^ (BIT_64(lo) - 1))
#endif

#endif
