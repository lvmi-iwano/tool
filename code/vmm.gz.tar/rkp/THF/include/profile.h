#ifndef LIBHYPERVISOR_PROFILE_H_
#define LIBHYPERVISOR_PROFILE_H_

#include <arch/aarch64.h>
#include <arch/atomic.h>

struct profile_counter {
	atomic_t total_time;
	atomic_t total_cnt;
};

#ifdef PROFILE
#define PROFILE_POINT(name) \
	static struct profile_counter __profile__##name = { \
		.total_time = 0, \
		.total_cnt = 0, \
	};

#define PROFILE_START() \
	{ \
		uint64_t __profile__begin = read_cntpct_el0(); \
		isb();

#define PROFILE_STOP(name) \
		isb(); \
		uint64_t __profile__end = read_cntpct_el0(); \
		atomic_inc_x(&__profile__##name.total_time, \
		             (__profile__end - __profile__begin) * 1000000 / read_cntfrq_el0()); \
		atomic_inc(&__profile__##name.total_cnt); \
	}

#define PROFILE_DUMP(name) \
	DMSG("%s ran %llu times, cost %lluus\n", #name, __profile__##name.total_cnt, __profile__##name.total_time);
#else
#define PROFILE_POINT(name)
#define PROFILE_START() \
	{

#define PROFILE_STOP(name) \
	}

#define PROFILE_DUMP(name)
#endif

#endif
