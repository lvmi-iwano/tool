#ifndef LIBHYPERVISOR_ASSERT_H_
#define LIBHYPERVISOR_ASSERT_H_

#include <printf.h>

#define assert(x) \
	do { \
		if (!(x)) \
			panic("Assertion failed: %s\n", #x); \
	} while(0)

#endif
