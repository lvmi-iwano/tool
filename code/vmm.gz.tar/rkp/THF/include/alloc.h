#ifndef LIBHYPERVISOR_ALLOC_H_
#define LIBHYPERVISOR_ALLOC_H_

#include <stdint.h>

void *malloc(size_t size);
void free(void *ptr);

#endif
