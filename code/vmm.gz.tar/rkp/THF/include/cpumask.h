#ifndef LIBHYPERVISOR_H_
#define LIBHYPERVISOR_H_

#include <bitfield.h>
#include <plat/platform_config.h>
struct cpumask {
	BITFIELD(v, NUM_CORES);
};

static inline int cpumask_get(const struct cpumask *mask, uint8_t cpu)
{
	if (cpu >= NUM_CORES)
		return 0;
	else
		return get_bit(&mask->v, cpu);
}

static void cpumask_set(struct cpumask *mask, uint8_t cpu)
{
	if (cpu >= NUM_CORES)
		return;
	set_bit(&mask->v, cpu);
}

#endif
