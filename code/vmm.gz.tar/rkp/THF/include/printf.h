#ifndef LIBHYPERVISOR_PRINTK_H_
#define LIBHYPERVISOR_PRINTK_H_

#include <stdint.h>
#include <compiler.h>
#include <stdarg.h>
#include <hypervisor.h>

void putchar(char ch);
void puts(const char *s);
void puthex(uint64_t v);

#define register_putchar(func) \
	void putchar(char ch) { func(ch); }

int printf(const char *fmt, ...) __printf(printf, 1, 2);
int snprintf(char *s, size_t size, const char *fmt, ...) __printf(printf, 3, 4);
int vsnprintf(char *s, size_t size, const char *fmt, va_list ap) __printf(printf, 3, 0);

#define DMSG(fmt, ...) \
	printf("[%u][DBG] %s:%d: " fmt, get_core_pos(), __FILE__, __LINE__, ##__VA_ARGS__);
#define IMSG(fmt, ...) \
	printf("[%u][INF] %s:%d: " fmt, get_core_pos(), __FILE__, __LINE__, ##__VA_ARGS__);
#define EMSG(fmt, ...) \
	printf("[%u][ERR] %s:%d: " fmt, get_core_pos(), __FILE__, __LINE__, ##__VA_ARGS__);
#define panic(fmt, ...) \
	do { \
		EMSG("PANIC: " fmt, ##__VA_ARGS__); \
		for (;;); \
	} while (0)

#endif
