#ifndef LIBHYPERVISOR_BITFIELD_H_
#define LIBHYPERVISOR_BITFIELD_H_

#ifndef __ASSEMBER__

#include <compiler.h>
#include <stdint.h>

#define BITFIELD(name, size) uint8_t name[((size) + 7) / 8]
static inline void set_bit(uint8_t (*bf)[], uint32_t bit)
{
	(*bf)[bit / 8] |= (1 << (bit % 8));
}
static inline void clear_bit(uint8_t (*bf)[], uint32_t bit)
{
	(*bf)[bit / 8] &= ~(1U << (bit % 8));
}
static inline uint8_t get_bit(const uint8_t (*bf)[], uint32_t bit)
{
	return !!((*bf)[bit / 8] & (1 << (bit % 8)));
}
#endif

#endif
