#ifndef LIBHYPERVISOR_SMP_H_
#define LIBHYPERVISOR_SMP_H_

#include <stdint.h>

typedef void (smp_func_t)(void *);
int smp_call_others(smp_func_t *func, void *arg, uint8_t wait);

void cpu_going_up(uint8_t cpu);
void cpu_ready();
void cpu_down();

#endif
