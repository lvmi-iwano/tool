#ifndef LIBHYPERVISOR_PAGER_H_
#define LIBHYPERVISOR_PAGER_H_

#include <stdint.h>

void pager_init(void);
void *alloc_pages(size_t num);
void *alloc_pages_aligned(size_t num, uint32_t align);
void free_pages(void *p, size_t num);
void _pager_validate(const char *func, uint32_t line);
#define pager_validate() _pager_validate(__func__, __LINE__)
void pager_dump(void);

#endif
