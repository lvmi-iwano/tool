#ifndef LIBHYPERVISOR_INTERRUPT_H_
#define LIBHYPERVISOR_INTERRUPT_H_

#include <stdint.h>

typedef int (interrupt_handler_t)(uint32_t irq, void *data);
int request_irq(uint32_t irq, interrupt_handler_t *handler, void *data);

#endif
