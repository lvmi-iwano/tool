#include <init.h>
#include <printf.h>
#include <assert.h>
#include <string.h>
#include <compiler.h>
#include <bget.h>
#include <plat/platform_config.h>
#include <arch/aarch64.h>
#include <hypervisor.h>
#include <arch/mmu.h>
#include <arch/vmm.h>
#include <pager.h>
#include <smp.h>
#include <arch/barrier.h>
#include <arch/cache.h>

static uint8_t heap_initialized __data = 0;
static uint8_t driver_initialized = 0;
static uint8_t feature_initialized = 0;
volatile uint8_t warm_boot[NUM_CORES];
struct gpreg_context *boot_context[NUM_CORES];

void hyp_init(int boot_type, struct gpreg_context *_boot_context)
{
	int res;
    struct vcpu *vcpu;
    extern int vcpu_handle_trap_hvc(struct vcpu *vcpu, void *arg __unused);

	if (phys_to_virt((paddr_t) bootstrap_pagetable_allocp) > ((vaddr_t) bootstrap_pagetable) + sizeof(bootstrap_pagetable))
		panic("bootstrap page table out of space\n");

	if (!heap_initialized) {
		extern uint8_t __bss_start[], __bss_end[];
		memset(__bss_start, 0, __bss_end - __bss_start);
		pager_init();
		heap_initialized = 1;
	}

	warm_boot[get_core_pos()] = boot_type;
	boot_context[get_core_pos()] = _boot_context;
call_init(arch); call_init(platform); if (!driver_initialized) { driver_initialized = 1;
		call_init(driver);
	}
	if (!feature_initialized) {
		feature_initialized = 1;
		call_init(feature);
	}

	assert(dom0 != NULL);
	cpu_ready();
	vm_set_current_vcpu(NULL);
	vm_set_next_vcpu(vm_get_vcpu(dom0, get_core_pos()));

    /*register the handler for hvc*/
    vcpu = vm_get_next_vcpu();
	vm_add_trap_handler(vcpu->vm, TRAP_HVC, vcpu_handle_trap_hvc, NULL);
    vm_enable_trap(vcpu->vm, TRAP_HVC);

	vm_run(vm_get_next_vcpu());
}
