#include <smp.h>
#include <list.h>
#include <stdint.h>
#include <arch/spinlock.h>
#include <plat/platform_config.h>
#include <hypervisor.h>
#include <alloc.h>
#include <printf.h>
#include <error.h>
#include <arch/barrier.h>
#ifdef HAS_GIC
#include <drivers/gic.h>
#endif
#include <init.h>

static spinlock_t cpus_lock = SPINLOCK_INITIALIZER;

struct smp_task {
	struct list_head list;
	struct list_head sender_list;
	smp_func_t *func;
	void *arg;
	volatile uint8_t wait, done;
};

struct {
	spinlock_t lock;
	struct list_head list;
} smp_queue[NUM_CORES];

volatile uint8_t cpu_state[NUM_CORES];
#define CPU_DOWN        0
#define CPU_GOING_UP    1
#define CPU_UP          2
#define CPU_GOING_DOWN  3

#define IRQ_SMP_CALL 15

void cpu_going_up(uint8_t cpu)
{
	spin_lock(&cpus_lock);
	cpu_state[cpu] = CPU_GOING_UP;
	spin_unlock(&cpus_lock);
}

void cpu_ready()
{
	uint8_t cpu = get_core_pos();
	spin_lock(&cpus_lock);
	cpu_state[cpu] = CPU_UP;
	spin_unlock(&cpus_lock);
}

void cpu_down()
{
	uint8_t cpu = get_core_pos();
	while (!spin_trylock(&cpus_lock)) {
		spin_lock(&smp_queue[cpu].lock);
		while (!list_empty(&smp_queue[cpu].list)) {
			struct smp_task *task = list_first_entry(&smp_queue[cpu].list, struct smp_task, list);
			task->func(task->arg);
			list_del(&task->list);
			if (task->wait) {
				task->done = 1;
				dmb();
			} else
				free(task);
		}
		spin_unlock(&smp_queue[cpu].lock);
	}
	cpu_state[cpu] = CPU_DOWN;
	spin_unlock(&cpus_lock);
}

int is_cpu_on(uint8_t cpu)
{
	return cpu_state[cpu] == CPU_UP;
}

int smp_call_others(smp_func_t *func, void *arg, uint8_t wait)
{
#ifdef HAS_GIC
	int ret;
	uint8_t this_cpu = get_core_pos();
	struct list_head sender_list;
	spin_lock(&cpus_lock);
	for (uint8_t i = 0; i < NUM_CORES; i++) {
		if (i != this_cpu && is_cpu_on(i)) {
			struct smp_task *task = malloc(sizeof(struct smp_task));
			if (task == NULL) {
				EMSG("Out of memory\n");
				spin_unlock(&cpus_lock);
				return -ENOMEM;
			}
			task->func = func;
			task->arg = arg;
			task->wait = wait;
			task->done = 0;
			list_init(&task->list);
			spin_lock(&smp_queue[i].lock);
			list_add_tail(&task->list, &smp_queue[i].list);
			spin_unlock(&smp_queue[i].lock);
			dmb();
			if ((ret = gic_send_sgi(i, IRQ_SMP_CALL)) != 0) {
				EMSG("Send IPI to CPU%u failed: %d\n", i, ret);
				free(task);
				break;
			}
			if (wait) {
				list_init(&task->sender_list);
				list_add_tail(&task->sender_list, &sender_list);
			}
		}
	}
	if (wait) {
		while (!list_empty(&sender_list)) {
			struct smp_task *task = list_first_entry(&sender_list, struct smp_task, list);
			while (!task->done)
				;
			list_del(&task->sender_list);
			free(task);
		}
	}
	spin_unlock(&cpus_lock);

	return 0;
#else
	return -ENOSYS;
#endif
}

static int init_smp_queue(void)
{
	for (uint8_t i = 0; i < NUM_CORES; i++) {
		smp_queue[i].lock = (spinlock_t) SPINLOCK_INITIALIZER;
		list_init(&smp_queue[i].list);
	}
	return 0;
}
register_init(feature, init_smp_queue);
