#include <ppool.h>
#include <printf.h>
#include <assert.h>

#define PAGER_FIRST_FIT 0
#define PAGER_LAST_FIT 1

//#define DEBUG_ALLOC
//#define DEBUG_FREE

#ifdef DEBUG_ALLOC
#define DALLOC(...) DMSG(__VA_ARGS__)
#else
#define DALLOC(...)
#endif
#ifdef DEBUG_FREE
#define DFREE(...) DMSG(__VA_ARGS__)
#else
#define DFREE(...)
#endif

extern uint8_t alloc_open;
void ppool_init(struct ppool *pool)
{
	pool->fph = NULL;
	pool->lock = SPINLOCK_INITIALIZER;
}

void ppool_add(struct ppool *pool, vaddr_t start, vaddr_t end)
{
	ppool_free(pool, (void *) ROUNDUP(start, PAGE_SIZE), (ROUNDDOWN(end, PAGE_SIZE) - ROUNDUP(start, PAGE_SIZE)) / PAGE_SIZE);
}

static void __alloc_pages(struct ppool *pool, struct page_header *hole_start,
                          struct page_header *hole_end, struct page_header *ph, size_t num)
{
	struct page_header *f = ph;
	struct page_header *l = (struct page_header *) ((vaddr_t) ph + num * PAGE_SIZE - PAGE_SIZE);
	DALLOC("Do alloc before: hole_start = %p\n", hole_start);
	DALLOC("                 f          = %p\n", f);
	DALLOC("                 l          = %p\n", l);
	DALLOC("                 hole_end   = %p\n", hole_end);
	DALLOC("                 hole->prev = %p\n", hole_start->prev);
	DALLOC("                 hole->next = %p\n", hole_end->next);
	if (f != hole_start) {
		if (l != hole_end) {
			//   Free   To alloc   Free
			// |      |          |      |
			hole_start->hole_end = f - 1;
			(f - 1)->hole_start = hole_start;
			hole_end->hole_start = l + 1;
			(l + 1)->hole_end = hole_end;
			(f - 1)->next = l + 1;
			(l + 1)->prev = f - 1;
		} else {
			//   Free   To alloc
			// |      |          |
			hole_start->hole_end = f - 1;
			(f - 1)->hole_start = hole_start;
			(f - 1)->next = l->next;
			(f - 1)->next->prev = f - 1;
		}
	} else {
		if (l != hole_end) {
			//   To alloc   Free
			// |          |      |
			hole_end->hole_start = l + 1;
			(l + 1)->hole_end = hole_end;
			(l + 1)->prev = f->prev;
			(l + 1)->prev->next = l + 1;
		} else {
			//   To alloc
			// |          |
			f->prev->next = l->next;
			l->next->prev = f->prev;
		}
	}
	if (f == hole_start && l == hole_end && f->prev == l)
		pool->fph = NULL;
	else if (f == pool->fph) {
		if (l != hole_end)
			pool->fph = l + 1;
		else
			pool->fph = l->next;
	}
	DALLOC("Do alloc after:  hole1->prev       = %p\n", hole_start->prev);
	DALLOC("                 hole1             = %p\n", hole_start);
	DALLOC("                 hole1->hole_end   = %p\n", hole_start->hole_end);
	DALLOC("                 hole1->next       = %p\n", hole_start->hole_end->next);
	DALLOC("                 hole2->prev       = %p\n", hole_end->hole_start->prev);
	DALLOC("                 hole2             = %p\n", hole_end->hole_start);
	DALLOC("                 hole2->hole_end   = %p\n", hole_end);
	DALLOC("                 hole2->next       = %p\n", hole_end->next);
}

static vaddr_t do_align(vaddr_t addr, uint8_t direction, uint32_t align)
{
	if (align <= PAGE_SHIFT)
		return addr;
	paddr_t paddr = virt_to_phys(addr);
	if (direction == PAGER_FIRST_FIT)
		paddr = ROUNDUP(paddr, 1ULL << align);
	else {
        //DMSG("paddr 0x%lx paddr_down 0x%lx va 0x%lx\n", paddr, ROUNDDOWN(paddr, 1ULL << align), phys_to_virt(ROUNDDOWN(paddr, 1ULL << align)));
		paddr = ROUNDDOWN(paddr, 1ULL << align);
    }
	return phys_to_virt(paddr);
}

static void *_alloc_pages(struct ppool *pool, size_t num, uint8_t direction, uint32_t align)
{
	struct page_header *ph = pool->fph;
	if (ph == NULL)
		return NULL;
	DALLOC("Try alloc: %zu pages, dir %u, align %u\n", num, direction, align);
	spin_lock(&pool->lock);
	if (direction == PAGER_FIRST_FIT) {
		do {
			struct page_header *hole_end = ph->hole_end;
			DALLOC("    Hole: %p-%p\n", ph, hole_end + 1);
			vaddr_t aligned = do_align((vaddr_t) ph, direction, align);

			if (aligned + (num - 1) * PAGE_SIZE <= (vaddr_t) hole_end) {
				__alloc_pages(pool, ph, hole_end, (struct page_header *) aligned, num);
				spin_unlock(&pool->lock);
				return (void *) aligned;
			}
			ph = hole_end->next;
		} while (ph != pool->fph);
	} else {
		ph = ph->prev;
		do {
			struct page_header *hole_start = ph->hole_start;
			DALLOC("    Hole: %p-%p\n", hole_start, ph + 1);
			vaddr_t aligned = do_align((vaddr_t) ph - (num - 1) * PAGE_SIZE, direction, align);
            //DMSG("aligned va 0x%lx align %u hole_start 0x%lx\n", aligned, align, (vaddr_t) hole_start);
			if (aligned >= (vaddr_t) hole_start) {//executed
				__alloc_pages(pool, hole_start, ph, (struct page_header *) aligned, num);
				spin_unlock(&pool->lock);
				return (void *) aligned;
			}
			ph = hole_start->prev;
		} while (ph != pool->fph);
	}

	spin_unlock(&pool->lock);
	return NULL;
}

void *ppool_alloc(struct ppool *pool, size_t num)
{
	return _alloc_pages(pool, num, PAGER_FIRST_FIT, 0);
}

void *ppool_alloc_aligned(struct ppool *pool, size_t num, uint32_t align)
{
	return _alloc_pages(pool, num, PAGER_FIRST_FIT, align);
}

void *ppool_alloc_last(struct ppool *pool, size_t num)
{
	return _alloc_pages(pool, num, PAGER_LAST_FIT, 0);
}

void *ppool_alloc_last_aligned(struct ppool *pool, size_t num, uint32_t align)
{
	return _alloc_pages(pool, num, PAGER_LAST_FIT, align);
}

void ppool_free(struct ppool *pool, void *p, size_t num)
{
	assert((((vaddr_t) p) & (PAGE_SIZE - 1)) == 0);
	struct page_header *f = (struct page_header *) p;
	struct page_header *l = (struct page_header *) ((vaddr_t) p + (num - 1) * PAGE_SIZE);
	struct page_header *hole;

	spin_lock(&pool->lock);
	if (pool->fph == NULL) {
		hole = f;
		pool->fph = f;
		f->hole_end = l;
		f->prev = l;
		l->hole_start = f;
		l->next = f;
	} else if (l < pool->fph) {
		hole = f;
		f->prev = pool->fph->prev;
		f->prev->next = f;
		if ((uint64_t) pool->fph - (uint64_t) l == PAGE_SIZE) {
			//   To free   Free
			// |         |      |
			//           fph
			f->hole_end = pool->fph->hole_end;
			f->hole_end->hole_start = f;
		} else {
			//   To free   Allocated   Free
			// |         |           |
			//                       fph
			f->hole_end = l;
			l->hole_start = f;
			l->next = pool->fph;
			l->next->prev = l;
		}
		pool->fph = f;
	} else if (pool->fph->prev < f) {
		if ((uint64_t) f - (uint64_t) pool->fph->prev == PAGE_SIZE) {
			//   Free   To free
			// |      |         |
			hole = pool->fph->prev->hole_start;
			l->hole_start = pool->fph->prev->hole_start;
			l->hole_start->hole_end = l;
		} else {
			//   Free   Allocated   To free
			// |      |           |         |
			hole = f;
			f->hole_end = l;
			l->hole_start = f;
			f->prev = pool->fph->prev;
			f->prev->next = l;
		}
		l->next = pool->fph;
		l->next->prev = l;
	} else {
		struct page_header *ph = pool->fph;
		while (ph < f)
			ph = ph->hole_end->next;
		if ((uint64_t) f - (uint64_t) ph->prev == PAGE_SIZE) {
			hole = ph->prev->hole_start;
			if ((uint64_t) ph - (uint64_t) l == PAGE_SIZE) {
				//   Free   To free   Free
				// |      |         |      |
				//                  ph
				ph->prev->hole_start->hole_end = ph->hole_end;
				ph->hole_end->hole_start = ph->prev->hole_start;
			} else {
				//   Free   To free   Allocated   Free
				// |      |         |           |      |
				//                              ph
				ph->prev->hole_start->hole_end = l;
				l->hole_start = ph->prev->hole_start;
				l->next = ph;
				l->next->prev = l;
			}
		} else {
			hole = f;
			if ((uint64_t) ph - (uint64_t) l == PAGE_SIZE) {
				//   Allocated   To free   Free
				// |           |         |      |
				//                       ph
				ph->hole_end->hole_start = f;
				f->hole_end = ph->hole_end;
				f->prev = ph->prev;
				f->prev->next = f;
			} else {
				//   Allocated   To free   Allocated   Free
				// |           |         |           |      |
				//                                   ph
				f->hole_end = l;
				l->hole_start = f;
				f->prev = ph->prev;
				f->prev->next = f;
				l->next = ph;
				l->next->prev = l;
			}
		}
	}
	spin_unlock(&pool->lock);
	DFREE("Do free after: hole->prev     = %p\n", hole->prev);
	DFREE("               hole           = %p\n", hole);
	DFREE("               hole->hole_end = %p\n", hole->hole_end);
	DFREE("               hole->next     = %p\n", hole->hole_end->next);
}

int ppool_validate(struct ppool *pool)
{
	spin_lock(&pool->lock);
	if (pool->fph == NULL) {
		spin_unlock(&pool->lock);
		return 0;
	}
	struct page_header *p, *n;
	for (p = pool->fph, n = p->hole_end; ; p = n->next, n = p->hole_end) {
		if (n->hole_start != p)
			return -1;
		if ((uint64_t) p - (uint64_t) p->prev == PAGE_SIZE)
			return -1;
		if ((uint64_t) n->next - (uint64_t) n == PAGE_SIZE)
			return -1;
		if (n->next->prev != n)
			return -1;
		if (p->prev->next != p)
			return -1;
		if (n == pool->fph->prev)
			break;
	}
	spin_unlock(&pool->lock);
	return 0;
}

void ppool_dump(struct ppool *pool)
{
	DMSG("Free pages:\n");
	spin_lock(&pool->lock);
	struct page_header *p = pool->fph;
	if (p == NULL) {
		spin_unlock(&pool->lock);
		return;
	}
	do {
		DMSG("\t%p-%p\n", p, p->hole_end + 1);
		p = p->hole_end->next;
	} while (p != pool->fph);
	spin_unlock(&pool->lock);
}
