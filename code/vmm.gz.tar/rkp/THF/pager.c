#include <pager.h>
#include <ppool.h>
#include <bget.h>
#include <hypervisor.h>
#include <arch.h>
#include <printf.h>

struct ppool main_pool;

//#define ALLOC_TRACE

#ifdef ALLOC_TRACE
size_t num_free;
#endif

static void *_alloc_pages(size_t num, uint8_t direction, uint32_t align);
static void *bectl_acquire(bufsize size)
{
	size = ROUNDUP(size, PAGE_SIZE);
#ifdef ALLOC_TRACE
	void *ret = ppool_alloc(&main_pool, size / PAGE_SIZE);
	if (ret != NULL)
		num_free -= size / PAGE_SIZE;
	DMSG("PATRACE: alloc malloc pool (%llu) return %p remain %zu\n", size / PAGE_SIZE, ret, num_free);
	return ret;
#else
	return ppool_alloc(&main_pool, size / PAGE_SIZE);
#endif
}

static void bectl_release(void *p, size_t size)
{
	size = ROUNDUP(size, PAGE_SIZE);
#ifdef ALLOC_TRACE
	num_free += size / PAGE_SIZE;
	DMSG("PATRACE: free malloc pool (%llu) remain %zu\n", size / PAGE_SIZE, num_free);
#endif
	free_pages(p, size / PAGE_SIZE);
}

void pager_init(void)
{
	extern uint8_t __start[], __end[];

	ppool_init(&main_pool);
	ppool_add(&main_pool,
	          ROUNDUP((uint64_t) __end, PAGE_SIZE),
	          ROUNDDOWN(HYPERVISOR_RAM_VA + HYPERVISOR_RAM_SIZE, PAGE_SIZE));
#ifdef ALLOC_TRACE
	num_free = (ROUNDDOWN(HYPERVISOR_RAM_VA + HYPERVISOR_RAM_SIZE, PAGE_SIZE) - ROUNDUP((uint64_t) __end, PAGE_SIZE)) / PAGE_SIZE;
#endif
	bectl(NULL, bectl_acquire, bectl_release, 10 * PAGE_SIZE);
}

void *alloc_pages(size_t num)
{
#ifdef ALLOC_TRACE
	uint64_t lr;
	asm volatile("mov %0, x30\n":"=r"(lr));
	void *ret = ppool_alloc_last(&main_pool, num);
	if (ret != NULL)
		num_free -= num;
	DMSG("PATRACE: alloc_pages(%zu) @0x%lx return %p remain %zu\n", num, lr, ret, num_free);
	return ret;
#else
	return ppool_alloc_last(&main_pool, num);
#endif
}
/*@num: amount of page allocted
 *tww: va and pa of these allocated pages are both continues
 */
void *alloc_pages_aligned(size_t num, uint32_t align)
{
#ifdef ALLOC_TRACE
	uint64_t lr;
	asm volatile("mov %0, x30\n":"=r"(lr));
	void *ret = ppool_alloc_last_aligned(&main_pool, num, align);
	if (ret != NULL)
		num_free -= num;
	DMSG("PATRACE: alloc_pages_aligned(%zu, %u) @0x%lx return %p remain %zu\n", num, align, lr, ret, num_free);
	return ret;
#else
	return ppool_alloc_last_aligned(&main_pool, num, align);
#endif
}

void free_pages(void *p, size_t num)
{
#ifdef ALLOC_TRACE
	uint64_t lr;
	asm volatile("mov %0, x30\n":"=r"(lr));
	num_free += num;
	DMSG("PATRACE: free(%p, %zu) @0x%lx remain %zu\n", p, num, lr, num_free);
#endif
	ppool_free(&main_pool, p, num);
}

void _pager_validate(const char *func, uint32_t line)
{
	if (ppool_validate(&main_pool) != 0)
		panic("Pager validation failed at %s:%u\n", func, line);
}

void pager_dump(void)
{
	ppool_dump(&main_pool);
}
