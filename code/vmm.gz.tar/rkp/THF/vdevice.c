#include <vdevice.h>
#include <plugin.h>
#include <alloc.h>
#include <list.h>
#include <printf.h>
#include <error.h>
#include <arch.h>

struct vdevice_inst {
	const struct vdevice *desc;
	struct list_head list;
	void *data;
};

int vdevice_handle_access(struct vcpu *vcpu)
{
	struct list_head *head = get_plugin_data(vcpu_get_vm(vcpu), vdevice_plugin);
	struct vdevice_inst *dev;
	paddr_t ipa;
	int ret;
	uint32_t instr = vcpu_get_instr(vcpu);

	uint8_t is_read, access_size;
	uint32_t fault_type = vcpu_get_fault_type(vcpu);

	switch (fault_type) {
	case FAULT_READ8:
		is_read = 1;
		access_size = 1;
		break;
	case FAULT_WRITE8:
		is_read = 0;
		access_size = 1;
		break;
	case FAULT_READ16://
		is_read = 1;
		access_size = 2;
		break;
	case FAULT_WRITE16://
		is_read = 0;
		access_size = 2;
		break;
	case FAULT_READ32:
		is_read = 1;
		access_size = 4;
		break;
	case FAULT_WRITE32:
		is_read = 0;
		access_size = 4;
		break;
	default:
		return 1;/*FAULT_READ64 and FAULT_WRITE64*/
	}
    //DMSG("vdevice_handle_access is_read: %d access_size: %d\n", is_read, access_size);

	if ((ret = vcpu_gva_to_gpa(vcpu, vcpu_get_fault_addr(vcpu), &ipa)) != 0) {//ipa == fault addr(gpa)
		return ret;
    }
	list_for_each_entry(dev, head, list) {
		struct vdevice_mmio_range *r = dev->desc->mmio;
		if (r == NULL)
			continue;
		for (;;) {
			if (r->size == 0)
				break;
			if (ipa >= r->addr && ipa + access_size <= r->addr + r->size) {
				if ((ipa & (access_size - 1)) != 0) {
					EMSG("Access not aligned, access size %u, IPA 0x%lx\n", access_size, ipa);
					return -EINVAL;
				}
				uint32_t reg_id = vcpu_get_fault_reg(vcpu);//rt? 
				uint64_t v;
				if (is_read) {
					if (r->read == NULL) {
						EMSG("vDevice MMIO hit but no read handler\n");
						return -ENOSYS;
					}
					ret = r->read(vcpu, ipa, access_size, &v, dev->data);
					if (ret == 0)
						vcpu_set_reg(vcpu, reg_id, v);
				} else {
					if (r->write == NULL) {
						EMSG("vDevice MMIO hit but no write handler\n");
						return -ENOSYS;
					}
					vcpu_get_reg(vcpu, reg_id, &v);
					ret = r->write(vcpu, ipa, access_size, v, dev->data);//write v to memory(ipa)
				}
#if defined(__aarch64__)
				if (ret == 0 && aarch64_instr_wback(instr))//write the fault addr to the register
					vcpu_set_reg(vcpu, REG_GP0 + aarch64_instr_get_Rn(instr), vcpu_get_fault_addr(vcpu));
#endif
				return ret;
		  }
		  r++;
	  }
	}
    //DMSG("vdevice_handle_access is_read: %d access_size: %d will be handled by handler\n", is_read, access_size);
	return 1;
}

int vdevice_add(struct vm *vm, const struct vdevice *desc)
{
	int ret;
	void *data = NULL;
	if (desc == NULL || desc->mmio == NULL)
		return -EINVAL;

	if (desc->init) {
		if ((ret = desc->init(vm, &data)) != 0)
			return ret;
	}
	for (struct vdevice_mmio_range *r = desc->mmio; r->size != 0; r++) {
		struct vm_area vma;
		vma.pa = 0;
		vma.va = r->addr;
		vma.size = r->size;
		vma.valid = 1;
		vma.forbidden = 1;
		DMSG("vDevice occupy 0x%lx-0x%lx\n", r->addr, r->addr + r->size);
		if ((ret = mmu_apply_vma(vm_get_s2pt(vm), &vma)) != 0) {
			if (desc->deinit)
				desc->deinit(vm, data);
			return ret;
		}
	}

	struct vdevice_inst *inst = malloc(sizeof(struct vdevice_inst));
	if (inst == NULL) {
		EMSG("Out of memory\n");
		if (desc->deinit)
			desc->deinit(vm, data);
		return -ENOMEM;
	}
	inst->desc = desc;
	inst->data = data;
	list_init(&inst->list);
	list_add(get_plugin_data(vm, vdevice_plugin), &inst->list);
	return 0;
}

static int vdevice_init(struct vm *vm, void **pdata)
{
	*pdata = malloc(sizeof(struct list_head));
	if (*pdata == NULL) {
		EMSG("Out of memory\n");
		return -ENOMEM;
	}
	list_init((struct list_head *) *pdata);

	return 0;
}

static void vdevice_deinit(struct vm *vm, void *data)
{
	struct list_head *head = (struct list_head *) data;
	struct vdevice_inst *dev, *tmp;
	list_for_each_entry_safe(dev, tmp, head, list) {
		if (dev->desc->deinit)
			dev->desc->deinit(vm, dev->data);
		free(dev);
	}
	free(head);
}

struct plugin vdevice_plugin = {
	.init = vdevice_init,
	.deinit = vdevice_deinit
};
register_plugin_order(00, vdevice_plugin);
