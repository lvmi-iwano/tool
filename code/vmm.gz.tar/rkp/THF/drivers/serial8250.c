#include <init.h>
#include <printf.h>
#include <arch/io.h>
#include <plat/platform_config.h>

void *base = (void *) UART_BASE;

#define UART_THR           0x0
#define UART_LSR           0x14
#	define UART_LSR_TEMT   0x40
#	define UART_LSR_THRE   0x20
#	define UART_LSR_EMPTY  (UART_LSR_TEMT | UART_LSR_THRE)

void serial8250_putchar(char ch)
{
	if (!base)
		return;
	if (ch == '\n')
		serial8250_putchar('\r');
	while ((read32(base + UART_LSR) & UART_LSR_EMPTY) != UART_LSR_EMPTY)
		;
	write8(base + UART_THR, ch);
}

int serial8250_init(void)
{
	base = (void *) UART_BASE;
	return 0;
}

register_driver_init(serial8250_init);
register_putchar(serial8250_putchar);
