#include <init.h>
#include <printf.h>
#include <arch/io.h>
#include <plat/platform_config.h>

void *base = (void *) UART_BASE;

#define PL011_DR 0x00
#define PL011_FR 0x18
#	define PL011_FR_TXFF (1U << 5)

void pl011_putchar(char ch)
{
	if (!base)
		return;
	if (ch == '\n')
		pl011_putchar('\r');
	while (read32(base + PL011_FR) & PL011_FR_TXFF)
		;
	write32(base + PL011_DR, ch);
}

int pl011_init(void)
{
	base = (void *) UART_BASE;
	return 0;
}

register_driver_init(pl011_init);
register_putchar(pl011_putchar);
