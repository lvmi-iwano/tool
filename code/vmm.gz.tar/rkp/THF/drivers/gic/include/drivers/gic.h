#ifndef LIBHYPERVISOR_DRIVER_GIC_H_
#define LIBHYPERVISOR_DRIVER_GIC_H_

#include <compiler.h>
#include <hypervisor.h>
#include <cpumask.h>

uint32_t gic_read_iar();
#	define GIC_IAR_InterruptID_SHIFT  0
#	define GIC_IAR_InterruptID_WIDTH  10
#	define GIC_IAR_InterruptID(reg)   (((reg) >> GIC_IAR_InterruptID_SHIFT) & (BIT_32(GIC_IAR_InterruptID_WIDTH) - 1))
#	define GIC_IAR_CPUID_SHIFT        10
#	define GIC_IAR_CPUID_WIDTH        3
#	define GIC_IAR_CPUID_MASK         BIT_32_MASK(GIC_IAR_CPUID_SHIFT + GIC_IAR_CPUID_WIDTH, GIC_IAR_CPUID_SHIFT)
#	define GIC_IAR_CPUID(reg)         (((reg) >> GIC_IAR_CPUID_SHIFT) & (BIT_32(GIC_IAR_CPUID_WIDTH) - 1))
int gic_has_irq(struct vcpu *vcpu);
int gic_send_sgi(uint8_t cpu, uint8_t sgi);
int gic_send_many(const struct cpumask *cpus, uint8_t sgi);

#endif
