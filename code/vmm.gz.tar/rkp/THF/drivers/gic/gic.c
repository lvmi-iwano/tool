#include <init.h>
#include <mmu.h>
#include <plat/platform_config.h>
#include <arch/io.h>
#include <plugin.h>
#include <hypervisor.h>
#include <drivers/gic.h>
#include <bitfield.h>
#include <interrupt.h>
#include <error.h>
#include <vdevice.h>
#include <alloc.h>
#include <blist.h>

void *gic_base = NULL;

#define IRQ_VMAINTAIN  25

#define GICD_BASE                       0x1000
#	define GICD_CTLR                    0x0
#	define GICD_ISENABLERn(x)           (0x100 + (x) * 4)
#	define GICD_ICENABLERn(x)           (0x180 + (x) * 4)
#	define GICD_ISPENDRn(x)             (0x200 + (x) * 4)
#	define GICD_ICPENDRn(x)             (0x280 + (x) * 4)
#	define GICD_ICACTIVERn(x)           (0x380 + (x) * 4)
#	define GICD_IPRIORITY(id)           (0x400 + (id))
#	define GICD_SGIR                    0xF00
#		define GICD_SGIR_TARGET_LIST    (0 << 24)
#		define GICD_SGIR_TARGET(i)      (1U << (16 + (i)))
#	define GICD_SIZE                    0x1000
#define GICC_BASE                       0x2000
#	define GICC_CTRL                    0x0
#		define GICC_CTRL_EOImodeNS      BIT_32(9)
#		define GICC_CTRL_EnableGrp1     BIT_32(0)
#	define GICC_PMR                     0x4
#	define GICC_BPR                     0x8
#	define GICC_IAR                     0xC
#	define GICC_EOIR                    0x10
#	define GICC_HPPIR                   0x18
#	define GICC_DIR                     0x1000
#	define GICC_SIZE                    0x2000
#define GICH_BASE                       0x4000
#	define GICH_HCR                     0x0
#		define GICH_HCR_VGrp1DIE        BIT_32(7)
#		define GICH_HCR_VGrp1EIE        BIT_32(6)
#		define GICH_HCR_VGrp0DIE        BIT_32(5)
#		define GICH_HCR_VGrp0EIE        BIT_32(4)
#		define GICH_HCR_LRENPIE         BIT_32(2)
#		define GICH_HCR_En              BIT_32(0)
#	define GICH_VTR                     0x4
#		define GICH_VTR_ListRegs_SHIFT  0
#		define GICH_VTR_ListRegs_WIDTH  6
#		define GICH_VTR_ListRegs(reg)   (((reg) >> GICH_VTR_ListRegs_SHIFT) & (BIT_32(GICH_VTR_ListRegs_WIDTH) - 1))
#	define GICH_VMCR                    0x8
#		define GICH_VMCR_VMGrp0En       BIT_32(0)
#	define GICH_MISR                    0x10
#		define GICH_MISR_VGrp0D         BIT_32(5)
#		define GICH_MISR_VGrp0E         BIT_32(4)
#		define GICH_MISR_EOI            BIT_32(0)
#	define GICH_LRn(x)                  (0x100 + (x) * 4)
#		define GICH_LR_HW               BIT_32(31)
#		define GICH_LR_Grp1             BIT_32(30)
#		define GICH_LR_State_SHIFT      28
#		define GICH_LR_State_WIDTH      2
#		define GICH_LR_State(reg)       (((reg) >> GICH_LR_State_SHIFT) & (BIT_32(GICH_LR_State_WIDTH) - 1))
#			define GICH_LR_State_INVALID    0x0
#			define GICH_LR_State_PENDING    0x1
#		define GICH_LR_Priority_SHIFT   23
#		define GICH_LR_EOI              BIT_32(19)
#		define GICH_LR_CPUID_SHIFT      10
#		define GICH_LR_CPUID_WIDTH      3
#		define GICH_LR_CPUID_MASK       BIT_32_MASK(GICH_LR_CPUID_SHIFT + GICH_LR_CPUID_WIDTH, GICH_LR_CPUID_SHIFT)
#		define GICH_LR_PhysicalID_SHIFT  10
#		define GICH_LR_PhysicalID_WIDTH  10
#		define GICH_LR_PhysicalID_MASK   BIT_32_MASK(GICH_LR_PhysicalID_SHIFT + GICH_LR_PhysicalID_WIDTH, GICH_LR_PhysicalID_SHIFT)
#		define GICH_LR_VirtualID_SHIFT  0
#		define GICH_LR_VirtualID_WIDTH  10
#		define GICH_LR_VirtualID_MASK   BIT_32_MASK(GICH_LR_VirtualID_SHIFT + GICH_LR_VirtualID_WIDTH, GICH_LR_VirtualID_SHIFT)
#	define GICH_EISRn(x)                (0x20 + (x) * 4)
#define GICH_BASEx(x)                   (0x5000 + (0x200 * x))
#define GICH_SIZE                       0x2000
#define GICV_BASE                       0x6000

#define DEFAULT_PRIORITY 0x0

uint32_t max_gich_lr;
uint32_t gic_read_iar(void)
{
	if (gic_base == NULL)
		return 1023;
	else
		return read32(gic_base + GICC_BASE + GICC_IAR);
}

void gic_eoi(uint32_t iar)
{
	if (gic_base == NULL)
		return;
	write32(gic_base + GICC_BASE + GICC_EOIR, iar);
	write32(gic_base + GICC_BASE + GICC_DIR, iar);
}

struct virq {
	uint32_t iar;
};

static int no_dup_irq(uint32_t iar, uint32_t irq)
{
	for (uint32_t i = 0; i < max_gich_lr; i++) {
		uint32_t old_lr = read32(gic_base + GICH_BASE + GICH_LRn(i));
		if (old_lr != 0 && (old_lr & GICH_LR_VirtualID_MASK) == irq && (old_lr & GICH_LR_CPUID_MASK) == (iar & GIC_IAR_CPUID_MASK)) {
			EMSG("IRQ %u dup: LR 0x%x\n", irq, old_lr);
			return 0;
		}
	}

	struct blist_head *plugin_data = get_plugin_data(vcpu_get_vm(vm_get_current_vcpu()), vgic);
	plugin_data = &plugin_data[get_core_pos()];
	struct virq *virq;
	blist_for_each_entry(virq, plugin_data) {
		if (virq->iar == iar) {
			EMSG("IRQ %u dup: IAR 0x%x\n", irq, iar);
			return 0;
		}
	}
	return 1;
}

struct {
	int (*handler)(uint32_t irq, void *data);
	void *data;
} irq_handler[MAX_INT_NR];
static int _handle_irq(void)
{
	int ret;
	for (;;) {
		uint32_t iar = gic_read_iar();
		uint32_t irq = GIC_IAR_InterruptID(iar);

		if (irq == 1023) {
			ret = 0;
			break;
		}
		if (irq >= MAX_INT_NR) {
			EMSG("error irq %u\n", irq);
			return -EINVAL;
		}

		if (irq_handler[irq].handler != NULL) {
			ret = irq_handler[irq].handler(irq, irq_handler[irq].data);
			if (ret < 0) {
				gic_eoi(iar);
				return ret;
			} else if (ret == 0) {
				gic_eoi(iar);
				continue;
			}
		}

		ret = vcpu_handle_irq(vm_get_current_vcpu());
		if (ret < 0) {
			gic_eoi(iar);
			return ret;
		} else if (ret == 0) {
			gic_eoi(iar);
			continue;
		}

		write32(gic_base + GICC_BASE + GICC_EOIR, iar);
		assert(no_dup_irq(iar, irq));
		uint32_t i;
		if (read32(gic_base + GICH_BASE + GICH_VMCR) & GICH_VMCR_VMGrp0En) {
			for (i = 0; i < max_gich_lr; i++) {
				uint32_t old_lr = read32(gic_base + GICH_BASE + GICH_LRn(i));
				if (old_lr == 0) {
					write32(gic_base + GICH_BASE + GICH_LRn(i),
					        (GICH_LR_State_PENDING << GICH_LR_State_SHIFT) | (0 << GICH_LR_Priority_SHIFT) | GICH_LR_EOI |
					        ((irq < 16 ? GIC_IAR_CPUID(iar) : 0) << GICH_LR_CPUID_SHIFT) |
					        irq);
					break;
				}
			}
		} else
			i = max_gich_lr;
		if (i == max_gich_lr) {
			struct virq virq;
			virq.iar = iar;
			struct blist_head *plugin_data = get_plugin_data(vcpu_get_vm(vm_get_current_vcpu()), vgic);
			if (blist_add_tail(&virq, &plugin_data[get_core_pos()]) != 0) {
				EMSG("Want to buffer IAR 0x%x\n", iar);
				EMSG("Out of memory\n");
				return -ENOMEM;
			}
		}
		ret = 0;
	}
	for (uint32_t i = 0; i < max_gich_lr; i++) {
		uint32_t old_lr = read32(gic_base + GICH_BASE + GICH_LRn(i));
		if (GICH_LR_State(old_lr) == GICH_LR_State_INVALID && old_lr != 0) {
			EMSG("MISR 0x%x\n", read32(gic_base + GICH_BASE + GICH_MISR));
			EMSG("EISR 0x%x, HPPIR 0x%x\n", read32(gic_base + GICH_BASE + GICH_EISRn(0)), read32(gic_base + GICC_BASE + GICC_HPPIR));
			panic("LR[%u]: 0x%0x Missing VMaintain?\n", i, old_lr);
		}
	}
	return ret;
}

void handle_irq(uint64_t eno, struct gpreg_context *regs)
{
	switch (eno) {
	case EXP_EL2H_IRQ:
	case EXP_EL2T_IRQ:
		panic("Shouldn't got IRQ in EL2\n");
	case EXP_EL1_IRQ:
	case EXP_EL1_32_IRQ:
		assert(vm_get_current_vcpu() != NULL);
		vmexit(regs);
		assert(_handle_irq() == 0);
		break;
	default:
		panic("Unknown exception\n");
	}

	vm_run(vm_get_next_vcpu());
}

int request_irq(uint32_t irq, interrupt_handler_t *handler, void *data)
{
	if (irq >= MAX_INT_NR)
		return -EINVAL;
	if (irq_handler[irq].handler != NULL)
		return -EBUSY;
	irq_handler[irq].handler = handler;
	irq_handler[irq].data = data;
	write32(gic_base + GICD_BASE + GICD_ISENABLERn(irq / 32), 1U << (irq % 32));
	write8(gic_base + GICD_BASE + GICD_IPRIORITY(irq), 0);
	return 0;
}

static int handle_vmaintain(uint32_t irq, void *arg __unused)
{
	uint32_t misr = read32(gic_base + GICH_BASE + GICH_MISR);

	if (misr & GICH_MISR_EOI) {
		for (uint32_t i = 0; i < ROUNDUP(max_gich_lr, 32) / 32; i++) {
			uint32_t eisr = read32(gic_base + GICH_BASE + GICH_EISRn(i));
			for (uint32_t j = 0; j < 32; j++) {
				if (eisr & (1U << j)) {
					uint32_t lr = read32(gic_base + GICH_BASE + GICH_LRn(i * 32 + j));
					write32(gic_base + GICC_BASE + GICC_DIR, lr & (GICH_LR_CPUID_MASK | GICH_LR_VirtualID_MASK));
					write32(gic_base + GICH_BASE + GICH_LRn(i * 32 + j), 0);

					struct blist_head *plugin_data = get_plugin_data(vcpu_get_vm(vm_get_current_vcpu()), vgic);
					if (!blist_empty(&plugin_data[get_core_pos()])) {
						struct virq *virq = blist_first_entry(&plugin_data[get_core_pos()], struct virq);
						uint32_t iar = virq->iar;
						uint32_t irq = GIC_IAR_InterruptID(iar);
						blist_del(virq);
						write32(gic_base + GICH_BASE + GICH_LRn(i * 32 + j),
						        (GICH_LR_State_PENDING << GICH_LR_State_SHIFT) | (0 << GICH_LR_Priority_SHIFT) | GICH_LR_EOI |
						        ((irq < 16 ? GIC_IAR_CPUID(iar) : 0) << GICH_LR_CPUID_SHIFT) |
						        irq);
					}
				}
			}
		}
		misr ^= GICH_MISR_EOI;
	}
	if (misr & GICH_MISR_VGrp0D) {
		write32(gic_base + GICH_BASE + GICH_HCR, read32(gic_base + GICH_BASE + GICH_HCR) ^ (GICH_HCR_VGrp0DIE | GICH_HCR_VGrp0EIE));
		for (uint32_t i = 0; i < max_gich_lr; i++)
			assert(read32(gic_base + GICH_BASE + GICH_LRn(i)) == 0);
		misr ^= GICH_MISR_VGrp0D;
	}
	if (misr & GICH_MISR_VGrp0E) {
		write32(gic_base + GICH_BASE + GICH_HCR, read32(gic_base + GICH_BASE + GICH_HCR) ^ (GICH_HCR_VGrp0DIE | GICH_HCR_VGrp0EIE));
		for (uint32_t i = 0; i < max_gich_lr; i++) {
			struct blist_head *virq_list = get_plugin_data(vcpu_get_vm(vm_get_current_vcpu()), vgic);
			virq_list = &virq_list[get_core_pos()];
			if (!blist_empty(virq_list)) {
				struct virq *virq = blist_first_entry(virq_list, struct virq);
				uint32_t iar = virq->iar;
				uint32_t irq = GIC_IAR_InterruptID(iar);
				blist_del(virq);
				write32(gic_base + GICH_BASE + GICH_LRn(i),
				        (GICH_LR_State_PENDING << GICH_LR_State_SHIFT) | (0 << GICH_LR_Priority_SHIFT) | GICH_LR_EOI |
				        ((irq < 16 ? GIC_IAR_CPUID(iar) : 0) << GICH_LR_CPUID_SHIFT) |
				        irq);
			}
		}
		misr ^= GICH_MISR_VGrp0E;
	}
	if (misr)
		EMSG("Unknown GICH_MISR 0x%x\n", misr);

	return 0;
}

int gic_send_sgi(uint8_t cpu, uint8_t sgi)
{
	if (cpu >= NUM_CORES || sgi >= 16)
		return -EINVAL;
	write32(gic_base + GICD_BASE + GICD_SGIR, GICD_SGIR_TARGET_LIST | GICD_SGIR_TARGET(cpu) | sgi);
	return 0;
}

int gic_send_many(const struct cpumask *cpus, uint8_t sgi)
{
	if (sgi >= 16)
		return -EINVAL;
	uint32_t sgir = GICD_SGIR_TARGET_LIST | sgi;
	for (uint8_t i = 0; i < NUM_CORES; i++) {
		if (cpumask_get(cpus, i))
			sgir |= GICD_SGIR_TARGET(i);
	}
	write32(gic_base + GICD_BASE + GICD_SGIR, sgir);
	return 0;
}

static int init_gic_dist(void)
{
	write32(gic_base + GICD_BASE + GICD_CTLR, 0);
	for (uint32_t i = 32; i < MAX_INT_NR; i++) {
		if (irq_handler[i].handler != NULL) {
			write32(gic_base + GICD_BASE + GICD_ISENABLERn(i / 32), 1U << (i % 32));
			write8(gic_base + GICD_BASE + GICD_IPRIORITY(i), DEFAULT_PRIORITY);
		}
	}
	write32(gic_base + GICD_BASE + GICD_CTLR, 1);
	max_gich_lr = GICH_VTR_ListRegs(read32(gic_base + GICH_BASE + GICH_VTR)) + 1;
	return 0;
}

static int init_gic_cpu(void)
{
	write32(gic_base + GICV_BASE + GICC_PMR, read32(gic_base + GICC_BASE + GICC_PMR));
	write32(gic_base + GICV_BASE + GICC_BPR, read32(gic_base + GICC_BASE + GICC_BPR));
	write32(gic_base + GICV_BASE + GICC_CTRL, read32(gic_base + GICC_BASE + GICC_CTRL));

	write32(gic_base + GICC_BASE + GICC_CTRL, 0);
	write32(gic_base + GICC_BASE + GICC_PMR, 0xf0);
	write32(gic_base + GICH_BASE + GICH_HCR, GICH_HCR_En | GICH_HCR_LRENPIE | GICH_HCR_VGrp0DIE);
	write32(gic_base + GICC_BASE + GICC_CTRL, GICC_CTRL_EOImodeNS | GICC_CTRL_EnableGrp1);

	for (uint32_t i = 0; i < 32; i++) {
		if (irq_handler[i].handler != NULL) {
			write32(gic_base + GICD_BASE + GICD_ISENABLERn(i / 32), 1U << (i % 32));
			write8(gic_base + GICD_BASE + GICD_IPRIORITY(i), DEFAULT_PRIORITY);
		}
	}
	return 0;
}

static int init_gic(void)
{
	int ret;
	if (gic_base == NULL) {
		gic_base = ioremap(GIC_BASE, GIC_SIZE);
		if (gic_base == NULL)
			return -1;
		for (uint32_t i = 0; i < MAX_INT_NR; i++)
			irq_handler[i].handler = NULL;
		if ((ret = init_gic_dist()) != 0)
			return ret;
		if ((ret = init_gic_cpu()) != 0)
			return ret;
		if ((ret = request_irq(IRQ_VMAINTAIN, handle_vmaintain, NULL)) != 0)
			return ret;
	} else {
		if ((ret = init_gic_cpu()) != 0)
			return ret;
	}

	return 0;
}
#ifdef ENABLE_VGIC
register_init(arch, init_gic);
#endif

int gic_has_irq(struct vcpu *vcpu)
{
	for (uint32_t i = 0; i < max_gich_lr; i++) {
		if (read32(gic_base + GICH_BASE + GICH_LRn(i)) != 0)
			return 1;
	}
	if (read32(gic_base + GICH_BASE + GICH_EISRn(0)) != 0)
		return 1;
	if (read32(gic_base + GICH_BASE + GICH_EISRn(1)) != 0)
		return 1;
	if (read_isr_el1() != 0)
		return 1;

	struct blist_head *plugin_data = get_plugin_data(vcpu_get_vm(vcpu), vgic);
	if (!blist_empty(&plugin_data[vcpu_get_id(vcpu)]))
		return 1;
	return 0;
}

struct vcpu_int_info {
	BITFIELD(enable, MAX_INT_NR);
	BITFIELD(pending, MAX_INT_NR);
	BITFIELD(active, MAX_INT_NR);
};

static int vgicd_read(struct vcpu *vcpu, paddr_t pa, uint32_t access_size, uint64_t *v, void *arg __unused)
{
	switch (access_size) {
	case 1:
		*v = read8((void *) phys_to_virt(pa));
		return 0;
	case 4:
		*v = read32((void *) phys_to_virt(pa));
		return 0;
	default:
		EMSG("Invalid access size for vGICD\n");
		return -EINVAL;
	}
}

static int vgicd_write(struct vcpu *vcpu, paddr_t pa, uint32_t access_size, uint64_t v, void *arg __unused)
{
	void *va = (void *) phys_to_virt(pa);
	if (va >= gic_base + GICD_BASE + GICD_ICENABLERn(0) && va < gic_base + GICD_BASE + GICD_ISPENDRn(0)) {
		if (access_size != 4) {
			EMSG("Invalid access size for GICD_ICENABLERn\n");
			return -EINVAL;
		}
		uint32_t i = (va - gic_base - GICD_BASE - GICD_ICENABLERn(0)) / 4;
		for (uint32_t j = 0; j < 32; j++) {
			if (i * 32 + j < MAX_INT_NR && irq_handler[i * 32 + j].handler != NULL)
				v &= ~(1U << j);
		}
		write32(va, v);
		return 0;
	} else if (va >= gic_base + GICD_BASE + GICD_IPRIORITY(0) && va < gic_base + GICD_BASE + GICD_IPRIORITY(MAX_INT_NR)) {
		switch (access_size) {
		case 1: {
			uint32_t i = va - gic_base - GICD_BASE - GICD_IPRIORITY(0);
			if (i >= MAX_INT_NR)
				return 0;
			else if (irq_handler[i].handler != NULL)
				write8(va, DEFAULT_PRIORITY);
			else
				write8(va, v);
			return 0; }
		case 4: {
			uint32_t i = va - gic_base - GICD_BASE - GICD_IPRIORITY(0);
			for (uint32_t j = 0; j < 4; j++) {
				if (i + j < MAX_INT_NR && irq_handler[i + j].handler != NULL) {
					v &= ~(0xFFU << (j * 8));
					v |= (DEFAULT_PRIORITY << (j * 8));
				}
			}
			write32(va, v);
			return 0; }
		default:
			EMSG("Invalid access size for vGICD\n");
			return -EINVAL;
		}
	} else {
		switch (access_size) {
		case 1:
			write8(va, v);
			return 0;
		case 4:
			write32(va, v);
			return 0;
		default:
			EMSG("Invalid access size for vGICD\n");
			return -EINVAL;
		}
	}
}

struct vdevice_mmio_range vgicd_range[] = {
	{ .addr = GIC_BASE + GICD_BASE, .size = GICD_SIZE, .read = vgicd_read, .write = vgicd_write },
	{ .addr = GIC_BASE + GICH_BASE, .size = GICH_SIZE, .read = NULL, .write = NULL },
	{ .addr = 0, .size = 0 }
};
struct vdevice vgicd = {
	.init = NULL,
	.deinit = NULL,
	.mmio = vgicd_range
};

static int init_vgic_plugin(struct vm *vm, void **pdata)
{
	int ret;
	DMSG("Init vGIC for VM %u\n", vm_get_id(vm));

	struct vm_area gicc_vma;
	gicc_vma.va = GIC_BASE + GICC_BASE;
	gicc_vma.pa = GIC_BASE + GICV_BASE;
	gicc_vma.size = GICC_SIZE;
	gicc_vma.valid = 1;
	gicc_vma.ro = 0;
	gicc_vma.nocache = 0;
	gicc_vma.xn = 0;
	gicc_vma.device = 1;
	gicc_vma.forbidden = 0;
	if ((ret = mmu_apply_vma(vm_get_s2pt(vm), &gicc_vma)) != 0)
		return ret;
	if ((ret = vm_enable_trap(vm, TRAP_IRQ)) != 0)
		return ret;
	if ((ret = vdevice_add(vm, &vgicd)) != 0)
		return ret;
	*pdata = malloc(sizeof(struct blist_head) * NUM_CORES);
	if (*pdata == NULL) {
		EMSG("Out of memory");
		return -ENOMEM;
	}
	for (uint32_t i = 0; i < NUM_CORES; i++)
		blist_init(&((struct blist_head *) *pdata)[i], 10, sizeof(struct virq));
	return 0;
}

static void deinit_vgic_plugin(struct vm *vm, void *data)
{
	for (uint32_t i = 0; i < NUM_CORES; i++) {
		struct blist_head *head = &((struct blist_head *) data)[i];
		struct virq *p, *tmp;
		blist_for_each_entry_safe(p, tmp, head) {
			DMSG("virq entry %p\n", p);
			blist_del(p);
		}
	}
	free(data);
}

struct plugin vgic = {
	.init = init_vgic_plugin,
	.deinit = deinit_vgic_plugin
};
#ifdef ENABLE_VGIC
register_plugin(vgic);
#endif
