#include <printf.h>
#include <compiler.h>
#include <stdarg.h>
#include <string.h>
#include <arch/spinlock.h>

void __weak putchar(char ch)
{
}

void puts(const char *s)
{
	while (*s)
		putchar(*s++);
}

static int printdec(char *p, uint64_t v)
{
	if (v == 0) {
		*p = '0';
		return 1;
	}
	int i = 0;
	while (v) {
		*p++ = '0' + v % 10;
		v /= 10;
		i++;
	}
	return i;
}

static int printoct(char *p, uint64_t v)
{
	if (v == 0) {
		*p = '0';
		return 1;
	}
	int i = 0;
	while (v) {
		*p++ = '0' + v & 0x7;
		v >>= 3;
		i++;
	}
	return i;
}

static const char hex[] = "0123456789abcdef";
static int printhex(char *p, uint64_t v)
{
	if (v == 0) {
		*p = '0';
		return 1;
	}
	int i = 0;
	while (v) {
		*p++ = hex[v & 0xf];
		v >>= 4;
		i++;
	}
	return i;
}

static const char HEX[] = "0123456789ABCDEF";
static int printHEX(char *p, uint64_t v)
{
	if (v == 0) {
		*p = '0';
		return 1;
	}
	int i = 0;
	while (v) {
		*p++ = HEX[v & 0xf];
		v >>= 4;
		i++;
	}
	return i;
}

#define OUT(c) \
	do { \
		ret++; \
		if (ret < size) \
			*p++ = (c); \
	} while(0)
static int _vsnprintf(char *s, size_t size, const char *fmt, va_list ap)
{
	int ret = 0;
	char *p = s;
	for (;;) {
		while (*fmt != '%') {
			if (*fmt == '\0')
				return ret;
			OUT(*fmt++);
		}
		fmt++;
		if (*fmt == '\0') {
			OUT('%');
			return ret;
		}

		char spec = '\0';
		char alt = 0, zero = 0, left = 0, sig = 0, space = 0, dot = 0;
		char len = '\0';
		int width = 0, prec = 0;
		while (!spec) {
			switch (*fmt) {
			case ' ':
				space = 1;
				break;
			case '#':
				alt = 1;
				break;
			case '-':
				left = 1;
				break;
			case '+':
				sig = 1;
				break;
			case '.':
				dot = 1;
				break;
			case 'l':
				if (fmt[1] == 'l') {
					fmt++;
					len = 'L';
				} else
					len = 'l';
				break;
			case 'L':
				len = 'L';
				break;
			case 'z':
				len = 'z';
				break;
			case '0':
				if (!dot && width == 0)
					zero = 1;
				else if (dot)
					prec = prec * 10 + *fmt - '0';
				else
					width = width * 10 + *fmt - '0';
				break;
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
				if (dot)
					prec = prec * 10 + *fmt - '0';
				else
					width = width * 10 + *fmt - '0';
				break;
			case 'd':
			case 'i':
			case 'o':
			case 'u':
			case 'x':
			case 'X':
			case 'e':
			case 'E':
			case 'f':
			case 'F':
			case 'g':
			case 'G':
			case 'a':
			case 'A':
			case 'c':
			case 's':
			case 'p':
			case 'n':
			case '%':
				spec = *fmt;
				break;
			}
			fmt++;
			if (*fmt == '\0')
				return ret;
		}

		if (left)
			zero = 0;
		if (sig)
			space = 0;

		char tmp[50];
		int actual;
		switch (spec) {
		case 'd':
		case 'i': {
			uint64_t v;
			char minus = 0;
			switch (len) {
			case '\0':
				v = va_arg(ap, uint32_t);
				if ((int) v < 0) {
					minus = 1;
					v = -(int) v;
				}
				break;
			case 'l':
				v = va_arg(ap, unsigned long);
				if ((long) v < 0) {
					minus = 1;
					v = -(long) v;
				}
				break;
			case 'L':
				v = va_arg(ap, unsigned long long);
				if ((long long) v < 0) {
					minus = 1;
					v = -(long long) v;
				}
				break;
			case 'z':
				v = va_arg(ap, size_t);
				if ((ssize_t) v < 0) {
					minus = 1;
					v = -(ssize_t) v;
				}
				break;
			}
			if (minus) {
				actual = printdec(tmp, v) + 1;
				tmp[actual - 1] = '-';
			} else if (sig) {
				actual = printdec(tmp, v) + 1;
				tmp[actual - 1] = '+';
			} else if (space) {
				actual = printdec(tmp, v) + 1;
				tmp[actual - 1] = ' ';
			} else
				actual = printdec(tmp, v);
			break; }
		case 'u':
		case 'o':
		case 'x':
		case 'X': {
			uint64_t v;
			switch (len) {
			case '\0':
				v = va_arg(ap, uint32_t);
				break;
			case 'l':
				v = va_arg(ap, unsigned long);
				break;
			case 'L':
				v = va_arg(ap, unsigned long long);
				break;
			case 'z':
				v = va_arg(ap, size_t);
				break;
			}
			switch (spec) {
			case 'u':
				actual = printdec(tmp, v);
				break;
			case 'o':
				if (alt && v != 0) {
					actual = printoct(tmp, v) + 1;
					tmp[actual - 1] = '0';
				} else
					actual = printoct(tmp, v);
				break;
			case 'x':
				if (alt && v != 0) {
					actual = printhex(tmp, v) + 2;
					tmp[actual - 2] = 'x';
					tmp[actual - 1] = '0';
				} else
					actual = printhex(tmp, v);
				break;
			case 'X':
				if (alt && v != 0) {
					actual = printHEX(tmp, v) + 2;
					tmp[actual - 2] = 'X';
					tmp[actual - 1] = '0';
				} else
					actual = printhex(tmp, v);
				break;
			}
			break; }
		case 'c':
			tmp[0] = va_arg(ap, unsigned int);
			actual = 1;
			break;
		case 'p': {
			uint64_t v;
			v = (uint64_t) va_arg(ap, void *);
			if (v == 0) {
				tmp[0] = 'L';
				tmp[1] = 'L';
				tmp[2] = 'U';
				tmp[3] = 'N';
				actual = 4;
			} else {
				actual = printhex(tmp, v) + 2;
				tmp[actual - 2] = 'x';
				tmp[actual - 1] = '0';
			}
			break; }
		case 's': {
			char *s = va_arg(ap, char *);
			size_t slen = strlen(s);
			if (!left) {
				while (width > slen) {
					OUT(' ');
					width--;
				}
			}
			while (*s)
				OUT(*s++);
			if (left) {
				while (width > slen) {
					OUT(' ');
					width--;
				}
			}
			actual = 0;
			width = 0;
			break; }
		}
		if (!left) {
			if (zero) {
				while (width > actual) {
					OUT('0');
					width--;
				}
			} else {
				while (width > actual) {
					OUT(' ');
					width--;
				}
			}
		}
		if (actual > sizeof(tmp))
			actual = sizeof(tmp);
		{
			int backup = actual;
			while (actual--)
				OUT(tmp[actual]);
			actual = backup;
		}
		if (left) {
			while (width > actual) {
				OUT(' ');
				width--;
			}
		}
	}
}

int vsnprintf(char *s, size_t size, const char *fmt, va_list ap)
{
	int i = _vsnprintf(s, size, fmt, ap);
	if (i > size)
		s[size - 1] = '\0';
	else
		s[i] = '\0';
	return i;
}

int snprintf(char *s, size_t size, const char *fmt, ...)
{
	va_list args;
	int i;

	va_start(args, fmt);
	i = vsnprintf(s, size, fmt, args);
	va_end(args);

	return i;
}

spinlock_t printf_lock = SPINLOCK_INITIALIZER;
int printf(const char *fmt, ...)
{
	va_list args;
	int i;
	char tmp[1024];

	va_start(args, fmt);
	i = vsnprintf(tmp, sizeof(tmp), fmt, args);
	va_end(args);
	spin_lock(&printf_lock);
	puts(tmp);
	spin_unlock(&printf_lock);

	return i;
}
